@echo off
setlocal
title Playroom - Private updates
echo ONE-TIME SETUP
echo First accept the host's invitation to sosavz/SCHOOL-GAMES on GitHub.
echo Sign in below using that same GitHub account.
echo.
set "PLAYROOM_GH=gh"
if exist "%~dp0runtime\gh.exe" (
    set "PLAYROOM_GH=%~dp0runtime\gh.exe"
    goto login
)
where gh >nul 2>nul
if %errorlevel% equ 0 goto login
if exist "%ProgramFiles%\GitHub CLI\gh.exe" (
    set "PLAYROOM_GH=%ProgramFiles%\GitHub CLI\gh.exe"
    goto login
)
if exist "%LOCALAPPDATA%\Programs\GitHub CLI\gh.exe" (
    set "PLAYROOM_GH=%LOCALAPPDATA%\Programs\GitHub CLI\gh.exe"
    goto login
)
echo Install GitHub CLI from https://cli.github.com then run this file again.
echo You can also install it in Terminal with:
echo winget install --id GitHub.cli --exact --source winget
pause
exit /b 1
:login
"%PLAYROOM_GH%" api --hostname github.com repos/sosavz/SCHOOL-GAMES --silent >nul 2>nul
if not errorlevel 1 goto ready
echo Open the GitHub device page shown below and enter the new code there.
echo Git for Windows is not needed.
set "GH_PROMPT_DISABLED=1"
"%PLAYROOM_GH%" auth login --hostname github.com --git-protocol https --web --clipboard <nul
rem Check actual access even if an optional CLI configuration step failed.
"%PLAYROOM_GH%" api --hostname github.com repos/sosavz/SCHOOL-GAMES --silent
if errorlevel 1 (
    echo Private updates are not ready yet.
    echo Check your internet, finish GitHub sign-in and accept the host's invitation.
    echo You can still play your installed game.
    pause
    exit /b 1
)
:ready
echo Ready! Open Start UNO Together.cmd to check for updates and play.
pause
