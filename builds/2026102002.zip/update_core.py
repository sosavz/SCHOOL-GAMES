"""HTTPS release downloads and recoverable, data-preserving app updates."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import os
import re
import shutil
import stat
import time
import subprocess
import tempfile
import zipfile

REPOSITORY = 'sosavz/SCHOOL-GAMES'
API_PREFIX = 'repos/'+REPOSITORY+'/contents/'
MAX_PACKAGE = 8*1024*1024
MAX_EXPANDED = 16*1024*1024
REQUIRED = {'uno_app.py','uno_net.py','launcher.py','update_core.py','Start UNO Together.cmd'}
DOCS = {'README.md','Friends - START HERE.md','Friends - START HERE.html','Start UNO Together.cmd','Set up private updates.cmd'}


class UpdateError(Exception):
    pass


def allowed(name):
    """Never permit updates to saved data, the runtime, or arbitrary paths."""
    if not isinstance(name,str) or '\\' in name or ':' in name: return False
    parts=PurePosixPath(name).parts
    if not parts or '/'.join(parts)!=name or any(p in ('.','..') for p in parts): return False
    if len(parts)==1:
        return name in DOCS or bool(re.fullmatch(r'[a-z][a-z0-9_]*\.py',name))
    return len(parts)==2 and parts[0]=='sounds' and bool(re.fullmatch(r'[a-z][a-z0-9_]*\.wav',parts[1]))


def atomic_json(path,value):
    temp=path.with_name(path.name+'.tmp')
    with temp.open('w',encoding='utf-8') as file:
        json.dump(value,file,sort_keys=True)
        file.flush(); os.fsync(file.fileno())
    os.replace(temp,path)


def installed(root):
    try:
        value=json.loads((root/'version.json').read_text(encoding='utf-8'))
        if type(value['build']) is int and value['build']>=0 and isinstance(value['version'],str): return value
    except (OSError,ValueError,KeyError,TypeError): pass
    return {'build':0,'version':'Original copy'}


def validate_manifest(value):
    if not isinstance(value,dict) or value.get('schema')!=1: raise UpdateError('Unknown release format.')
    if type(value.get('build')) is not int or not 0<value['build']<10**15: raise UpdateError('Invalid release number.')
    if not isinstance(value.get('version'),str) or not re.fullmatch(r'[0-9.]{1,40}',value['version']): raise UpdateError('Invalid version.')
    if value.get('package') != f'builds/{value["build"]}.zip': raise UpdateError('Unexpected download location.')
    if not isinstance(value.get('sha256'),str) or not re.fullmatch('[a-f0-9]{64}',value['sha256']): raise UpdateError('Missing release checksum.')
    if type(value.get('size')) is not int or not 0<value['size']<=MAX_PACKAGE: raise UpdateError('Release is too large.')
    files=value.get('files')
    if not isinstance(files,dict) or not REQUIRED.issubset(files) or not 1<=len(files)<=80: raise UpdateError('Incomplete release.')
    total=0
    for name,entry in files.items():
        if not allowed(name) or not isinstance(entry,dict): raise UpdateError('Unsafe release path.')
        if type(entry.get('size')) is not int or not 0<=entry['size']<=4*1024*1024: raise UpdateError('File is too large.')
        if not isinstance(entry.get('sha256'),str) or not re.fullmatch('[a-f0-9]{64}',entry['sha256']): raise UpdateError('Missing file checksum.')
        total+=entry['size']
    if total>MAX_EXPANDED: raise UpdateError('Expanded release is too large.')
    return value


def github_cli():
    bundled=Path(__file__).resolve().parent/'runtime/gh.exe'
    if bundled.is_file(): return str(bundled)
    found=shutil.which('gh')
    if found: return found
    for variable in ('ProgramFiles','LOCALAPPDATA'):
        base=os.environ.get(variable)
        if base:
            candidate=Path(base)/('GitHub CLI' if variable=='ProgramFiles' else 'Programs/GitHub CLI')/'gh.exe'
            if candidate.is_file(): return str(candidate)
    raise UpdateError('Private updates need one-time setup. Open Set up private updates.cmd in the game folder.')


def download(relative,limit,progress=None,cancel=None):
    """Use each player's own GitHub CLI login; never read or bundle a token."""
    if relative!='latest.json' and not re.fullmatch(r'builds/[0-9]+\.zip',relative): raise UpdateError('Unexpected update address.')
    command=[github_cli(),'api','--hostname','github.com',API_PREFIX+relative+'?ref=main',
             '-H','Accept: application/vnd.github.raw+json']
    env=os.environ.copy(); env['GH_PROMPT_DISABLED']='1'; env['GH_NO_UPDATE_NOTIFIER']='1'
    # Bound disk and memory use even if the server sends an unexpectedly large response.
    with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
        proc=subprocess.Popen(command,stdout=output,stderr=errors,stdin=subprocess.DEVNULL,env=env,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        started=time.monotonic()
        try:
            while proc.poll() is None:
                if cancel is not None and cancel.is_set(): raise UpdateError('Update skipped.')
                if time.monotonic()-started>25: raise UpdateError('Update download took too long.')
                if os.fstat(output.fileno()).st_size>limit: raise UpdateError('Download is too large.')
                time.sleep(.05)
            if proc.returncode:
                raise UpdateError('Private updates unavailable. Check your internet, GitHub sign-in and repository invitation. See the friends guide.')
            if os.fstat(output.fileno()).st_size>limit: raise UpdateError('Download is too large.')
            output.seek(0); data=output.read(limit+1)
            if progress: progress(len(data),len(data))
            return data
        finally:
            if proc.poll() is None: proc.kill()
            proc.wait()


def check(root,fetch=download):
    try: manifest=validate_manifest(json.loads(fetch('latest.json',65536)))
    except (ValueError,UnicodeError) as exc: raise UpdateError('The update list could not be read.') from exc
    return manifest if manifest['build']>installed(root)['build'] else None


def verify_package(manifest,data):
    validate_manifest(manifest)
    if len(data)!=manifest['size'] or hashlib.sha256(data).hexdigest()!=manifest['sha256']:
        raise UpdateError('Download checksum failed. Your installed game has not changed.')
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            entries=archive.infolist()
            if len(entries)!=len(manifest['files']) or {x.filename for x in entries}!=set(manifest['files']):
                raise UpdateError('Unexpected files in update.')
            result={}
            for info in entries:
                expected=manifest['files'][info.filename]
                if info.is_dir() or stat.S_ISLNK(info.external_attr>>16) or info.flag_bits&1 or info.file_size!=expected['size']:
                    raise UpdateError('Unsafe archive entry.')
                content=archive.read(info)
                if hashlib.sha256(content).hexdigest()!=expected['sha256']: raise UpdateError('File checksum failed.')
                if info.filename.endswith('.py'):
                    compile(content,info.filename,'exec')  # Reject incompatible source before changing anything.
                result[info.filename]=content
            return result
    except (zipfile.BadZipFile,SyntaxError,RuntimeError) as exc:
        raise UpdateError('The update package is damaged or incompatible.') from exc


def safe_path(root,name):
    path=root/name
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise UpdateError('An update path points outside the game folder.')
    return path


def clear_work(root):
    work=safe_path(root,'.update-work')
    if work.exists(): shutil.rmtree(work)


def recover(root):
    """Restore the previous version if installation was interrupted."""
    work=safe_path(root,'.update-work')
    if not work.exists(): return False
    journal=work/'journal.json'
    if not journal.exists(): clear_work(root); return False
    value=json.loads(journal.read_text(encoding='utf-8'))
    if value.get('phase')=='committed': clear_work(root); return False
    files=value.get('files')
    if value.get('phase')!='applying' or not isinstance(files,dict): raise UpdateError('Update recovery needs the original game folder.')
    for name,existed in files.items():
        if (not allowed(name) and name!='version.json') or type(existed) is not bool: raise UpdateError('Invalid recovery record.')
        target=safe_path(root,name)
        if existed:
            backup=safe_path(work/'old',name)
            if not backup.is_file(): raise UpdateError('An update backup is missing. Keep this folder for recovery.')
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(backup,target)
        elif target.exists(): target.unlink()
    clear_work(root)
    return True


def install(root,manifest,data):
    """Called with the launcher lock held, before importing game modules."""
    root=Path(root).resolve()
    files=verify_package(manifest,data)
    recover(root)
    if manifest['build']<=installed(root)['build']: return False
    work=safe_path(root,'.update-work'); work.mkdir()
    files['version.json']=json.dumps({'build':manifest['build'],'version':manifest['version']}).encode('utf-8')
    existed={}
    try:
        for name,content in files.items():
            target=safe_path(root,name); existed[name]=target.exists()
            staged=safe_path(work/'new',name); staged.parent.mkdir(parents=True,exist_ok=True); staged.write_bytes(content)
            if target.exists():
                if not target.is_file(): raise UpdateError('An update target is not a file.')
                backup=safe_path(work/'old',name); backup.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(target,backup)
        atomic_json(work/'journal.json',{'phase':'applying','files':existed})
        # Version is written last. The recovery journal remains until every file is installed.
        for name in files:
            target=safe_path(root,name); target.parent.mkdir(parents=True,exist_ok=True)
            os.replace(work/'new'/name,target)
        atomic_json(work/'journal.json',{'phase':'committed','files':existed})
    except Exception:
        recover(root)
        raise
    try: clear_work(root)
    except OSError: pass  # A committed journal can be safely cleaned on the next launch.
    # Avoid stale timestamp-based bytecode after quick successive releases.
    cache=safe_path(root,'__pycache__')
    if cache.is_dir():
        for file in cache.glob('*.pyc'):
            try: safe_path(root,str(file.relative_to(root))).unlink()
            except OSError: pass
    return True


class GameLock:
    def __init__(self,root): self.path=root/'.playroom.lock'; self.file=None
    def __enter__(self):
        self.file=self.path.open('a+b')
        try:
            self.file.seek(0)
            if not self.file.read(1): self.file.write(b'0'); self.file.flush()
            self.file.seek(0)
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close(); self.file=None
            raise UpdateError('This copy of Playroom is already open. Close it before starting again.')
        return self
    def __exit__(self,*args):
        if self.file: self.file.close(); self.file=None
