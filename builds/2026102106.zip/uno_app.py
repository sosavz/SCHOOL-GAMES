"""UNO Together: private 2–6 player tables on the same Wi-Fi/LAN."""
import json
import math
from pathlib import Path
import queue
import re
import socket
import time
import webbrowser
import tkinter as tk
from tkinter import messagebox

from uno_art import paint_uno_card, rounded
from uno_net import CHAT_LENGTH, CHAT_HISTORY, DEFAULT_PORT, MAX_PLAYERS, GAMES, RoomClient, RoomServer, local_addresses
from maedn_view import MaednView
from uno_rules import UNO_COLORS, STARTING_HANDS, TARGET_SCORES
from uno_themes import THEMES, decorate_table

ROOT = Path(__file__).resolve().parent
DEFAULT_HOST = '192.168.178.193'
COLORS = {'Red': '#ed2734', 'Yellow': '#c49a16', 'Green': '#17a767', 'Blue': '#168de2', 'Wild': '#647970'}


class CoreApp(MaednView, tk.Tk):
    BG = '#0c211d'
    PANEL = '#15372e'
    TEXT = '#f5f3df'
    MUTED = '#aac0af'
    GOLD = '#ffe177'
    GREEN = '#287b59'

    def __init__(self):
        super().__init__()
        self.preferences = self.load_preferences()
        self.design = tk.StringVar(master=self, value=self.preferences.get('design', 'Playroom') if self.preferences.get('ui_revision')==2 else 'Playroom')
        self.base_tk_scaling = float(self.tk.call('tk','scaling'))
        self.text_size = tk.StringVar(master=self, value=self.preferences.get('text_size','Standard'))
        self.high_contrast = tk.BooleanVar(master=self, value=self.preferences.get('high_contrast',False))
        self.motion_pace = tk.StringVar(master=self, value=self.preferences.get('motion_pace','Playful'))
        self.refresh_palette()
        self.title('UNO Together · Up to six players. One table.')
        self.geometry('1240x880')
        self.minsize(1000, 760)
        self.configure(bg=self.BG)
        self.client = self.server = None
        self.state = None
        self.seat = None
        self.link = ''
        self.pending = False
        self.pending_request = None
        self.request_serial = 0
        self.scene = ''
        self.page = 0
        self.wild = None
        self.hover = None
        self.hits = []
        self.history = []
        self.chat_messages = []
        self.chat_draft = tk.StringVar(master=self)
        self.chat_draft.trace_add('write', lambda *_: self.update_chat_count())
        self.chat_tab = 'chat'
        self.chat_unread = 0
        self.chat_feedback = ''
        self.chat_pending = None
        self.chat_render_key = None
        self.animation = None
        self.animation_job = None
        self.poll_job = None
        self.closing = False
        self.last_move_revision = -1
        self.error_text = ''
        self.error_until = 0
        self.motion = tk.BooleanVar(master=self, value=self.preferences.get('motion', True))
        self.sound = tk.BooleanVar(master=self, value=self.preferences.get('sound', False))
        self.guidance = tk.BooleanVar(master=self, value=self.preferences.get('guidance', True))
        self.sorted_hand = tk.BooleanVar(master=self, value=self.preferences.get('sorted_hand', True))
        self.saved = self.load_session()
        self.name = tk.StringVar(master=self, value=str(self.preferences.get('player_name',self.saved.get('name','')))[:20])
        same_host = (self.saved.get('host'), self.saved.get('port')) == (DEFAULT_HOST, DEFAULT_PORT)
        self.code = tk.StringVar(master=self, value=str(self.saved.get('code', '')) if same_host else '')
        self.player_count = tk.IntVar(master=self, value=self.preferences.get('player_count', 2))
        self.game_kind = tk.StringVar(master=self, value=self.preferences.get('game_kind', 'uno'))
        self.three_rolls = tk.BooleanVar(master=self, value=self.preferences.get('three_rolls', False))
        self.home_jumping = tk.BooleanVar(master=self, value=self.preferences.get('home_jumping', True))
        migrated = self.preferences.get('rules_revision') == 1
        self.starting_cards = tk.IntVar(master=self, value=self.preferences.get('starting_cards', 7) if migrated else 7)
        self.target_score = tk.IntVar(master=self, value=self.preferences.get('target_score', 500) if migrated else 500)
        self.uno_mode = tk.StringVar(master=self, value=self.preferences.get('uno_mode','classic'))
        self.body = tk.Frame(self, bg=self.BG)
        self.body.pack(fill='both', expand=True, padx=28, pady=(0, 22))
        self.build_header()
        self.bind('<Escape>', lambda e: self.cancel_wild())
        self.bind('<Key-d>', lambda e: self.shortcut('draw'))
        self.bind('<Key-u>', lambda e: self.shortcut('uno'))
        self.bind('<Key-p>', lambda e: self.shortcut('pass'))
        self.bind('<space>', lambda e: self.board_shortcut())
        for piece in range(4):
            self.bind(f'<Key-{piece+1}>', lambda e, p=piece: self.board_shortcut(p))
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.show_home()
        self.poll_job = self.after(40, self.poll)
        self.apply_text_size()

    def load_preferences(self):
        try:
            data = json.loads((ROOT/'uno_preferences.json').read_text(encoding='utf-8'))
            choices = {'design': THEMES, 'player_count': range(2, 7), 'starting_cards': STARTING_HANDS,
                       'target_score': TARGET_SCORES, 'uno_mode': ('classic','extreme'),
                       'motion': (True, False), 'sorted_hand': (True, False), 'rules_revision': (1,),
                       'game_kind': GAMES, 'three_rolls': (True, False), 'home_jumping': (True, False),
                       'sound': (True, False), 'guidance': (True, False), 'ui_revision': (2,),
                       'text_size': ('Small','Standard','Large','Extra large'), 'high_contrast': (True,False),
                       'motion_pace': ('Gentle','Playful')}
            if not isinstance(data, dict): return {}
            valid={key: value for key, value in data.items() if key in choices
                    and type(value) in (str, int, bool) and value in choices[key]}
            if isinstance(data.get('player_name'),str): valid['player_name']=''.join(c for c in data['player_name'] if c.isprintable()).strip()[:20]
            return valid
        except (OSError, ValueError, TypeError):
            return {}

    def save_preferences(self):
        values = {'design': self.design.get(), 'motion': self.motion.get(), 'player_count': self.player_count.get(),
                  'starting_cards': self.starting_cards.get(), 'target_score': self.target_score.get(),
                  'uno_mode': self.uno_mode.get(),
                  'sorted_hand': self.sorted_hand.get(), 'rules_revision': 1,
                  'game_kind': self.game_kind.get(), 'three_rolls': self.three_rolls.get(), 'home_jumping': self.home_jumping.get(),
                  'sound': self.sound.get(), 'guidance': self.guidance.get(), 'ui_revision':2,
                  'text_size':self.text_size.get(), 'high_contrast':self.high_contrast.get(),
                  'motion_pace':self.motion_pace.get(), 'player_name':self.name.get().strip()[:20]}
        try:
            (ROOT/'uno_preferences.json').write_text(json.dumps(values, indent=2), encoding='utf-8')
        except OSError:
            pass

    def build_header(self):
        if hasattr(self, 'header'): self.header.destroy()
        self.header = tk.Frame(self, bg=self.BG, padx=28, pady=17)
        self.header.pack(fill='x', before=self.body)
        self.label(self.header, 'PLAY / TOGETHER', 16, self.GOLD, True).pack(side='left')
        self.button(self.header, 'How to play', self.show_rules, secondary=True).pack(side='right')
        self.button(self.header, 'Connection help', self.show_connection_help, secondary=True).pack(side='right', padx=6)
        menu = tk.OptionMenu(self.header, self.design, *THEMES, command=self.apply_design)
        menu.configure(bg=self.BUTTON, fg=self.TEXT, highlightthickness=0, relief='flat',
                       font=('Segoe UI', 10, 'bold'), width=12, padx=6, pady=10)
        menu['menu'].configure(bg=self.PANEL, fg=self.TEXT)
        menu.pack(side='right', padx=(6, 10))
        self.connection_label = self.label(self.header, '', 9, self.MUTED)
        self.connection_label.pack(side='left', padx=16)

    def apply_design(self, design):
        if design not in THEMES: return
        # A connected room uses the host-selected design everywhere. Appearance
        # controls are disabled in-room; ignore stale callbacks as well.
        if isinstance(getattr(self, 'state', None), dict): return
        self.design.set(design)
        self.refresh_palette()
        self.configure(bg=self.BG); self.body.configure(bg=self.BG)
        self.build_header()
        self.save_preferences()
        if self.state:
            self.scene = ''
            self.update_view()
        elif self.client:
            self.begin_connection()
        else:
            self.show_home()

    def active_design(self):
        """A room follows the host's lobby design; menus keep the local choice."""
        state=getattr(self,'state',None)
        if isinstance(state,dict): return state.get('theme',self.design.get())
        return self.design.get()

    def refresh_palette(self):
        palette=dict(THEMES.get(self.active_design(),THEMES['Playroom']))
        if getattr(self,'high_contrast',None) and self.high_contrast.get():
            palette.update(BG='#000000',PANEL='#101010',TEXT='#ffffff',MUTED='#f0f0f0',GOLD='#ffff00',
                           GREEN='#006b38',BUTTON='#242424',BUTTON_TEXT='#ffffff',BOARD='#050505',
                           BORDER='#ffffff',TILE='#000000',ACTIVE='#303030',ENTRY='#000000',ERROR='#ff8c8c')
        for key,value in palette.items(): setattr(self,key,value)

    def apply_text_size(self):
        factor={'Small':.9,'Standard':1.0,'Large':1.13,'Extra large':1.26}.get(self.text_size.get(),1.0)
        self.tk.call('tk','scaling',self.base_tk_scaling*factor)

    def load_session(self):
        try:
            data = json.loads((ROOT/'uno_session.json').read_text(encoding='utf-8'))
            if not isinstance(data, dict):
                return {}
            return {key: value for key, value in data.items() if key in ('name', 'host', 'port', 'code', 'resume')}
        except (OSError, ValueError):
            return {}

    def save_session(self, event):
        if self.server or not self.client:
            return
        self.saved = {'name': self.client.name, 'host': self.client.host, 'port': self.client.port,
                      'code': self.client.code, 'resume': event['resume']}
        try:
            (ROOT/'uno_session.json').write_text(json.dumps(self.saved, indent=2), encoding='utf-8')
        except OSError:
            pass

    def button(self, parent, text, command, secondary=False, danger=False, large=False):
        bg = self.GREEN if danger else self.BUTTON if secondary else self.GREEN
        return tk.Button(parent, text=text, command=command, bg=bg, fg=self.TEXT if secondary else self.BUTTON_TEXT,
                         activebackground=self.GREEN, activeforeground=self.BUTTON_TEXT, disabledforeground=self.MUTED,
                         font=('Segoe UI', 13 if large else 10, 'bold'), relief='flat', bd=0,
                         padx=22 if large else 14, pady=17 if large else 10,
                         cursor='hand2', takefocus=True)

    def label(self, parent, text, size=11, color=None, bold=False, **options):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color or self.TEXT,
                        font=('Segoe UI', size, 'bold' if bold else 'normal'), **options)

    def field(self, parent, label, variable, width=None):
        self.label(parent, label, 10, self.MUTED).pack(anchor='w', pady=(12, 5))
        entry = tk.Entry(parent, textvariable=variable, font=('Segoe UI', 13), bg=self.ENTRY,
                         fg='#17382c', insertbackground='#17382c', relief='flat', width=width)
        entry.pack(fill='x', ipady=9)
        return entry

    def clear_body(self):
        for widget in self.body.winfo_children():
            widget.destroy()
        self.hits = []
        self.wild = None
        self.hover = None

    def show_home(self):
        self.clear_body()
        self.title('UNO Together · Up to six players. One table.')
        self.scene = 'home'
        self.connection_label.configure(text='2–6 players')
        hero = tk.Frame(self.body, bg=self.BG)
        hero.pack(fill='x', pady=(8, 12))
        if self.error_text:
            self.label(hero, 'Couldn’t connect to the table', 24, self.ERROR, True).pack(anchor='w')
            self.connection_error_label = self.label(hero, self.error_text, 11, self.ERROR,
                                                     wraplength=max(600, self.winfo_width()-100), justify='left')
            self.connection_error_label.pack(anchor='w', pady=(10, 8))
        else:
            self.label(hero, 'Bring the whole table together.', 30, bold=True).pack(anchor='w')
            self.label(hero, 'UNO or Mensch ärgere dich nicht. Choose a game, invite your friends, and play.',
                       12, self.MUTED).pack(anchor='w', pady=(8, 16))
            strip = tk.Canvas(hero, height=90, bg=self.BG, highlightthickness=0)
            strip.design = self.active_design()
            strip.pack(fill='x')
            for i, card in enumerate([None, ('Red', '7'), ('Yellow', 'Skip'), ('Green', 'Reverse'), ('Blue', '+2'), ('Wild', 'Wild'), ('Wild', '+4')]):
                paint_uno_card(strip, 6+i*65, 4, 53, 80, card)
        name_bar = tk.Frame(self.body, bg=self.PANEL, padx=20, pady=10)
        name_bar.pack(fill='x', pady=(0, 14))
        self.label(name_bar, 'YOUR NAME', 9, self.MUTED, True).pack(side='left', padx=(0, 14))
        tk.Entry(name_bar, textvariable=self.name, font=('Segoe UI', 13), width=23, relief='flat',
                 bg=self.ENTRY, fg='#17382c').pack(side='left', ipady=7)
        self.label(name_bar, '2–6 players · Two games · One room', 10, self.MUTED).pack(side='right')
        columns = tk.Frame(self.body, bg=self.BG)
        columns.pack(fill='both', expand=True)
        columns.columnconfigure(0, weight=1, uniform='forms')
        columns.columnconfigure(1, weight=1, uniform='forms')
        columns.rowconfigure(0, weight=1)
        host = tk.Frame(columns, bg=self.PANEL, padx=24, pady=22)
        host.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        join = tk.Frame(columns, bg=self.PANEL, padx=24, pady=22)
        join.grid(row=0, column=1, sticky='nsew', padx=(8, 0))
        self.label(host, '01   HOST A TABLE', 11, self.GOLD, True).pack(anchor='w')
        self.label(host, 'Make room for everyone.', 22, bold=True).pack(anchor='w', pady=(10, 6))
        self.label(host, 'Choose your settings, then share the lobby code.\nEveryone selects Ready. Keep this app open.',
                   11, self.MUTED, justify='left').pack(anchor='w')
        self.host_summary = self.label(host, self.settings_summary(), 10, self.GOLD, True)
        self.host_summary.pack(anchor='w', pady=(12, 8))
        host_actions = tk.Frame(host, bg=self.PANEL); host_actions.pack(fill='x', pady=(0, 10))
        self.button(host_actions, 'Host settings', self.show_host_settings, secondary=True).pack(side='left', padx=(0, 8))
        self.button(host_actions, 'Create a room →', self.host_room).pack(side='left')
        self.label(host, 'Share the full UNO Together folder with each friend.\nNo Python installation needed with the Windows ZIP.',
                   10, self.MUTED, justify='left').pack(anchor='w')
        self.label(join, '02   JOIN A FRIEND', 11, self.GOLD, True).pack(anchor='w')
        self.label(join, 'Just bring your lobby code.', 20, bold=True).pack(anchor='w', pady=(10, 6))
        self.label(join, 'The host address and port are built in.',
                   11, self.MUTED, justify='left').pack(anchor='w')
        code_entry = self.field(join, 'Six-digit lobby code', self.code)
        code_entry.bind('<Return>', lambda event: self.join_room())
        actions = tk.Frame(join, bg=self.PANEL)
        actions.pack(fill='x', pady=(12, 0))
        self.button(actions, 'Join room  →', self.join_room).pack(side='left')
        if self.saved.get('resume') and self.saved.get('host') == DEFAULT_HOST and self.saved.get('port') == DEFAULT_PORT:
            self.button(actions, 'Resume last room', lambda: self.join_room(resume=True), secondary=True).pack(side='left', padx=8)
        bottom = tk.Frame(self.body, bg=self.BG)
        bottom.pack(side='bottom', fill='x', pady=(14, 0), before=columns)
        self.button(bottom, 'Friends’ guide', self.open_friends_guide, secondary=True).pack(side='left')
        self.home_error = self.label(bottom, '', 10, self.ERROR, wraplength=720, justify='left')
        self.home_error.pack(side='left', padx=15)

    def credentials(self):
        name = ''.join(c for c in self.name.get() if c.isprintable()).strip()[:20]
        if not name:
            if hasattr(self,'name_entry') and self.name_entry.winfo_exists(): self.name_entry.focus_set()
            raise ValueError('Enter your name first.')
        return name, DEFAULT_PORT

    def settings_summary(self):
        if self.game_kind.get() == 'maedn':
            return f'Mensch ärgere dich nicht · {self.player_count.get()} players'
        mode = 'Extreme UNO' if self.uno_mode.get()=='extreme' else 'Classic' if (self.starting_cards.get(), self.target_score.get()) == (7, 500) else 'Custom'
        return f'{mode} · {self.player_count.get()} players · {self.starting_cards.get()} cards · {self.target_score.get()} points'

    def open_friends_guide(self):
        guide = ROOT/'Friends - START HERE.html'
        if guide.exists(): webbrowser.open(guide.as_uri())
        else: self.show_connection_help()

    def show_host_settings(self):
        dialog = tk.Toplevel(self)
        dialog.title('Host settings · UNO Together')
        dialog.geometry('590x640'); dialog.resizable(False, False)
        dialog.configure(bg=self.PANEL); dialog.transient(self); dialog.grab_set()
        frame = tk.Frame(dialog, bg=self.PANEL, padx=28, pady=22); frame.pack(fill='both', expand=True)
        self.label(frame, 'Set up your table', 23, self.GOLD, True).pack(anchor='w', pady=(0, 10))
        in_room = self.state is not None
        locked = in_room and (self.seat != 0 or self.state['game'] is not None)
        settings = self.state['settings'] if in_room else {'starting_cards':self.starting_cards.get(), 'target_score':self.target_score.get()}
        players = tk.IntVar(master=dialog, value=self.state['player_count'] if in_room else self.player_count.get())
        cards = tk.IntVar(master=dialog, value=settings['starting_cards'])
        target = tk.IntVar(master=dialog, value=settings['target_score'])
        game_kind = self.state.get('game_kind', 'uno') if in_room else self.game_kind.get()
        board = self.state['board_settings'] if in_room else {'three_rolls':self.three_rolls.get(), 'home_jumping':self.home_jumping.get()}
        game_choice = tk.StringVar(master=dialog, value=GAMES[game_kind])
        three_rolls = tk.BooleanVar(master=dialog, value=board['three_rolls'])
        home_jumping = tk.BooleanVar(master=dialog, value=board['home_jumping'])
        dialog.game_choice, dialog.three_rolls, dialog.home_jumping = game_choice, three_rolls, home_jumping
        rows = []
        for title, variable, values, disabled in (
                ('Players, including the host', players, range(2, 7), locked),
                ('Starting cards per player', cards, STARTING_HANDS, locked),
                ('Points to win the match', target, TARGET_SCORES, locked)):
            row = tk.Frame(frame, bg=self.PANEL); row.pack(fill='x', pady=10)
            rows.append(row)
            self.label(row, title, 11).pack(side='left')
            menu = tk.OptionMenu(row, variable, *values)
            menu.configure(bg=self.BUTTON, fg=self.TEXT, highlightthickness=0, width=6,
                           font=('Segoe UI', 12), state='disabled' if disabled else 'normal')
            menu['menu'].configure(bg=self.PANEL, fg=self.TEXT)
            menu.pack(side='right')
        game_row = tk.Frame(frame, bg=self.PANEL); game_row.pack(fill='x', pady=10, before=rows[0])
        self.label(game_row, 'Game', 11).pack(side='left')
        menu = tk.OptionMenu(game_row, game_choice, *GAMES.values())
        menu.configure(bg=self.BUTTON, fg=self.TEXT, highlightthickness=0, font=('Segoe UI',11),
                       state='disabled' if locked else 'normal')
        menu['menu'].configure(bg=self.PANEL, fg=self.TEXT); menu.pack(side='right')
        preset = self.button(frame, 'Use classic UNO · 7 cards / 500 points',
                             lambda: (cards.set(7), target.set(500)), secondary=True)
        preset.pack(fill='x', pady=(8,0))
        board_panel = tk.Frame(frame, bg=self.PANEL)
        for title, variable in (('Three attempts when all remaining pawns are stuck in base', three_rolls),
                                 ('Allow jumping over your pawns inside the home lane', home_jumping)):
            tk.Checkbutton(board_panel, text=title, variable=variable, bg=self.PANEL, fg=self.TEXT,
                           activebackground=self.PANEL, activeforeground=self.TEXT, selectcolor=self.BG,
                           font=('Segoe UI',10), state='disabled' if locked else 'normal', anchor='w').pack(fill='x',pady=8)
        self.label(board_panel,'4 pawns each · Exact rolls to finish · Six gives another roll\n40 spaces for 2–4 players / 60 spaces for 5–6 players',
                   10,self.MUTED,justify='left').pack(anchor='w',pady=8)
        def choose_game(*_):
            is_uno = game_choice.get() == GAMES['uno']
            for row in rows[1:]:
                for widget in row.winfo_children():
                    if isinstance(widget,tk.Menubutton): widget.configure(state='normal' if is_uno and not locked else 'disabled')
            preset.configure(state='normal' if is_uno and not locked else 'disabled')
            if is_uno:
                board_panel.pack_forget()
                for index,row in enumerate(rows[1:],1): row.pack(fill='x',pady=10,after=rows[index-1])
                preset.pack(fill='x',pady=(8,0),after=rows[-1])
            else:
                for row in rows[1:]: row.pack_forget()
                preset.pack_forget()
                board_panel.pack(fill='x',after=rows[0],pady=(8,0))
        game_choice.trace_add('write',choose_game)
        choose_game()
        hint = ('This match has started. Create a new room to change the rules.' if locked else
                'Everyone sees changes and must Ready again. Connected players cannot be removed; smaller tables release removed offline seats.' if in_room else
                'Choose either game here. Your design is chosen separately in the top menu.')
        self.label(frame, hint, 10, self.MUTED, wraplength=530, justify='left').pack(anchor='w', pady=12)
        def apply():
            kind = next(key for key,value in GAMES.items() if value == game_choice.get())
            if in_room:
                if not self.send_command({'type':'settings', 'player_count':players.get(),
                                          'starting_cards':cards.get(), 'target_score':target.get(),
                                          'game_kind':kind, 'three_rolls':three_rolls.get(), 'home_jumping':home_jumping.get()}):
                    return
            else:
                self.player_count.set(players.get())
                self.starting_cards.set(cards.get()); self.target_score.set(target.get())
                self.game_kind.set(kind); self.three_rolls.set(three_rolls.get()); self.home_jumping.set(home_jumping.get())
                self.save_preferences()
            dialog.destroy()
            self.update_view() if in_room else self.show_home()
        buttons = tk.Frame(frame, bg=self.PANEL); buttons.pack(side='bottom', fill='x')
        if not locked: self.button(buttons, 'Apply settings', apply).pack(side='left')
        self.button(buttons, 'Close' if locked else 'Cancel', dialog.destroy, secondary=True).pack(side='right')

    def host_room(self):
        try:
            name, port = self.credentials()
            self.server = RoomServer(port, player_count=self.player_count.get(),
                                     starting_cards=self.starting_cards.get(), target_score=self.target_score.get(),
                                     uno_mode=self.uno_mode.get(),
                                     game_kind=self.game_kind.get(), three_rolls=self.three_rolls.get(), home_jumping=self.home_jumping.get(),
                                     theme=self.design.get())
            self.invite_addresses = local_addresses()
            self.client = RoomClient('127.0.0.1', self.server.port, self.server.code, name, host_key=self.server.host_key)
        except (OSError, ValueError) as exc:
            self.error_text = f'Could not open the room: {exc}. Close any other UNO host window and try again.'
            self.home_error.configure(text=self.error_text)
            return
        self.begin_connection()

    def join_room(self, resume=False):
        try:
            name, port = self.credentials()
            host = DEFAULT_HOST
            code = self.code.get().strip().replace(' ', '')
            if resume:
                code = str(self.saved.get('code', ''))
                self.code.set(code)
            if not (len(code) == 6 and code.isascii() and code.isdigit()):
                raise ValueError('Enter the six-digit room code shown on the host PC.')
            token = ''
            if (host, port, code) == (self.saved.get('host'), self.saved.get('port'), self.saved.get('code')):
                token = self.saved.get('resume', '')
            self.client = RoomClient(host, port, code, name, resume=token)
        except (ValueError, OSError) as exc:
            self.error_text = str(exc)
            self.home_error.configure(text=self.error_text)
            return
        self.begin_connection()

    def begin_connection(self):
        self.error_text = ''
        self.state = None
        self.pending = False
        self.pending_request = None
        self.seat = None
        self.link = 'Connecting…'
        self.clear_body()
        self.scene = 'connecting'
        self.label(self.body, 'Pulling up a chair…', 27, bold=True).pack(pady=(130, 14))
        self.connect_note = self.label(self.body, 'Connecting to the host PC.', 12, self.MUTED, wraplength=700)
        self.connect_note.pack()
        self.button(self.body, 'Back', lambda: self.leave(False), secondary=True).pack(pady=24)

    def poll(self):
        self.poll_job = None
        try:
            if self.client:
                for _ in range(30):
                    try:
                        event = self.client.events.get_nowait()
                    except queue.Empty:
                        break
                    kind = event.get('type')
                    if kind == 'welcome':
                        self.seat = event['seat']
                        self.link = 'Connected'
                        self.save_session(event)
                    elif kind in ('chat', 'chat_history'):
                        messages = [event['message']] if kind == 'chat' else event['messages']
                        self.receive_chat(messages, live=kind == 'chat')
                    elif kind == 'chat_error':
                        self.chat_pending = None
                        self.chat_feedback = event['message']
                        self.refresh_chat()
                    elif kind == 'ack':
                        if event.get('request') == self.pending_request:
                            self.pending = False
                            self.pending_request = None
                            self.update_view()
                    elif kind == 'connection':
                        self.link = event['status']
                        if self.chat_pending:
                            self.chat_pending = None
                            self.chat_feedback = 'Connection lost. Check chat before resending your draft.'
                        self.pending = False
                        self.pending_request = None
                        if self.scene == 'connecting':
                            self.connect_note.configure(text=self.link)
                        elif self.state:
                            self.update_view()
                    elif kind == 'error':
                        self.pending = False
                        self.pending_request = None
                        self.error_text = event['message']
                        self.error_until = time.monotonic()+4
                        if event.get('fatal'):
                            if event.get('forget_resume'):
                                self.saved = {}
                                try: (ROOT/'uno_session.json').write_text('{}', encoding='utf-8')
                                except OSError: pass
                            self.leave(False, preserve_error=True)
                            break
                        self.update_view()
                    elif kind == 'state':
                        old = self.state
                        old_theme = old.get('theme') if old else None
                        self.state = event
                        if old_theme != event.get('theme'):
                            self.refresh_palette()
                            self.configure(bg=self.BG)
                            self.body.configure(bg=self.BG)
                            if hasattr(self,'header'): self.build_header()
                            self.scene = ''
                        self.seat = event['seat']
                        if self.pending_request is None: self.pending = False
                        self.link = 'Connected'
                        game = event.get('game')
                        is_uno = game and game.get('kind', 'uno') == 'uno'
                        if self.wild is not None and (not is_uno or not old or not old.get('game') or
                                game['hand'] != old['game']['hand'] or game['color'] != old['game']['color'] or
                                not all(event['connected']) or
                                not any(a[0] == 'play' and a[1] == self.wild for a in game['actions'])):
                            self.wild = None
                        if is_uno and (not old or old.get('game') is None or old['game']['hand'] != game['hand'] or bool(old['game']['audit']) != bool(game['audit'])):
                            self.page = self.hand_order(game).index(game['drawn_index'])//7 if game['phase'] == 'drawn' and game['drawn_index'] is not None else 0
                        note = event['event']
                        if not self.history or self.history[-1] != note:
                            self.history = (self.history + [note])[-30:]
                        move = event.get('last_move')
                        if move and move['revision'] > self.last_move_revision:
                            self.last_move_revision = move['revision']
                            if self.motion.get() and move['kind'] in ('play', 'draw'):
                                self.animation = (time.monotonic(), move)
                                self.ensure_frame()
                        if time.monotonic() >= self.error_until:
                            self.error_text = ''
                        self.visual_state_changed(old, event)
                        self.update_view()
            if self.error_text and self.error_until and time.monotonic() >= self.error_until and self.state:
                self.error_text = ''
                self.error_until = 0
                self.update_view()
        finally:
            if not self.closing:
                self.poll_job = self.after(40, self.poll)

    def display_note(self, note):
        if not self.state:
            return note
        return re.sub(r'\bP([1-6])\b', lambda m: self.state['names'][int(m[1])-1]
                      if int(m[1]) <= len(self.state['names']) else m[0], note)

    def linked(self):
        return bool(self.client and self.client.connected and self.link == 'Connected')

    def can_play(self):
        return bool(self.state and self.linked() and all(self.state['connected']) and not self.pending)

    def update_view(self):
        if not self.state:
            return
        game = self.state['game']
        desired = ('maedn' if game.get('kind') == 'maedn' else 'table') if game else 'room'
        if self.scene != desired or getattr(self, 'scene_player_count', None) != self.state['player_count']:
            self.clear_body()
            self.scene = desired
            self.scene_player_count = self.state['player_count']
            if desired == 'maedn': self.build_maedn()
            elif game: self.build_table()
            else: self.build_room()
        self.connection_label.configure(text=f'Room {self.state["room"]}  ·  '+('Connected' if self.linked() else 'Reconnecting…'))
        if desired == 'maedn':
            self.update_maedn()
        elif game:
            self.update_table()
        else:
            self.update_room()
        self.refresh_chat()

    def build_chat(self, parent):
        rail = tk.Frame(parent, width=290, bg=self.PANEL, padx=14, pady=14)
        rail.pack(side='right', fill='y', padx=(14, 0))
        rail.pack_propagate(False)
        self.label(rail, 'AT THE TABLE', 10, self.GOLD, True).pack(anchor='w')
        tabs = tk.Frame(rail, bg=self.PANEL)
        tabs.pack(fill='x', pady=(10, 10))
        self.chat_tab_button = self.button(tabs, 'Chat', lambda: self.select_chat_tab('chat'))
        self.chat_tab_button.pack(side='left', fill='x', expand=True)
        self.activity_tab_button = self.button(tabs, 'Activity', lambda: self.select_chat_tab('activity'), secondary=True)
        self.activity_tab_button.pack(side='left', fill='x', expand=True, padx=(6, 0))
        footer = tk.Frame(rail, bg=self.PANEL)
        footer.pack(side='bottom', fill='x')
        if self.state.get('game'):
            options = tk.Frame(footer, bg=self.PANEL)
            options.pack(side='bottom', fill='x', pady=(10, 0))
            self.button(options, 'Leave room', self.leave, secondary=True).pack(side='right')
            tk.Checkbutton(options, text='Animations', variable=self.motion, command=self.draw,
                           bg=self.PANEL, fg=self.MUTED, selectcolor=self.BG, activebackground=self.PANEL,
                           activeforeground=self.TEXT, relief='flat').pack(side='left')
        self.chat_status = self.label(footer, '', 9, self.MUTED, wraplength=258, justify='left', anchor='w')
        self.chat_status.pack(fill='x', pady=(10, 6))
        self.chat_entry = tk.Entry(footer, textvariable=self.chat_draft, font=('Segoe UI', 11),
                                   bg=self.ENTRY, fg='#17382c', insertbackground='#17382c', relief='flat')
        self.chat_entry.pack(fill='x', ipady=10)
        self.chat_entry.bind('<Return>', self.send_chat)
        self.chat_entry.bind('<KP_Enter>', self.send_chat)
        row = tk.Frame(footer, bg=self.PANEL); row.pack(fill='x', pady=(8, 0))
        self.chat_count = self.label(row, '', 9, self.MUTED)
        self.chat_count.pack(side='left')
        self.chat_send = self.button(row, 'Send ↵', self.send_chat)
        self.chat_send.pack(side='right')
        log_frame = tk.Frame(rail, bg=self.PANEL)
        log_frame.pack(fill='both', expand=True)
        scroll = tk.Scrollbar(log_frame, orient='vertical')
        scroll.pack(side='right', fill='y')
        self.chat_log = tk.Text(log_frame, width=1, height=1, wrap='word', bg=self.BG, fg=self.TEXT,
                                font=('Segoe UI', 10), relief='flat', padx=10, pady=10, spacing3=7,
                                selectbackground=self.GREEN, selectforeground=self.BUTTON_TEXT,
                                insertwidth=0, state='disabled', yscrollcommand=scroll.set)
        self.chat_log.pack(side='left', fill='both', expand=True)
        scroll.configure(command=self.chat_log.yview)
        self.chat_log.tag_configure('author', foreground=self.GOLD, font=('Segoe UI', 9, 'bold'), spacing3=1)
        self.chat_log.tag_configure('muted', foreground=self.MUTED)
        self.chat_render_key = None
        self.update_chat_count()

    def select_chat_tab(self, tab):
        self.chat_tab = tab
        if tab == 'chat': self.chat_unread = 0
        self.chat_render_key = None
        self.refresh_chat()

    def receive_chat(self, messages, live=False):
        seen = {entry['id'] for entry in self.chat_messages}
        for entry in messages:
            if live and entry['seat'] == self.seat and entry['text'] == self.chat_pending:
                if ''.join(c for c in self.chat_draft.get() if c.isprintable()).strip() == self.chat_pending:
                    self.chat_draft.set('')
                self.chat_pending = None
                self.chat_feedback = ''
            if entry['id'] not in seen:
                self.chat_messages.append(entry)
                seen.add(entry['id'])
                if live and self.chat_tab != 'chat' and entry['seat'] != self.seat:
                    self.chat_unread += 1
        self.chat_messages = sorted(self.chat_messages, key=lambda entry: entry['id'])[-CHAT_HISTORY:]
        self.refresh_chat()

    def update_chat_count(self):
        if hasattr(self, 'chat_count') and self.chat_count.winfo_exists():
            length = len(self.chat_draft.get())
            self.chat_count.configure(text=f'{length}/{CHAT_LENGTH}', fg=self.ERROR if length > CHAT_LENGTH else self.MUTED)

    def send_chat(self, event=None):
        text = ''.join(c for c in self.chat_draft.get() if c.isprintable()).strip()
        if self.chat_pending:
            return 'break'
        if not self.linked():
            self.chat_feedback = 'Reconnecting… Your draft is kept.'
        elif not text:
            self.chat_feedback = 'Type a message first.'
        elif len(text) > CHAT_LENGTH:
            self.chat_feedback = f'Keep messages to {CHAT_LENGTH} characters.'
        elif self.client.send({'type': 'chat', 'text': text}):
            self.chat_pending = text
            self.chat_feedback = ''
            self.select_chat_tab('chat')
        else:
            self.chat_feedback = 'Couldn’t send yet. Try again in a moment.'
        self.refresh_chat()
        return 'break'

    def refresh_chat(self):
        if not hasattr(self, 'chat_log') or not self.chat_log.winfo_exists(): return
        self.chat_send.configure(state='normal' if self.linked() and not self.chat_pending else 'disabled')
        self.chat_status.configure(text=self.chat_feedback or ('Sending your message…' if self.chat_pending else 'Message everyone · Enter to send' if self.linked() else 'Reconnecting… Your draft is kept.'),
                                   fg=self.ERROR if self.chat_feedback else self.MUTED)
        self.chat_tab_button.configure(text='Chat'+(f' ({self.chat_unread})' if self.chat_unread else ''),
                                       bg=self.GREEN if self.chat_tab == 'chat' else self.BUTTON)
        self.activity_tab_button.configure(bg=self.GREEN if self.chat_tab == 'activity' else self.BUTTON)
        key = (self.chat_tab, tuple(entry['id'] for entry in self.chat_messages) if self.chat_tab == 'chat' else tuple(self.history))
        if key == self.chat_render_key: return
        previous_tab = self.chat_render_key[0] if self.chat_render_key else None
        position = self.chat_log.yview()
        at_bottom = not position or position[1] >= .98 or previous_tab != self.chat_tab
        self.chat_render_key = key
        self.chat_log.configure(state='normal')
        self.chat_log.delete('1.0', 'end')
        if self.chat_tab == 'activity':
            for note in self.history:
                self.chat_log.insert('end', self.display_note(note)+'\n\n')
        elif not self.chat_messages:
            self.chat_log.insert('end', 'Say hello to your table.\n\nMessages are visible to everyone in this room, even between rounds.', 'muted')
        else:
            for entry in self.chat_messages:
                author = f'P{entry["seat"]+1} · {entry["name"]}'+(' (you)' if entry['seat'] == self.seat else '')
                self.chat_log.insert('end', author+'  ·  '+entry['time']+'\n', 'author')
                self.chat_log.insert('end', entry['text']+'\n\n')
        self.chat_log.configure(state='disabled')
        if at_bottom: self.chat_log.see('end')
        else: self.chat_log.yview_moveto(position[0])

    def build_room(self):
        self.build_chat(self.body)
        main = tk.Frame(self.body, bg=self.BG)
        main.pack(side='left', fill='both', expand=True)
        self.label(main, 'Your table is open.' if self.server else 'You’re at the table.', 26, bold=True).pack(anchor='w', pady=(8, 6))
        self.room_heading = self.label(main, '', 11, self.MUTED, wraplength=620, justify='left')
        self.room_heading.pack(anchor='w', pady=(0, 12))
        invite = tk.Frame(main, bg=self.PANEL, padx=18, pady=12)
        invite.pack(fill='x')
        self.label(invite, 'ROOM CODE', 10, self.MUTED, True).pack(anchor='w')
        self.label(invite, self.state['room'], 32, self.GOLD, True).pack(side='left')
        if self.server:
            self.button(invite, 'Copy lobby code', self.copy_invite, secondary=True).pack(side='right')
        else:
            self.label(invite, 'Choose Ready\nwhen you’re set.', 10, self.MUTED).pack(side='right')
        settings_row = tk.Frame(main, bg=self.BG); settings_row.pack(fill='x', pady=(12, 0))
        self.room_settings_label = self.label(settings_row, '', 10, self.GOLD, True)
        self.room_settings_label.pack(side='left')
        if self.server:
            self.button(settings_row, 'Host settings', self.show_host_settings, secondary=True).pack(side='right')
        seats = tk.Frame(main, bg=self.BG)
        seats.pack(fill='x', pady=10)
        self.seat_labels = []
        columns = min(3, self.state['player_count'])
        for column in range(columns):
            seats.columnconfigure(column, weight=1, uniform='seats')
        for i in range(self.state['player_count']):
            panel = tk.Frame(seats, bg=self.PANEL, padx=10, pady=10)
            panel.grid(row=i//columns, column=i%columns, sticky='nsew', padx=4, pady=4)
            self.label(panel, f'PLAYER {i+1}', 9, self.MUTED, True).pack(anchor='w')
            name = self.label(panel, '', 12, bold=True); name.pack(anchor='w', pady=3)
            status = self.label(panel, '', 9, self.MUTED); status.pack(anchor='w')
            self.seat_labels.append((name, status))
        footer = tk.Frame(main, bg=self.BG)
        footer.pack(fill='x')
        self.ready_button = self.button(footer, 'Ready to play', self.toggle_ready, large=True)
        self.ready_button.pack(side='left')
        self.button(footer, 'Leave room', self.leave, secondary=True).pack(side='left', padx=10)
        self.room_status = self.label(main, '', 10, self.MUTED, wraplength=610, justify='left')
        self.room_status.pack(anchor='w', pady=12)

    def copy_invite(self):
        self.clipboard_clear()
        self.clipboard_append(self.server.code)
        self.room_status.configure(text='Lobby code copied. Send it to your friends with the latest game ZIP.')

    def update_room(self):
        settings = self.state['settings']
        if self.server:
            board = self.state['board_settings']
            changed = (self.player_count.get(), self.starting_cards.get(), self.target_score.get(), self.uno_mode.get(), self.game_kind.get(), self.three_rolls.get(), self.home_jumping.get()) != (
                self.state['player_count'], settings['starting_cards'], settings['target_score'], settings.get('uno_mode','classic'), self.state['game_kind'], board['three_rolls'], board['home_jumping'])
            self.player_count.set(self.state['player_count'])
            self.starting_cards.set(settings['starting_cards'])
            self.target_score.set(settings['target_score'])
            self.uno_mode.set(settings.get('uno_mode','classic'))
            self.game_kind.set(self.state['game_kind']); self.three_rolls.set(board['three_rolls']); self.home_jumping.set(board['home_jumping'])
            if changed: self.save_preferences()
        mode = 'Extreme UNO' if settings.get('uno_mode')=='extreme' else 'Classic UNO' if (settings['starting_cards'], settings['target_score']) == (7, 500) else 'Custom rules'
        self.room_settings_label.configure(text=f'{mode} · {settings["starting_cards"]} cards · {settings["target_score"]} points')
        if self.state.get('game_kind') == 'maedn':
            board = self.state['board_settings']
            self.room_settings_label.configure(text='Mensch ärgere dich nicht\n'+
                ('3 attempts' if board['three_rolls'] else '1 attempt')+' · Home jumping '+('on' if board['home_jumping'] else 'off'))
        connected = sum(self.state['connected'])
        ready = sum(r and c for r, c in zip(self.state['ready'], self.state['connected']))
        self.room_heading.configure(text=f'{connected}/{self.state["player_count"]} connected · {ready} ready · Everyone must join and choose Ready to start.')
        for i, (name, status) in enumerate(self.seat_labels):
            name.configure(text=self.short_name(i, 8 if i == self.seat else 11) + (' · You' if i == self.seat else ''))
            status.configure(text='Ready ✓' if self.state['connected'][i] and self.state['ready'][i] else 'Not ready yet' if self.state['connected'][i] else 'Waiting to join',
                             fg=self.GOLD if self.state['ready'][i] else self.MUTED)
        self.ready_button.configure(text='Cancel ready' if self.state['ready'][self.seat] else 'Ready to play',
                                    state='normal' if self.linked() and not self.pending else 'disabled')
        self.room_status.configure(text=self.error_text or (self.display_note(self.state['event']) if self.linked() else 'Connection lost. Keep the host app open; reconnecting automatically.'))

    def toggle_ready(self):
        if self.state and self.send_command({'type': 'ready', 'ready': not self.state['ready'][self.seat],
                                             'settings_version': self.state.get('settings_version', 1)}):
            self.update_view()

    def send_command(self, message):
        if self.pending or not self.linked(): return False
        self.request_serial += 1
        if self.client.send(dict(message, request=self.request_serial)):
            self.pending_request = self.request_serial
            self.pending = True
            return True
        self.error_text = 'Could not send your choice. Please try again once connected.'
        self.error_until = time.monotonic()+5
        self.update_view()
        return False

    def build_table(self):
        self.table_top = tk.Frame(self.body, bg=self.PANEL, padx=14, pady=4)
        self.table_top.pack(fill='x', pady=(0, 12))
        self.score_labels = []
        columns = min(3, self.state['player_count'])
        for column in range(columns):
            self.table_top.columnconfigure(column, weight=1, uniform='scores')
        for i in range(self.state['player_count']):
            lab = self.label(self.table_top, '', 10, bold=True, anchor='w')
            lab.grid(row=i//columns, column=i%columns, sticky='ew', padx=5, pady=3)
            self.score_labels.append(lab)
        stage = tk.Frame(self.body, bg=self.BG)
        stage.pack(fill='both', expand=True)
        self.build_chat(stage)
        left = tk.Frame(stage, bg=self.BG)
        left.pack(side='left', fill='both', expand=True)
        self.turn_panel = tk.Frame(left, bg=self.PANEL, padx=14, pady=10)
        self.turn_panel.pack(fill='x', pady=(0, 6))
        self.turn_label = self.label(self.turn_panel, '', 22, self.GOLD, True, anchor='w')
        self.turn_label.pack(fill='x')
        self.phase_label = self.label(self.turn_panel, '', 10, self.MUTED, anchor='w', justify='left')
        self.phase_label.pack(fill='x', pady=(3, 0))
        self.banner = self.label(left, '', 10, self.MUTED, anchor='w', justify='left')
        self.banner.pack(fill='x', pady=(0, 6))
        left.bind('<Configure>', lambda e: (self.phase_label.configure(wraplength=max(200, e.width-32)),
                                           self.banner.configure(wraplength=max(200, e.width-8))))
        # Pack the controls first at the bottom so they stay reachable on small windows.
        pages = tk.Frame(left, bg=self.BG)
        pages.pack(side='bottom', fill='x', pady=(6, 0))
        self.prev_button = self.button(pages, '‹', lambda: self.change_page(-1), secondary=True)
        self.prev_button.configure(pady=5)
        self.prev_button.pack(side='left')
        self.page_label = self.label(pages, '', 10, self.MUTED)
        self.page_label.pack(side='left', padx=12)
        self.next_button = self.button(pages, '›', lambda: self.change_page(1), secondary=True)
        self.next_button.configure(pady=5)
        self.next_button.pack(side='left')
        self.sort_button = self.button(pages, '', self.toggle_hand_order, secondary=True)
        self.sort_button.configure(pady=5)
        self.sort_button.pack(side='right')
        self.controls = tk.Frame(left, bg=self.BG)
        self.controls.pack(side='bottom', fill='x', pady=(10, 0))
        for column in range(3): self.controls.columnconfigure(column, weight=1, uniform='actions')
        self.canvas = tk.Canvas(left, bg=self.BG, highlightthickness=0, takefocus=True)
        self.canvas.design = self.active_design()
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Configure>', lambda e: self.draw())
        self.canvas.bind('<Button-1>', self.click)
        self.canvas.bind('<Motion>', self.on_hover)
        self.canvas.bind('<Leave>', lambda e: self.set_hover(None))

    def actions(self):
        if not self.can_play() or not self.state.get('game'):
            return []
        return [tuple(a) for a in self.state['game']['actions']]

    def short_name(self, seat, limit=14):
        name = self.state['names'][seat]
        return name if len(name) <= limit else name[:limit-1] + '…'

    def update_table(self):
        u = self.state['game']
        for i, label in enumerate(self.score_labels):
            active = u['turn'] == i and not u['done'] and self.can_play()
            label.configure(text=('▶ ' if active else '')+f'P{i+1}  {self.short_name(i, 11)}'+(' (you)' if i == self.seat else '')+f'  ·  {u["points"][i]} pts',
                            fg=self.GOLD if active else self.TEXT)
        paused = not self.linked() or not all(self.state['connected'])
        if paused:
            title = 'GAME PAUSED'
            missing = ', '.join(self.short_name(i) for i, connected in enumerate(self.state['connected']) if not connected)
            hint = 'Reconnecting to the host…' if not self.linked() else f'Waiting for {missing} to reconnect.'
        elif u['done']:
            title = 'YOU WON THE ROUND!' if u['winner'] == self.seat else self.short_name(u['winner'], 16)+' wins!'
            hint = (f'Match complete · First to {u["target_score"]}' if max(u['points']) >= u['target_score'] else f'+{u["round_points"]} points this round')+' · Choose Ready below.'
        else:
            mine = u['turn'] == self.seat
            title = f'YOUR TURN · P{self.seat+1}' if mine else f'P{u["turn"]+1} · {self.short_name(u["turn"], 16)}’s turn'
            hint = ({'ready': 'Play a highlighted card, or draw a card below.', 'drawn': 'Play your new card, or choose Keep & pass.',
                     'draw_stack': f'Stack a +2 card or draw all {u.get("stack_penalty",0)} cards.',
                     'challenge': 'Take four cards, or challenge the +4.', 'audit': 'Review the revealed hand, then choose Continue.',
                     'opening_color': 'Choose a color on the table to start.'}.get(u['phase'], '') if mine else
                    f'Waiting for {self.short_name(u["turn"], 20)}. You can chat while they play.')
            if mine and u['phase'] == 'drawn' and u['drawn_index'] is not None:
                color, value = u['hand'][u['drawn_index']]
                hint = f'You drew {color} {value}. Play that card, or choose Keep & pass.'
            missed = u.get('missed_uno')
            if missed is not None:
                hint += (' Call UNO now before you are caught!' if missed == self.seat else
                         f' {self.short_name(missed, 12)} forgot UNO — you can catch it!')
        if self.pending and not paused:
            hint = 'Sending your choice to the host…'
        emphasized = not paused and not u['done'] and u['turn'] == self.seat
        panel_color = self.GREEN if emphasized else self.PANEL
        self.turn_panel.configure(bg=panel_color)
        self.turn_label.configure(text=title, bg=panel_color, fg=self.BUTTON_TEXT if emphasized else self.GOLD)
        self.phase_label.configure(text=hint, bg=panel_color, fg=self.BUTTON_TEXT if emphasized else self.MUTED)
        self.title(('Your turn! · ' if emphasized else '')+'UNO Together · Room '+self.state['room'])
        banner = self.error_text or ('Waiting for all players. Your hand is saved on the host.' if paused else
                                    self.display_note(u['note']))
        self.banner.configure(text=banner, fg=self.ERROR if paused or self.error_text else self.MUTED)
        for child in self.controls.winfo_children():
            child.destroy()
        if u['done']:
            ready = self.state['ready'][self.seat]
            label = 'Cancel ready' if ready else 'Ready for new match' if max(u['points']) >= u['target_score'] else 'Ready for next round'
            button = self.button(self.controls, label, self.toggle_ready, large=True)
            button.grid(row=0, column=0, columnspan=2, sticky='ew', padx=(0, 8))
            button.configure(state='normal' if self.linked() and not self.pending else 'disabled')
            self.label(self.controls, f'{sum(self.state["ready"])}/{self.state["player_count"]} ready\nEveryone chooses Ready.', 10, self.MUTED).grid(row=0, column=2, sticky='ew')
        else:
            labels = {'draw': 'Draw card [D]', 'pass': 'Keep & pass [P]', 'uno': 'UNO! [U]',
                      'uno_late': 'UNO! [U]', 'catch': 'Catch UNO!', 'accept': 'Take four',
                      'challenge': 'Challenge +4', 'continue': 'Continue',
                      'take_penalty': f'Draw stack ({u.get("stack_penalty",0)})'}
            # Keep useful controls visible while waiting, but disabled.
            visible = [tuple(a) for a in u['actions'] if a[0] in labels]
            if not any(a[0] in ('draw', 'pass', 'accept', 'continue', 'take_penalty') for a in visible): visible.insert(0, ('draw',))
            if not any(a[0] in ('uno', 'uno_late', 'challenge') for a in visible): visible.append(('uno',))
            for index, action in enumerate(visible):
                button = self.button(self.controls, labels[action[0]], lambda a=action: self.send_action(a),
                                     danger=action[0] in ('uno', 'uno_late', 'catch'), large=True)
                button.configure(padx=8)
                button.grid(row=index//3, column=index%3, sticky='ew', padx=(0, 7), pady=(0, 2))
                button.configure(state='normal' if action in self.actions() else 'disabled')
        self.draw()

    def send_action(self, action):
        if tuple(action) not in self.actions():
            return
        if self.send_command({'type': 'action', 'revision': self.state['revision'], 'action': list(action)}):
            self.wild = None
            self.update_view()

    def shortcut(self, kind):
        if self.scene != 'table' or isinstance(self.focus_get(), (tk.Entry, tk.Text)) or self.wild is not None:
            return
        options = ('uno', 'uno_late') if kind == 'uno' else (kind,)
        for action in self.actions():
            if action[0] in options:
                self.send_action(action)
                return

    def change_page(self, amount):
        self.page += amount
        self.hover = None
        self.draw()

    def hand_order(self, game):
        indices = list(range(len(game['hand'])))
        if self.sorted_hand.get():
            colors = (*UNO_COLORS, 'Wild')
            values = (*map(str, range(10)), 'Skip', 'Reverse', '+2', 'Wild', '+4')
            indices.sort(key=lambda i: (colors.index(game['hand'][i][0]), values.index(game['hand'][i][1]), i))
        return indices

    def toggle_hand_order(self):
        self.sorted_hand.set(not self.sorted_hand.get())
        self.page = 0
        self.hover = None
        if self.state and self.state['game']:
            game = self.state['game']
            if game['drawn_index'] is not None: self.page = self.hand_order(game).index(game['drawn_index'])//7
        self.save_preferences()
        self.draw()

    def cancel_wild(self):
        self.wild = None
        self.draw()

    def set_hover(self, hover):
        if self.hover != hover:
            self.hover = hover
            self.draw()

    def on_hover(self, event):
        hover = next((action for x1, y1, x2, y2, action in reversed(self.hits)
                      if x1 <= event.x <= x2 and y1 <= event.y <= y2), None)
        self.canvas.configure(cursor='hand2' if hover is not None else '')
        self.set_hover(hover)

    def click(self, event):
        self.canvas.focus_set()
        hit = next((a for x1, y1, x2, y2, a in reversed(self.hits) if x1 <= event.x <= x2 and y1 <= event.y <= y2), None)
        if hit is None:
            return
        if hit[0] == 'wild':
            self.wild = hit[1]
            self.hover = None
            self.draw()
        elif hit[0] == 'cancel':
            self.cancel_wild()
        else:
            self.send_action(hit)

    def text(self, x, y, text, size=12, fill=None, **options):
        return self.canvas.create_text(x, y, text=text, fill=fill or self.TEXT,
                                       font=('Segoe UI', max(5, int(size)), 'bold'), **options)

    def draw(self):
        if self.scene == 'maedn':
            self.draw_maedn()
            return
        if self.scene != 'table' or not self.state or not hasattr(self, 'canvas') or not self.canvas.winfo_exists():
            return
        c, u = self.canvas, self.state['game']
        c.delete('all')
        self.hits = []
        width, height = max(100, c.winfo_width()), max(100, c.winfo_height())
        rounded(c, 2, 2, width-2, height-2, 22, fill=self.BOARD, outline=self.BORDER, width=2)
        decorate_table(c, width, height, self.active_design(), THEMES[self.active_design()])
        opponents = [(self.seat + i) % self.state['player_count'] for i in range(1, self.state['player_count'])]
        self.opponent_centers = {}
        tile_w = (width - 20) / len(opponents)
        for position, opponent in enumerate(opponents):
            x = 10 + position * tile_w
            cx = x + tile_w / 2
            self.opponent_centers[opponent] = cx
            active = u['turn'] == opponent and not u['done'] and self.linked() and all(self.state['connected'])
            connected = self.state['connected'][opponent]
            rounded(c, x+3, 8, x+tile_w-3, 71, 8, fill=self.ACTIVE if active else self.TILE,
                    outline=self.GOLD if active else self.BORDER, width=3 if active else 1)
            self.text(cx, 22, f'P{opponent+1} · {self.short_name(opponent, 7 if len(opponents)>3 else 16)}',
                      9, self.GOLD if active else self.TEXT)
            count = u['counts'][opponent]
            caption = 'Offline' if not connected else 'UNO! · 1 card' if count == 1 else f'{count} cards'
            self.text(cx, 39, caption, 8, self.ERROR if not connected else self.MUTED)
            if active:
                self.text(cx, 58, '▶ PLAYING', 8, self.GOLD)
            else:
                backs = min(4, count)
                for i in range(backs):
                    paint_uno_card(c, cx-((backs-1)*10+10)/2+i*10, 50, 10, 15)
        direction = 'CLOCKWISE →' if u['direction'] == 1 else '← COUNTERCLOCKWISE'
        self.text(width/2, 82, f'ROUND {u.get("round_number", 1)}  ·  {direction}  ·  YOU ARE P{self.seat+1}  ·  FIRST TO {u["target_score"]}', 8, self.MUTED)
        shown = u['audit']['hand'] if u['audit'] else u['hand']
        order = list(range(len(shown))) if u['audit'] else self.hand_order(u)
        self.sort_button.configure(text='Hand: by color' if self.sorted_hand.get() else 'Hand: as dealt',
                                   state='disabled' if u['audit'] or u['done'] else 'normal')
        pages = max(1, (len(shown)+6)//7)
        self.page = max(0, min(self.page, pages-1))
        self.prev_button.configure(state='normal' if self.page > 0 and not u['done'] else 'disabled')
        self.next_button.configure(state='normal' if self.page+1 < pages and not u['done'] else 'disabled')
        self.page_label.configure(text=f'Page {self.page+1} / {pages}' if pages > 1 else f'{len(shown)} cards')
        hand_w = max(20, min(94, (width-40)/7-7, (height*.27)*.67))
        hand_h = hand_w/.67
        hand_y = height-hand_h-20
        pile_h = max(32, min(140, hand_y-170))
        pile_w = pile_h*.67
        pile_y = 94
        deck_x, discard_x = width/2-pile_w-23, width/2+23
        for offset in (6, 3, 0):
            paint_uno_card(c, deck_x-offset*.3, pile_y+offset, pile_w, pile_h)
        move = self.animation[1] if self.animation else None
        age = time.monotonic()-self.animation[0] if self.animation else 1
        animating = bool(self.animation and self.motion.get() and age < .38)
        paint_uno_card(c, discard_x, pile_y, pile_w, pile_h, tuple(u['top']))
        self.text(deck_x+pile_w/2, pile_y+pile_h+17, f'DRAW  ·  {u["deck_count"]}', 9, self.MUTED)
        self.text(discard_x+pile_w/2, pile_y+pile_h+17, 'DISCARD', 9, self.MUTED)
        c.create_oval(width/2-7, pile_y+pile_h*.45, width/2+7, pile_y+pile_h*.45+14,
                      fill=COLORS.get(u['color'], '#777777'), outline='#f7f2d5', width=2)
        self.text(width/2, pile_y+pile_h+36, f'{u["color"].upper()} IS ACTIVE', 10, self.GOLD)
        actions = self.actions()
        if ('draw',) in actions:
            self.hits.append((deck_x, pile_y, deck_x+pile_w, pile_y+pile_h, ('draw',)))
        if u['audit']:
            audit = u['audit']
            label = f'REVEALED: {self.state["names"][audit["seat"]]}  ·  Previous color {audit["color"]}'
        else:
            label = 'YOUR HAND  ·  '+('UNO called ✓' if u['called'] else 'Call UNO before playing down to one card')
        self.text(width/2, hand_y-18, label, 9, self.TEXT)
        visible = order[self.page*7:(self.page+1)*7]
        total = len(visible)*(hand_w+7)-7
        for n, i in enumerate(visible):
            card = shown[i]
            plays = [a for a in actions if a[0] == 'play' and a[1] == i] if not u['audit'] else []
            hit = ('wild', i) if plays and card[0] == 'Wild' else plays[0] if plays else None
            x = (width-total)/2+n*(hand_w+7)
            y = hand_y-(11 if hit and self.hover == hit else 0)
            paint_uno_card(c, x, y, hand_w, hand_h, tuple(card), bool(plays))
            if hit:
                self.hits.append((x, y, x+hand_w, y+hand_h, hit))
            if u['drawn_index'] == i and u['phase'] == 'drawn' and not u['audit']:
                self.text(x+hand_w/2, y+hand_h+12, 'JUST DRAWN', 7, self.GOLD)
        if animating and move:
            t = min(1, age/.38); ease = 1-(1-t)**3
            if move['kind'] == 'play' and move['card']:
                sx = (width/2 if move['seat'] == self.seat else self.opponent_centers[move['seat']])-hand_w/2
                sy = hand_y if move['seat'] == self.seat else 45
                paint_uno_card(c, sx+(discard_x-sx)*ease, sy+(pile_y-sy)*ease-math.sin(t*math.pi)*24,
                               hand_w+(pile_w-hand_w)*ease, hand_h+(pile_h-hand_h)*ease, tuple(move['card']))
            elif move['kind'] == 'draw':
                ex = width/2 if move['seat'] == self.seat else self.opponent_centers[move['seat']]
                ey = hand_y if move['seat'] == self.seat else 45
                paint_uno_card(c, deck_x+(ex-deck_x)*ease, pile_y+(ey-pile_y)*ease, pile_w, pile_h)
        choose_open = u['phase'] == 'opening_color' and u['turn'] == self.seat and self.can_play()
        if u['done'] and u.get('round_breakdown') is not None:
            self.draw_round_summary(width, height)
        if self.wild is not None or choose_open:
            self.draw_color_picker(width, height, choose_open)

    def draw_round_summary(self, width, height):
        u = self.state['game']
        self.hits = []
        box_w, box_h = min(width-24, 590), min(height-16, 330)
        x, y = (width-box_w)/2, (height-box_h)/2
        rounded(self.canvas, x, y, x+box_w, y+box_h, 14, fill=self.PANEL, outline=self.GOLD, width=2)
        self.text(width/2, y+25, f'ROUND {u.get("round_number", 1)} · SCORES', 15, self.GOLD)
        self.text(width/2, y+51, 'Points from cards left in each hand', 10, self.MUTED)
        step = min(29, (box_h-132)/self.state['player_count'])
        for i, points in enumerate(u['round_breakdown']):
            line_y = y+77+i*step
            self.text(x+20, line_y, f'P{i+1} · {self.short_name(i, 18)}', 11, anchor='w')
            self.text(x+box_w-20, line_y, 'WINNER' if i == u['winner'] else f'{u["counts"][i]} cards · {points} pts',
                      10, self.GOLD if i == u['winner'] else self.MUTED, anchor='e')
        self.text(width/2, y+box_h-40, f'{self.short_name(u["winner"], 18)} earns {u["round_points"]} points', 13, self.GOLD)
        self.text(width/2, y+box_h-17, 'Choose Ready below when you want to continue.', 10, self.MUTED)

    def draw_color_picker(self, width, height, opening):
        self.hits = []
        size = min(width-24, 420)
        x, y = (width-size)/2, max(12, (height-182)/2)
        rounded(self.canvas, x, y, x+size, y+182, 16, fill='#f9f5e9', outline='#b8cdb0', width=2)
        self.text(width/2, y+27, 'CHOOSE THE NEXT COLOR', 14, '#183c2e')
        for i, color in enumerate(UNO_COLORS):
            bx = x+15+i*(size-25)/4
            bw = (size-25)/4-6
            rounded(self.canvas, bx, y+56, bx+bw, y+113, 8, fill=COLORS[color], outline='')
            self.text(bx+bw/2, y+84, color, 11, 'white')
            action = ('color', color) if opening else ('play', self.wild, color)
            if action in self.actions():
                self.hits.append((bx, y+56, bx+bw, y+113, action))
        hand = self.state['game']['hand']
        bluff = not opening and hand[self.wild][1] == '+4' and any(card[0] == self.state['game']['color'] for card in hand)
        self.text(width/2, y+134, 'Matching color in your hand: +4 can be challenged.' if bluff else 'The next player must match your chosen color.', 9, '#537064')
        if not opening:
            self.text(width/2, y+161, 'Cancel  ·  Esc', 10, '#315b45')
            self.hits.append((width/2-70, y+148, width/2+70, y+178, ('cancel',)))

    def ensure_frame(self):
        if self.animation_job is None:
            self.animation_job = self.after(16, self.frame)

    def frame(self):
        self.animation_job = None
        if self.animation and time.monotonic()-self.animation[0] < .38:
            self.draw()
            self.ensure_frame()
        else:
            self.animation = None
            self.draw()

    def show_rules(self):
        if (self.state.get('game_kind') if self.state else self.game_kind.get()) == 'maedn':
            self.show_maedn_rules()
            return
        window = tk.Toplevel(self)
        window.title('How to play · UNO Together')
        window.geometry('670x650')
        window.configure(bg=self.PANEL)
        text = tk.Text(window, bg=self.PANEL, fg=self.TEXT, font=('Segoe UI', 11), wrap='word',
                       padx=24, pady=22, relief='flat', spacing3=10)
        text.pack(fill='both', expand=True)
        text.insert('1.0', '''2–6 PLAYERS. ONE PRIVATE TABLE.
Every PC runs the latest copy of this app. The host uses Host settings to choose the player count, starting cards and score target, then creates a room. Friends enter their name and the six-digit lobby code; the connection address is built in. All chosen seats must be connected and Ready before dealing. Keep the host app open. This copy uses a local host address; see Connection help for different networks.

RULES & WAITING-ROOM SETTINGS
The defaults are 108 cards, seven cards per player and first to 500 points. Classic has no stacking or jump-in. Optional Extreme mode lets a player stack a +2 on a +2; the next player may stack another +2 or draw the accumulated total and lose their turn. +4 cards do not stack. The host chooses the mode before starting; it is shown at the table. Before the first deal, the host can change player count, starting cards, score target, mode and room design in Host settings. Apply settings resets Ready votes. Connected players cannot be removed by reducing seats. Settings lock once the match starts.

CHOOSE YOUR DESIGN
Open Settings to choose from the room designs, including the warm Larissa kitchen theme with tile, herbs and a plate-and-utensil card back. Your selected room design is shared with everyone. Card colors still mean the same thing. Settings also controls animations, optional gentle sounds, hints and fullscreen.

PLAY A CARD
The large YOUR TURN banner tells you when to play. Otherwise it names the active player, whose player tile is highlighted. Match the active color, number, or symbol. Glowing borders and checkmarks identify playable cards. Use the large buttons at the bottom left to draw, call UNO or pass. You may play only the card you just drew, or keep it and pass.

Use Sorted by color / As dealt below your cards to change their display order. Drawing a playable card opens its page and marks it NEW.

ROOM CHAT
Use Chat on the right, type in the box and press Enter or Send. Everyone in the room can read it. Activity shows recent game events; Chat counts new messages while Activity is open. Messages have a 240-character limit. The latest 80 messages are kept in memory until the host closes the room. Reconnects restore history. Rejected messages keep their draft; wait a few seconds if chat is moving too fast.

CALL UNO
With two cards, click UNO! before playing one. If you forget, any other player can Catch UNO before the next normal action: draw two. You can also call UNO late before being caught. With two players, catching is allowed even when a Skip leaves the same player on turn.

ACTION CARDS
Skip skips the next player. Reverse changes direction; with two players it acts like Skip. Draw Two makes the next player draw two and miss their turn in Classic. In Extreme, Draw Two can stack on another Draw Two. Wild lets you choose the next color. Player numbers show seat order; the table shows the direction of play.

WILD DRAW FOUR
A +4 is lawful only if you hold no card of the active color. The next player may accept four and skip, or challenge. A successful challenge makes the offender draw four; the challenger keeps the turn. An unsuccessful challenge makes the challenger draw six and skip. The challenged hand is shown only to the challenger.

WIN THE MATCH
Empty your hand to win a round and score all opponents’ cards: numbers at face value, colored actions 20, Wilds 50. The score panel shows each opponent’s contribution. Everyone selects Ready for the next round. The first dealer is chosen by the highest number drawn, with actions counting as zero and ties redrawn. The dealer moves one seat clockwise between rounds. Reach the host’s score target to win; 500 is the classic default. A final +2/+4 applies its penalty and ends the round immediately before scoring.

CONNECTIONS
A dropped connection pauses play until everyone is back. Reconnecting resumes the same hand while the host remains open. Guests can use Resume last room if the app was closed. A saved seat may wait briefly for its old connection to time out. Before the first deal the host can change capacity; after play begins, changing group size needs a new room. Leaving as host closes the room. LAN play needs no account; Tailscale requires separate setup for different networks.

SHORTCUTS
1–7: choose a visible card · D: draw · U: call UNO · P: keep and pass. In the Wild picker, R/Y/G/B chooses Red/Yellow/Green/Blue; Esc cancels. F11 toggles fullscreen. Game shortcuts are inactive while typing or selecting chat text.
''')
        text.configure(state='disabled')
        self.button(window, 'Back to the table', window.destroy).pack(pady=(0, 15))

    def show_connection_help(self):
        window = tk.Toplevel(self)
        window.title('Connecting with friends · UNO Together')
        window.geometry('690x660')
        window.configure(bg=self.PANEL)
        content = tk.Text(window, bg=self.PANEL, fg=self.TEXT, font=('Segoe UI', 11), wrap='word',
                          padx=24, pady=20, relief='flat', spacing3=10)
        content.pack(fill='both', expand=True)
        content.insert('1.0', f'''JOIN WITH A LOBBY CODE
This copy is fixed to {DEFAULT_HOST}, port {DEFAULT_PORT}. Enter your name and the current six-digit lobby code, then Join room. Friends do not type an address or port. Re-entering the same room code automatically resumes your saved seat.

ON THE SAME WI-FI / LAN
Keep the host room open and both PCs on the same home network. The host PC must still have the address built into this copy. Creating a new room generates a new code.

ON DIFFERENT NETWORKS
192.168.178.193 is a local address. This exact copy cannot reach it from a different network. Installing Tailscale alone does not change that address into an internet address.

1. Everyone installs Tailscale on their PC and signs in to their own account.
2. The host opens Tailscale’s admin console, finds their PC under Machines, and chooses Share → Copy invite link. Share a link with each friend (or choose a reusable link). They accept the invitation.
3. The host needs a game copy configured with the shared PC’s Tailscale IPv4 address (usually 100.x.x.x) or full Tailscale name. Everyone uses that updated copy. The developer can replace the fixed host address once you supply it.
4. With that version, keep Tailscale connected, open the host room and join using only the current lobby code. Every player selects Ready.

STILL CANNOT CONNECT?
Use this same updated UNO version on every PC. Check the current code. Allow the UNO/Python app through Windows Firewall on the network being used. The fixed port is {DEFAULT_PORT}. Guest Wi-Fi can prevent local PCs from connecting to each other. See the detailed Friends’ guide included in the folder.

Tailscale is a separate app and requires setup. UNO does not install or configure it automatically.
''')
        content.configure(state='disabled')
        buttons = tk.Frame(window, bg=self.PANEL)
        buttons.pack(fill='x', padx=24, pady=(0, 18))
        self.button(buttons, 'Open Tailscale setup guide', lambda: webbrowser.open(
            'https://tailscale.com/docs/use-cases/personal-or-at-home-use/share-private-game-server')).pack(side='left')
        self.button(buttons, 'Close', window.destroy, secondary=True).pack(side='right')

    def leave(self, confirm=True, preserve_error=False):
        if confirm and self.state and self.state.get('game') and not self.state['game']['done']:
            if not messagebox.askyesno('Leave the table?', 'Close this room for everyone?' if self.server else 'Leave this game? You can resume while the host stays open.', parent=self):
                return
        if self.client:
            self.client.close()
        if self.server:
            self.server.close()
        self.client = self.server = None
        self.state = None
        self.seat = None
        self.animation = None
        self.pending = False
        self.pending_request = None
        self.history = []
        self.chat_messages = []
        self.chat_draft.set('')
        self.chat_unread = 0
        self.chat_feedback = ''
        self.chat_pending = None
        self.chat_tab = 'chat'
        self.last_move_revision = -1
        if not preserve_error:
            self.error_text = ''
        self.show_home()

    def close(self):
        self.save_preferences()
        self.closing = True
        for job in (self.poll_job, self.animation_job):
            if job is not None:
                self.after_cancel(job)
        if self.client:
            self.client.close()
        if self.server:
            self.server.close()
        self.destroy()


from playroom_ui import PlayroomUI


class UnoApp(PlayroomUI, CoreApp):
    """The network/rules core with the Playroom presentation layer."""


if __name__ == '__main__':
    try:
        app = UnoApp()
        app.withdraw()
        app.after(150, app.deiconify)
        app.mainloop()
    except Exception:
        import traceback
        report = traceback.format_exc()
        try:
            (ROOT/'uno_crash.log').write_text(report, encoding='utf-8')
        except OSError:
            pass
        messagebox.showerror('UNO Together', 'The app could not start. Details were saved to uno_crash.log.')
        raise
