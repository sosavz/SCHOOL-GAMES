"""Owner tools and a chat-code fun panel; authority is always checked by the server."""
import math
import time
import tkinter as tk


class HostControls:
    def can_play(self):
        return super().can_play() and not self.state.get('paused', False)

    def update_view(self):
        super().update_view()
        if not self.state: return
        if hasattr(self, 'manage_button'):
            if self.seat == 0:
                self.manage_button.pack(side='right', padx=(7,0))
            else: self.manage_button.pack_forget()
        if self.state.get('paused') and self.state.get('game'):
            self.turn_panel.configure(bg=self.PANEL)
            self.turn_label.configure(text='PAUSED BY THE HOST', bg=self.PANEL, fg=self.GOLD)
            self.phase_label.configure(text='Take a break. The host can resume from Host controls.', bg=self.PANEL, fg=self.MUTED)
            self.guide_title.configure(text='Time for a little break.')
            self.guide_note.configure(text='Your game is saved here. Chat stays open while everyone waits.')
            self.title('Paused · Playroom')
        if self.state.get('next_die') is not None and self.state.get('game') and not self.state.get('paused'):
            self.banner.configure(text=f'Fun mode · The next dice roll is set to {self.state["next_die"]}.')
        if self.state.get('muted', [False]*self.state['player_count'])[self.seat]:
            self.chat_status.configure(text='The host muted your chat. You can still read and play.')
        serial=self.state.get('party_serial',0)
        if serial != getattr(self,'seen_party',0):
            self.seen_party=serial
            if serial: self.start_party(self.state.get('party_effect','confetti'))

    def send_chat(self,event=None):
        if self.chat_draft.get().strip().lower() == '/party':
            self.chat_draft.set(''); self.show_fun_menu(); return 'break'
        return super().send_chat(event)

    def manage(self,command,revision=None,**payload):
        if not self.state or self.seat != 0: return False
        return self.send_command(dict(type='manage',command=command,
            revision=self.state['revision'] if revision is None else revision,**payload))

    def confirm_management(self,title,note,command,parent=None,**payload):
        revision=self.state['revision']
        dialog=tk.Toplevel(self); dialog.title(title); dialog.geometry('560x300')
        dialog.configure(bg=self.BG); dialog.transient(parent or self); dialog.grab_set()
        frame=tk.Frame(dialog,bg=self.BG,padx=25,pady=22); frame.pack(fill='both',expand=True)
        self.label(frame,title,23,self.TEXT,True).pack(anchor='w')
        self.label(frame,note,12,self.MUTED,wraplength=505,justify='left').pack(anchor='w',pady=18)
        row=tk.Frame(frame,bg=self.BG); row.pack(side='bottom',fill='x')
        def close():
            dialog.destroy()
            if parent and parent.winfo_exists(): parent.grab_set()
        def apply():
            self.manage(command,revision,**payload); close()
        self.button(row,'Cancel',close,secondary=True).pack(side='left')
        self.button(row,title,apply,large=True).pack(side='right')
        dialog.bind('<Escape>',lambda e:close())

    def show_host_controls(self):
        if not self.state or self.seat != 0: return
        existing=getattr(self,'host_panel',None)
        if existing is not None and existing.winfo_exists(): existing.lift(); return
        window=tk.Toplevel(self); self.host_panel=window
        window.title('Host controls · Playroom'); window.geometry('760x660'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=22,pady=18); frame.pack(fill='both',expand=True)
        last=[None]; job=[None]
        def render():
            job[0]=None
            if not window.winfo_exists(): return
            if not self.state or self.seat != 0: window.destroy(); return
            key=(self.state['revision'],self.pending,self.linked(),self.error_text)
            if key != last[0]:
                last[0]=key
                for child in frame.winfo_children(): child.destroy()
                game=self.state['game']; running=game is not None and not game['done']
                self.label(frame,'You’re the host.',25,self.TEXT,True).pack(anchor='w')
                status='Waiting room' if not game else 'Paused by you' if self.state.get('paused') else 'Game finished' if game['done'] else 'Game in progress'
                self.label(frame,status+' · Changes are shared with everyone.',10,self.MUTED).pack(anchor='w',pady=(3,10))
                enabled=self.linked() and not self.pending
                def button(parent,text,fn,available=True):
                    result=self.button(parent,text,fn,secondary=True)
                    result.configure(state='normal' if enabled and available else 'disabled',pady=6)
                    return result
                top=tk.Frame(frame,bg=self.BG); top.pack(fill='x')
                locked=self.state.get('join_locked',False)
                button(top,'Unlock new joins' if locked else 'Lock new joins',lambda:self.manage('lock',value=not locked)).pack(side='left')
                button(top,'Game settings',self.show_host_settings,not game).pack(side='left',padx=8)
                button(top,'Remove open seats',lambda:self.manage('compact'),not game and not all(self.state.get('occupied',[True]*self.state['player_count']))).pack(side='left')
                self.label(frame,'PLAYERS',10,self.MUTED,True).pack(anchor='w',pady=(14,5))
                occupied=self.state.get('occupied',[True]*self.state['player_count'])
                for seat,name in enumerate(self.state['names']):
                    row=tk.Frame(frame,bg=self.PANEL,padx=10,pady=1); row.pack(fill='x',pady=2)
                    muted=self.state.get('muted',[False]*self.state['player_count'])[seat]
                    state='Host' if seat==0 else 'Open seat' if not occupied[seat] else 'Connected' if self.state['connected'][seat] else 'Offline · reserved'
                    if muted: state+=' · muted'
                    self.label(row,f'{seat+1}  {name[:20]}',11,self.TEXT,True,width=25,anchor='w').pack(side='left')
                    self.label(row,state,9,self.MUTED).pack(side='left')
                    if seat and occupied[seat]:
                        note='Remove this player and free their seat?'
                        if game: note+=' This ends the current game, resets scores and returns everyone to the lobby.'
                        button(row,'Kick',lambda s=seat,n=name,d=note:self.confirm_management('Kick '+n[:14]+'?',d,'kick',window,seat=s)).pack(side='right')
                        button(row,'Unmute' if muted else 'Mute',lambda s=seat,m=muted:self.manage('mute',seat=s,value=not m)).pack(side='right',padx=5)
                self.label(frame,'GAME CONTROLS',10,self.MUTED,True).pack(anchor='w',pady=(13,5))
                grid=tk.Frame(frame,bg=self.BG); grid.pack(fill='x')
                grid.columnconfigure(0,weight=1); grid.columnconfigure(1,weight=1)
                paused=self.state.get('paused',False)
                button(grid,'Resume game' if paused else 'Pause game',lambda:self.manage('pause',value=not paused),running).grid(row=0,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Restart round' if self.state['game_kind']=='uno' else 'Restart game',lambda:self.confirm_management('Restart?',
                    'Deal fresh cards and keep match scores.' if self.state['game_kind']=='uno' else 'Reset every pawn and roll for a new starter.', 'restart',window),running and all(self.state['connected'])).grid(row=0,column=1,sticky='ew',pady=3)
                button(grid,'New match · reset scores',lambda:self.confirm_management('New match?','Start immediately with everyone connected. All scores and game progress reset.','new_match',window),bool(game) and all(self.state['connected'])).grid(row=1,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Return everyone to lobby',lambda:self.confirm_management('Back to lobby?','End this game and reset scores. Keep the room code and chat, then change rules or players.','lobby',window),bool(game)).grid(row=1,column=1,sticky='ew',pady=3)
                self.label(frame,self.error_text or 'A kick is not a ban. Lock new joins to prevent rejoining with the code. Saved players can still reconnect.',9,self.ERROR if self.error_text else self.MUTED,wraplength=710,justify='left').pack(anchor='w',pady=8)
                self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
            job[0]=window.after(200,render)
        def cleanup(e):
            if e.widget is window and job[0]:
                window.after_cancel(job[0]); job[0]=None
        window.bind('<Destroy>',cleanup); window.bind('<Escape>',lambda e:window.destroy()); render()

    def show_fun_menu(self):
        if not self.state: return
        window=tk.Toplevel(self); window.title('Secret party menu'); window.geometry('570x580')
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=24,pady=20); frame.pack(fill='both',expand=True)
        self.label(frame,'You found the party! ★',24,self.GOLD,True).pack(anchor='w')
        host=self.seat==0
        self.label(frame,'Fun effects and host-only cheats. Everyone sees game-changing effects.',11,self.MUTED,wraplength=510,justify='left').pack(anchor='w',pady=(10,15))
        self.button(frame,'Confetti on my screen',self.start_party,large=True).pack(fill='x',pady=4)
        if host:
            self.button(frame,'Confetti for everyone',lambda:self.manage('party',effect='confetti'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Boo! Surprise the table',lambda:self.manage('party',effect='boo'),secondary=True).pack(fill='x',pady=4)
            if self.state['game_kind']=='uno':
                for label,effect in (('Give me a Wild','wild'),('Give me a +4','draw_four')):
                    self.button(frame,label,lambda v=effect:self.manage('party',effect=v),secondary=True).pack(fill='x',pady=4)
                self.label(frame,'Use on your UNO turn before drawing. Takes an existing card from the deck or discard pile.',10,self.MUTED,wraplength=510,justify='left').pack(pady=8)
            else:
                self.label(frame,'Choose the next dice roll (one use):',12,self.TEXT,True).pack(pady=(12,5))
                row=tk.Frame(frame,bg=self.BG); row.pack(fill='x')
                for n in range(1,7): self.button(row,str(n),lambda v=n:self.manage('party',effect='die',value=v),secondary=True).pack(side='left',fill='x',expand=True,padx=2)
        else:
            self.label(frame,'Only the host can change cards, dice or the whole table.',11,self.MUTED,wraplength=500).pack(pady=16)
        status=self.label(frame,'',10,self.ERROR,wraplength=510,justify='left'); status.pack(fill='x',pady=5)
        # Use the main polling loop only while the window exists; destroy cancels its timer.
        timer=[None]
        def tick():
            if not window.winfo_exists(): return
            if not self.state: window.destroy(); return
            status.configure(text=self.error_text); timer[0]=window.after(250,tick)
        window.bind('<Destroy>',lambda e:window.after_cancel(timer[0]) if e.widget is window and timer[0] else None)
        tick()
        self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
        window.bind('<Escape>',lambda e:window.destroy())

    def start_party(self,effect='confetti'):
        if not self.motion.get(): return
        self.local_party_effect=effect
        self.party_started=time.monotonic()
        if getattr(self,'party_job',None) is None: self.party_frame()

    def party_frame(self):
        self.party_job=None
        if self.closing: return
        if not self.motion.get() or time.monotonic()-self.party_started>=2.2:
            surface=self.party_surface()
            if surface is not None: surface.delete('party')
            return
        self.paint_party()
        self.party_job=self.after(20,self.party_frame)

    def paint_party(self):
        c=self.party_surface()
        if c is None: return
        c.delete('party')
        t=(time.monotonic()-getattr(self,'party_started',0))/2.2
        if not 0<=t<1 or not self.motion.get(): return
        w,h=c.winfo_width(),c.winfo_height()
        if getattr(self,'local_party_effect','confetti')=='boo':
            x,y=w/2,h/2+math.sin(t*12)*12
            c.create_oval(x-42,y-50,x+42,y+40,fill='white',outline='#514bcb',width=3,tags='party')
            for dx in (-15,15): c.create_oval(x+dx-5,y-23,x+dx+5,y-9,fill='#514bcb',outline='',tags='party')
            c.create_text(x,y+13,text='BOO!',font=('Segoe UI',17,'bold'),fill='#514bcb',tags='party')
            return
        for i in range(70):
            x=(i*87+math.sin(t*8+i)*25)%max(w,1); y=-90+(i*29)%160+t*(h+160)
            if 0<y<h: c.create_line(x-4,y-3,x+4,y+3,fill=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5],width=4,tags='party')

    def party_surface(self):
        name='party_canvas' if self.scene=='room' else 'canvas'
        canvas=getattr(self,name,None)
        return canvas if canvas is not None and canvas.winfo_exists() else None

    def draw(self):
        super().draw(); self.paint_party()

    def close(self):
        if getattr(self,'party_job',None): self.after_cancel(self.party_job); self.party_job=None
        super().close()
