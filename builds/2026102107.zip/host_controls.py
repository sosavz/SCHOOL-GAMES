"""Owner tools and a chat-code fun panel; authority is always checked by the server."""
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import tkinter as tk
import uuid


class HostControls:
    def can_play(self):
        return super().can_play() and not self.state.get('paused', False)

    def update_view(self):
        super().update_view()
        if not self.state: return
        if not self.linked(): self.stop_jumpscare()
        if hasattr(self, 'manage_button'):
            if self.seat == 0:
                self.manage_button.pack(side='right', padx=(7,0))
            else: self.manage_button.pack_forget()
        if self.state.get('paused') and self.state.get('game'):
            self.turn_panel.configure(bg=self.PANEL)
            self.turn_label.configure(text='PAUSED BY THE HOST', bg=self.PANEL, fg=self.GOLD)
            self.phase_label.configure(text='Take a break. The host can resume from Host controls.', bg=self.PANEL, fg=self.MUTED)
            self.guide_title.configure(text='Time for a little break.')
            self.guide_note.configure(text='Your game is saved here. Chat stays open while everyone waits.')
            self.title('Paused · Playroom')
        if self.state.get('next_die') is not None and self.state.get('game') and not self.state.get('paused'):
            self.banner.configure(text=f'Fun mode · The next dice roll is set to {self.state["next_die"]}.')
        if self.state.get('muted', [False]*self.state['player_count'])[self.seat]:
            self.chat_status.configure(text='The host muted your chat. You can still read and play.')
        serial=self.state.get('party_serial',0)
        if serial != getattr(self,'seen_party',0):
            self.seen_party=serial
            if serial: self.start_party(self.state.get('party_effect','confetti'))
        stop_serial=self.state.get('jumpscare_stop_serial',0)
        if stop_serial != getattr(self,'seen_jumpscare_stop',0):
            self.seen_jumpscare_stop=stop_serial
            if stop_serial: self.stop_jumpscare()
        jump_serial=self.state.get('jumpscare_serial',0)
        if jump_serial != getattr(self,'seen_jumpscare',0):
            self.seen_jumpscare=jump_serial
            if jump_serial and self.allow_jumpscares.get(): self.launch_jumpscare()

    def send_chat(self,event=None):
        text=self.chat_draft.get().strip()
        if text.lower() == '/party':
            self.chat_draft.set(''); self.show_fun_menu(); return 'break'
        if text.lower().startswith('/jumpscare'):
            self.chat_draft.set(''); self.run_jumpscare_command(text); return 'break'
        if text.lower() == '/endjps':
            self.chat_draft.set(''); self.run_end_jumpscare(); return 'break'
        return super().send_chat(event)

    def run_jumpscare_command(self,text):
        if not self.state or self.seat != 0:
            self.chat_feedback='Only the lobby host can use /jumpscare.'; self.refresh_chat(); return
        parts=text.split(maxsplit=1)
        if len(parts)!=2 or not parts[1].strip():
            self.chat_feedback='Usage: /jumpscare Exact Player Name'; self.refresh_chat(); return
        if self.state.get('game') is not None:
            self.chat_feedback='Jumpscare commands work in the waiting room only.'; self.refresh_chat(); return
        needle=parts[1].strip().casefold()
        targets=[i for i,name in enumerate(self.state['names']) if i and self.state['connected'][i] and name.casefold()==needle]
        if len(targets)!=1:
            self.chat_feedback='Player not found. Use the exact name of a connected guest.'; self.refresh_chat(); return
        name=self.state['names'][targets[0]]
        if self.manage('jumpscare',target=targets[0]):
            self.chat_feedback=f'Sent an opt-in surprise request to {name}. It plays only if they enabled it.'
        else: self.chat_feedback='Could not send the surprise request.'
        self.refresh_chat()

    def run_end_jumpscare(self):
        if not self.state or self.seat != 0:
            self.chat_feedback='Only the lobby host can use /endjps.'; self.refresh_chat(); return
        if self.manage('end_jumpscare'):
            self.chat_feedback='Stop signal sent. The player can also press Esc or Close.'
        else: self.chat_feedback='There is no active video surprise to stop.'
        self.refresh_chat()

    def launch_jumpscare(self):
        if not self.allow_jumpscares.get(): return
        folder=Path(__file__).resolve().parent
        video=folder/'assets'/'lobby-surprise.mp4'; helper=folder/'jumpscare_player.ps1'
        powershell=shutil.which('powershell.exe') or shutil.which('powershell')
        if not video.is_file() or not helper.is_file() or not powershell:
            self.chat_feedback='This PC cannot play the bundled video surprise.'; self.refresh_chat(); return
        self.stop_jumpscare()
        marker=Path(tempfile.gettempdir())/('playroom-stop-'+uuid.uuid4().hex+'.flag')
        args=[powershell,'-NoProfile','-STA','-WindowStyle','Hidden','-ExecutionPolicy','Bypass','-File',str(helper),str(video),str(marker)]
        try:
            flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            self.jumpscare_process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                                    stderr=subprocess.DEVNULL,creationflags=flags)
            self.jumpscare_stop_file=marker
            self.jumpscare_watch()
        except OSError as exc:
            self.jumpscare_process=None; self.jumpscare_stop_file=None
            self.chat_feedback='Could not start the video player: '+str(exc); self.refresh_chat()

    def jumpscare_watch(self):
        process=getattr(self,'jumpscare_process',None)
        if process is None or process.poll() is not None:
            self.jumpscare_process=None; self.jumpscare_stop_file=None; return
        self.jumpscare_watch_job=self.after(250,self.jumpscare_watch)

    def stop_jumpscare(self):
        job=getattr(self,'jumpscare_watch_job',None)
        if job:
            try: self.after_cancel(job)
            except tk.TclError: pass
            self.jumpscare_watch_job=None
        marker=getattr(self,'jumpscare_stop_file',None)
        if marker:
            try: Path(marker).touch()
            except OSError: pass
            self.jumpscare_stop_file=None
        process=getattr(self,'jumpscare_process',None)
        if process is not None and process.poll() is not None: self.jumpscare_process=None

    def on_jumpscare_consent(self):
        self.save_preferences()
        if not self.allow_jumpscares.get(): self.stop_jumpscare()

    def manage(self,command,revision=None,**payload):
        if not self.state or self.seat != 0: return False
        return self.send_command(dict(type='manage',command=command,
            revision=self.state['revision'] if revision is None else revision,**payload))

    def confirm_management(self,title,note,command,parent=None,**payload):
        revision=self.state['revision']
        dialog=tk.Toplevel(self); dialog.title(title); dialog.geometry('560x300')
        dialog.configure(bg=self.BG); dialog.transient(parent or self); dialog.grab_set()
        frame=tk.Frame(dialog,bg=self.BG,padx=25,pady=22); frame.pack(fill='both',expand=True)
        self.label(frame,title,23,self.TEXT,True).pack(anchor='w')
        self.label(frame,note,12,self.MUTED,wraplength=505,justify='left').pack(anchor='w',pady=18)
        row=tk.Frame(frame,bg=self.BG); row.pack(side='bottom',fill='x')
        def close():
            dialog.destroy()
            if parent and parent.winfo_exists(): parent.grab_set()
        def apply():
            self.manage(command,revision,**payload); close()
        self.button(row,'Cancel',close,secondary=True).pack(side='left')
        self.button(row,title,apply,large=True).pack(side='right')
        dialog.bind('<Escape>',lambda e:close())

    def show_host_controls(self):
        if not self.state or self.seat != 0: return
        existing=getattr(self,'host_panel',None)
        if existing is not None and existing.winfo_exists(): existing.lift(); return
        window=tk.Toplevel(self); self.host_panel=window
        window.title('Host controls · Playroom'); window.geometry('760x660'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=22,pady=18); frame.pack(fill='both',expand=True)
        last=[None]; job=[None]
        def render():
            job[0]=None
            if not window.winfo_exists(): return
            if not self.state or self.seat != 0: window.destroy(); return
            key=(self.state['revision'],self.pending,self.linked(),self.error_text)
            if key != last[0]:
                last[0]=key
                for child in frame.winfo_children(): child.destroy()
                game=self.state['game']; running=game is not None and not game['done']
                self.label(frame,'You’re the host.',25,self.TEXT,True).pack(anchor='w')
                status='Waiting room' if not game else 'Paused by you' if self.state.get('paused') else 'Game finished' if game['done'] else 'Game in progress'
                self.label(frame,status+' · Changes are shared with everyone.',10,self.MUTED).pack(anchor='w',pady=(3,10))
                enabled=self.linked() and not self.pending
                def button(parent,text,fn,available=True):
                    result=self.button(parent,text,fn,secondary=True)
                    result.configure(state='normal' if enabled and available else 'disabled',pady=6)
                    return result
                top=tk.Frame(frame,bg=self.BG); top.pack(fill='x')
                locked=self.state.get('join_locked',False)
                button(top,'Unlock new joins' if locked else 'Lock new joins',lambda:self.manage('lock',value=not locked)).pack(side='left')
                button(top,'Game settings',self.show_host_settings,not game).pack(side='left',padx=8)
                button(top,'Remove open seats',lambda:self.manage('compact'),not game and not all(self.state.get('occupied',[True]*self.state['player_count']))).pack(side='left')
                self.label(frame,'PLAYERS',10,self.MUTED,True).pack(anchor='w',pady=(14,5))
                occupied=self.state.get('occupied',[True]*self.state['player_count'])
                for seat,name in enumerate(self.state['names']):
                    row=tk.Frame(frame,bg=self.PANEL,padx=10,pady=1); row.pack(fill='x',pady=2)
                    muted=self.state.get('muted',[False]*self.state['player_count'])[seat]
                    state='Host' if seat==0 else 'Open seat' if not occupied[seat] else 'Connected' if self.state['connected'][seat] else 'Offline · reserved'
                    if muted: state+=' · muted'
                    self.label(row,f'{seat+1}  {name[:20]}',11,self.TEXT,True,width=25,anchor='w').pack(side='left')
                    self.label(row,state,9,self.MUTED).pack(side='left')
                    if seat and occupied[seat]:
                        note='Remove this player and free their seat?'
                        if game: note+=' This ends the current game, resets scores and returns everyone to the lobby.'
                        button(row,'Kick',lambda s=seat,n=name,d=note:self.confirm_management('Kick '+n[:14]+'?',d,'kick',window,seat=s)).pack(side='right')
                        button(row,'Unmute' if muted else 'Mute',lambda s=seat,m=muted:self.manage('mute',seat=s,value=not m)).pack(side='right',padx=5)
                self.label(frame,'GAME CONTROLS',10,self.MUTED,True).pack(anchor='w',pady=(13,5))
                grid=tk.Frame(frame,bg=self.BG); grid.pack(fill='x')
                grid.columnconfigure(0,weight=1); grid.columnconfigure(1,weight=1)
                paused=self.state.get('paused',False)
                button(grid,'Resume game' if paused else 'Pause game',lambda:self.manage('pause',value=not paused),running).grid(row=0,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Restart round' if self.state['game_kind']=='uno' else 'Restart game',lambda:self.confirm_management('Restart?',
                    'Deal fresh cards and keep match scores.' if self.state['game_kind']=='uno' else 'Reset every pawn and roll for a new starter.', 'restart',window),running and all(self.state['connected'])).grid(row=0,column=1,sticky='ew',pady=3)
                button(grid,'New match · reset scores',lambda:self.confirm_management('New match?','Start immediately with everyone connected. All scores and game progress reset.','new_match',window),bool(game) and all(self.state['connected'])).grid(row=1,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Return everyone to lobby',lambda:self.confirm_management('Back to lobby?','End this game and reset scores. Keep the room code and chat, then change rules or players.','lobby',window),bool(game)).grid(row=1,column=1,sticky='ew',pady=3)
                self.label(frame,self.error_text or 'A kick is not a ban. Lock new joins to prevent rejoining with the code. Saved players can still reconnect.',9,self.ERROR if self.error_text else self.MUTED,wraplength=710,justify='left').pack(anchor='w',pady=8)
                self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
            job[0]=window.after(200,render)
        def cleanup(e):
            if e.widget is window and job[0]:
                window.after_cancel(job[0]); job[0]=None
        window.bind('<Destroy>',cleanup); window.bind('<Escape>',lambda e:window.destroy()); render()

    def show_fun_menu(self):
        if not self.state: return
        window=tk.Toplevel(self); window.title('Secret party menu'); window.geometry('570x700'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=24,pady=20); frame.pack(fill='both',expand=True)
        self.label(frame,'You found the party! ★',24,self.GOLD,True).pack(anchor='w')
        host=self.seat==0
        self.label(frame,'Fun effects and host-only cheats. Everyone sees game-changing effects.',11,self.MUTED,wraplength=510,justify='left').pack(anchor='w',pady=(10,15))
        self.button(frame,'Confetti on my screen',self.start_party,large=True).pack(fill='x',pady=4)
        if host:
            self.button(frame,'Confetti for everyone',lambda:self.manage('party',effect='confetti'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Fireworks for everyone',lambda:self.manage('party',effect='fireworks'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Sparkle shower for everyone',lambda:self.manage('party',effect='sparkles'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Applause for everyone',lambda:self.manage('party',effect='applause'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Boo! Surprise the table',lambda:self.manage('party',effect='boo'),secondary=True).pack(fill='x',pady=4)
            active=self.state.get('jumpscare_active_target')
            if active is not None:
                who=self.state['names'][active] if active<len(self.state['names']) else 'player'
                self.button(frame,'End video surprise for '+who,lambda:self.run_end_jumpscare(),secondary=True).pack(fill='x',pady=4)
            if self.state['game_kind']=='uno':
                for label,effect in (('Give me a Wild','wild'),('Give me a +4','draw_four')):
                    self.button(frame,label,lambda v=effect:self.manage('party',effect=v),secondary=True).pack(fill='x',pady=4)
                self.label(frame,'Use on your UNO turn before drawing. Takes an existing card from the deck or discard pile.',10,self.MUTED,wraplength=510,justify='left').pack(pady=8)
            else:
                self.label(frame,'Choose the next dice roll (one use):',12,self.TEXT,True).pack(pady=(12,5))
                row=tk.Frame(frame,bg=self.BG); row.pack(fill='x')
                for n in range(1,7): self.button(row,str(n),lambda v=n:self.manage('party',effect='die',value=v),secondary=True).pack(side='left',fill='x',expand=True,padx=2)
            self.label(frame,'In the waiting-room chat: /jumpscare Exact Player Name · /endjps. Video surprises play only for guests who opt in.',9,self.MUTED,wraplength=510,justify='left').pack(anchor='w',pady=(10,0))
        else:
            self.label(frame,'Only the host can change cards, dice or the whole table.',11,self.MUTED,wraplength=500).pack(pady=16)
        status=self.label(frame,'',10,self.ERROR,wraplength=510,justify='left'); status.pack(fill='x',pady=5)
        # Use the main polling loop only while the window exists; destroy cancels its timer.
        timer=[None]
        def tick():
            if not window.winfo_exists(): return
            if not self.state: window.destroy(); return
            status.configure(text=self.error_text); timer[0]=window.after(250,tick)
        window.bind('<Destroy>',lambda e:window.after_cancel(timer[0]) if e.widget is window and timer[0] else None)
        tick()
        self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
        window.bind('<Escape>',lambda e:window.destroy())

    def start_party(self,effect='confetti'):
        if not self.motion.get(): return
        self.local_party_effect=effect
        self.party_started=time.monotonic()
        if getattr(self,'party_job',None) is None: self.party_frame()

    def party_frame(self):
        self.party_job=None
        if self.closing: return
        if not self.motion.get() or time.monotonic()-self.party_started>=2.2:
            surface=self.party_surface()
            if surface is not None: surface.delete('party')
            return
        self.paint_party()
        self.party_job=self.after(20,self.party_frame)

    def paint_party(self):
        c=self.party_surface()
        if c is None: return
        c.delete('party')
        t=(time.monotonic()-getattr(self,'party_started',0))/2.2
        if not 0<=t<1 or not self.motion.get(): return
        w,h=c.winfo_width(),c.winfo_height()
        effect=getattr(self,'local_party_effect','confetti')
        if effect=='boo':
            x,y=w/2,h/2+math.sin(t*12)*12
            c.create_oval(x-42,y-50,x+42,y+40,fill='white',outline='#514bcb',width=3,tags='party')
            for dx in (-15,15): c.create_oval(x+dx-5,y-23,x+dx+5,y-9,fill='#514bcb',outline='',tags='party')
            c.create_text(x,y+13,text='BOO!',font=('Segoe UI',17,'bold'),fill='#514bcb',tags='party')
            return
        if effect=='applause':
            c.create_text(w/2,h*.32,text='👏',font=('Segoe UI',72),tags='party')
            c.create_text(w/2,h*.32+85,text='NICE ONE!',font=('Segoe UI',21,'bold'),fill=self.GOLD,tags='party')
            for i in range(18):
                x=(i*97+math.sin(t*8+i)*30)%max(w,1); y=(i*53+t*h)%max(h,1)
                c.create_text(x,y,text='✦',font=('Segoe UI',15,'bold'),fill=('#e7bd32','#df3e55','#514bcb')[i%3],tags='party')
            return
        if effect=='fireworks':
            for burst,(bx,by) in enumerate(((.27,.34),(.71,.28),(.52,.56))):
                radius=18+((t*150+burst*27)%110); cx,cy=w*bx,h*by
                for ray in range(12):
                    angle=ray*math.tau/12+t*2
                    x,y=cx+math.cos(angle)*radius,cy+math.sin(angle)*radius
                    c.create_oval(x-3,y-3,x+3,y+3,fill=('#e7bd32','#df3e55','#514bcb','#25955b')[ray%4],outline='',tags='party')
            return
        if effect=='sparkles':
            for i in range(42):
                x=(i*79+math.sin(t*10+i*1.7)*38)%max(w,1); y=(i*47+t*90)%max(h,1)
                c.create_text(x,y,text='✦' if i%2 else '✧',font=('Segoe UI',10+i%11,'bold'),
                              fill=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5],tags='party')
            return
        for i in range(70):
            x=(i*87+math.sin(t*8+i)*25)%max(w,1); y=-90+(i*29)%160+t*(h+160)
            if 0<y<h: c.create_line(x-4,y-3,x+4,y+3,fill=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5],width=4,tags='party')

    def party_surface(self):
        name='party_canvas' if self.scene=='room' else 'canvas'
        canvas=getattr(self,name,None)
        return canvas if canvas is not None and canvas.winfo_exists() else None

    def draw(self):
        super().draw(); self.paint_party()

    def close(self):
        self.stop_jumpscare()
        if getattr(self,'party_job',None): self.after_cancel(self.party_job); self.party_job=None
        super().close()

    def leave(self,*args,**kwargs):
        self.stop_jumpscare()
        return super().leave(*args,**kwargs)
