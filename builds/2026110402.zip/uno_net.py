"""Authoritative 2–6 seat LAN rooms. JSON only; snapshots redact private cards."""
import json
from collections import deque
import queue
import secrets
import socket
import threading
import time

from uno_rules import Uno, STARTING_HANDS, TARGET_SCORES
from maedn_rules import Maedn
from uno_themes import THEMES
from room_features import RoomFeatures
from playroom_data import cosmetics, validate_checkpoint

VERSION = 7
GAMES = {'uno': 'UNO', 'maedn': 'Mensch ärgere dich nicht'}
MAX_PLAYERS = 6
DEFAULT_PORT = 47624
MAX_FRAME = 16384
CHAT_LENGTH = 240
CHAT_HISTORY = 80
HANDSHAKE_TIMEOUT = 6


class SeatReconnecting(ValueError):
    """The old socket has not timed out yet; the saved player can retry."""


def connection_error(host, port, exc):
    target = f'{host}:{port}'
    if isinstance(exc, socket.gaierror):
        detail = 'The host name could not be found. Check its spelling or use the host IP address.'
    elif isinstance(exc, ConnectionRefusedError):
        detail = 'The connection was refused. Keep the host room open and check the port.'
    elif isinstance(exc, TimeoutError):
        detail = 'The connection timed out. Check the network connection and the host firewall.'
    else:
        detail = f'The connection failed: {exc}'
    return (f'Could not connect to {target}. {detail}\n'
            'Different Wi-Fi networks? You need Tailscale and a game copy configured with the host’s Tailscale address. '
            'A fixed local address works only on that LAN. Open Connection help for details.')


def encode(message):
    return (json.dumps(message, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')


def frames(sock, stop, idle=15, first_frame_timeout=None):
    buffer = b''
    last = time.monotonic()
    deadline = last + first_frame_timeout if first_frame_timeout is not None else None
    while not stop.is_set():
        if deadline is not None and time.monotonic() >= deadline:
            raise ConnectionError('Handshake timed out')
        try:
            chunk = sock.recv(4096)
        except socket.timeout:
            if time.monotonic() - last > idle:
                raise ConnectionError('Connection timed out')
            continue
        if not chunk:
            return
        last = time.monotonic()
        if deadline is not None and last >= deadline:
            raise ConnectionError('Handshake timed out')
        buffer += chunk
        while b'\n' in buffer:
            line, buffer = buffer.split(b'\n', 1)
            if len(line) > MAX_FRAME:
                raise ValueError('Message is too large')
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError('Expected a JSON object')
            deadline = None
            yield value
        if len(buffer) > MAX_FRAME:
            raise ValueError('Message is too large')


def local_addresses():
    addresses = set()
    try:
        addresses.update(item[4][0] for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET))
    except OSError:
        pass
    try:
        # Select the default LAN interface without transmitting any packets.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(('192.0.2.1', 9))
            preferred = probe.getsockname()[0]
            addresses.add(preferred)
    except OSError:
        preferred = None
    result = sorted(ip for ip in addresses if not ip.startswith(('127.', '169.254.')))
    if preferred in result:
        result.remove(preferred)
        result.insert(0, preferred)
    return result or [socket.gethostname()]


class Peer:
    def __init__(self, sock, name, token):
        self.sock, self.name, self.token = sock, name, token
        self.send_lock = threading.Lock()
        self.last_request = 0

    def send(self, value):
        with self.send_lock:
            self.sock.sendall(encode(value))

    def close(self):
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.sock.close()


class BotPeer:
    """In-process opponent; may fill a public lobby seat or a practice seat."""
    def __init__(self, name, seat, difficulty='normal'):
        self.name=name; self.seat=seat; self.difficulty=difficulty; self.token='bot-'+secrets.token_urlsafe(18)
        self.send_lock=threading.Lock(); self.closed=False
    def send(self, value):
        if self.closed: raise OSError('Practice bot seat is closed.')
    def close(self): self.closed=True


class RoomServer(RoomFeatures):
    def __init__(self, port=DEFAULT_PORT, bind='0.0.0.0', player_count=2, starting_cards=7, target_score=500,
                 game_kind='uno', three_rolls=False, home_jumping=True, theme='Playroom', uno_mode='classic',
                 turn_timer=0, round_limit=0, bot_count=0, bot_difficulty='normal', save_path=None, saved_room=None):
        if saved_room is not None:
            saved_room,_=validate_checkpoint(saved_room)
            player_count=saved_room['player_count']; game_kind=saved_room['game_kind']
            starting_cards=saved_room['settings']['starting_cards']; target_score=saved_room['settings']['target_score']
            uno_mode=saved_room['settings']['uno_mode']; theme=saved_room['theme']
            three_rolls=saved_room['board_settings']['three_rolls']; home_jumping=saved_room['board_settings']['home_jumping']
            turn_timer=saved_room['turn_timer']; round_limit=saved_room['round_limit']
            bot_difficulty=saved_room['bot_difficulty']; bot_count=0
        if type(player_count) is not int or not 2 <= player_count <= MAX_PLAYERS:
            raise ValueError('Choose between 2 and 6 players.')
        self.player_count = player_count
        self.settings = self.validate_settings(starting_cards, target_score, uno_mode)
        self.game_kind, self.board_settings = self.validate_game(game_kind, three_rolls, home_jumping)
        if not isinstance(theme, str) or theme not in THEMES:
            raise ValueError('Choose a valid table design.')
        self.theme = theme
        self.turn_timer = self._validate_choice(turn_timer, (0, 30, 45, 60), 'Turn timer')
        self.round_limit = self._validate_choice(round_limit, (0, 3, 5, 10), 'Round limit')
        if type(bot_count) is not int or not 0 <= bot_count < player_count:
            raise ValueError('Bot seats must be between 0 and the number of guest seats.')
        if bot_difficulty not in ('easy', 'normal', 'hard'):
            raise ValueError('Choose an easy, normal or hard bot difficulty.')
        self.bot_difficulty = bot_difficulty
        self.settings_version = 1
        self.stop = threading.Event()
        self.lock = threading.RLock()
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
                self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            else:
                self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.listener.bind((bind, port))
            self.listener.listen(12)
            self.listener.settimeout(.5)
        except Exception:
            self.listener.close()
            raise
        self.port = self.listener.getsockname()[1]
        self.code = f'{secrets.randbelow(1000000):06d}'
        self.host_key = secrets.token_urlsafe(24)
        self.peers = [None] * player_count
        self.names = ['Host'] + ['Open seat'] * (player_count - 1)
        self.tokens = [None] * player_count
        self.ready = [False] * player_count
        self.paused = False
        self.join_locked = False
        self.muted = [False] * player_count
        self.next_die = None
        self.party_serial = 0
        self.party_effect = 'confetti'
        self.kitchen_serial = 0
        # Video surprises: a shared serial is delivered only to the targeted seats.
        self.jumpscare_serial = 0
        self.jumpscare_stop_serial = 0
        self.jumpscare_targets = set()
        self.jumpscare_stop_targets = set()
        self.game = None
        self.round_number = 0
        self.revision = 0
        self.last_event = f'Room opened for {player_count} players. Everyone selects Ready to begin.'
        self.last_move = None
        self.bot_seats = set()
        self.bot_actions = 0
        self.activity = deque(maxlen=24)
        self._activity_marker = None
        self._turn_marker = None
        self._turn_started = time.monotonic()
        self._timer_fired = False
        self.pending = set()
        self.chat = deque(maxlen=CHAT_HISTORY)
        self.chat_serial = 0
        self.chat_times = [deque() for _ in range(player_count)]
        self.init_features(save_path,saved_room)
        if bot_count:
            self._install_bots(bot_count, bot_difficulty)
        threading.Thread(target=self._accept, daemon=True, name='uno-host').start()
        threading.Thread(target=self._run_bots, daemon=True, name='playroom-bots').start()
        threading.Thread(target=self._timer_loop, daemon=True, name='playroom-turn-timer').start()

    @staticmethod
    def _validate_choice(value, allowed, label):
        if type(value) is not int or value not in allowed:
            raise ValueError(f'{label} must be one of {", ".join(map(str, allowed))}.')
        return value

    def _install_bots(self, count, difficulty):
        if type(count) is not int or not 0 <= count < self.player_count or difficulty not in ('easy','normal','hard'):
            raise ValueError('Choose a valid bot count and difficulty.')
        # Put bots at the end so friends take ordinary open seats first.
        for seat in sorted(self.bot_seats):
            peer = self.peers[seat]
            if isinstance(peer, BotPeer):
                peer.close(); self.peers[seat] = None; self.tokens[seat] = None
                self.names[seat] = 'Open seat'; self.ready[seat] = False
        self.bot_seats.clear()
        for seat in range(self.player_count-count, self.player_count):
            if seat == 0 or self.tokens[seat] is not None:
                continue
            name = f'Bot {seat}'
            peer = BotPeer(name, seat, difficulty)
            self.peers[seat] = peer; self.tokens[seat] = peer.token; self.names[seat] = name
            self.ready[seat] = True; self.bot_seats.add(seat)

    def _timer_loop(self):
        from uno_bot import choose_action
        while not self.stop.wait(.25):
            with self.lock:
                if not self.turn_timer or self.game is None or self.game.done or self.paused or not all(self.peers):
                    self._turn_marker = None
                    continue
                if isinstance(self.game, Maedn):
                    marker = (self.game.turn, self.game.phase, self.game.note)
                else:
                    marker = (self.game.turn, self.game.phase, self.game.note)
                if marker != self._turn_marker:
                    self._turn_marker = marker
                    self._turn_started = time.monotonic()
                    self._timer_fired = False
                remaining = max(0, self.turn_timer - int(time.monotonic()-self._turn_started))
                if remaining == 0 and not self._timer_fired:
                    self._timer_fired = True
                    seat = self.game.turn
                    state = self.snapshot(seat)
                    action = choose_action(self, seat, state, difficulty='easy')
                    if action:
                        before = self.revision
                        # _message already bumps the revision and broadcasts when the move is accepted.
                        self._message(seat, {'type':'action','revision':self.revision,'action':list(action)})
                        if self.revision != before:
                            self.last_event = f'{self.names[seat]} ran out of time. A quick move was made automatically.'
                            self._broadcast()
                # Timer refreshes do not advance gameplay revisions.
                if int(time.monotonic()) != getattr(self, '_last_timer_broadcast', -1):
                    self._last_timer_broadcast = int(time.monotonic())
                    self._broadcast()

    def add_practice_bots(self, count, difficulty='normal'):
        """Fill seats with deterministic local opponents before a practice game starts."""
        if type(count) is not int or not 1 <= count < self.player_count:
            raise ValueError('A practice table needs at least one bot and one human.')
        with self.lock:
            if self.game is not None or any(self.tokens[1:]):
                raise ValueError('Practice bots can only be added to an empty waiting room.')
            if difficulty not in ('easy','normal','hard'):
                raise ValueError('Choose an easy, normal or hard bot difficulty.')
            for seat in range(1,count+1):
                name=f'Bot {seat}'
                peer=BotPeer(name,seat,difficulty)
                self.peers[seat]=peer; self.tokens[seat]=peer.token; self.names[seat]=name
                self.ready[seat]=True; self.bot_seats.add(seat)
            self.revision+=1
            self.last_event=f'{count} practice bot'+('s are' if count!=1 else ' is')+' ready.'

    def _sync_bot_seats(self):
        """Bot ownership follows actual peers when seats are removed or renumbered."""
        self.bot_seats = {seat for seat, peer in enumerate(self.peers) if isinstance(peer, BotPeer)}

    def _run_bots(self):
        from uno_bot import choose_action
        while not self.stop.wait(.45):
            with self.lock:
                self._sync_bot_seats()
                if self.paused: continue
                if self.game is None or self.game.done:
                    changed=False
                    for seat in self.bot_seats:
                        if (seat < self.player_count and isinstance(self.peers[seat], BotPeer)
                                and not self.peers[seat].closed and not self.ready[seat]):
                            self.ready[seat]=True; changed=True
                    if changed:
                        self.revision+=1
                        self._maybe_start_round()
                        self._broadcast()
                    continue
                for seat in sorted(self.bot_seats):
                    peer=self.peers[seat] if seat < self.player_count else None
                    if not isinstance(peer, BotPeer) or peer.closed: continue
                    state=self.snapshot(seat); view=state.get('game') or {}
                    actions=view.get('actions',())
                    if not actions: continue
                    action=choose_action(self,seat,state,difficulty=getattr(peer,'difficulty',self.bot_difficulty))
                    if action is None: continue
                    revision=self.revision
                    self._message(seat,{'type':'action','revision':revision,'action':list(action)})
                    if self.revision!=revision: self.bot_actions+=1
                    break

    @staticmethod
    def validate_game(game_kind, three_rolls, home_jumping):
        if not isinstance(game_kind, str) or game_kind not in GAMES:
            raise ValueError('Choose UNO or Mensch ärgere dich nicht.')
        if type(three_rolls) is not bool or type(home_jumping) is not bool:
            raise ValueError('Board-game options must be on or off.')
        return game_kind, {'three_rolls': three_rolls, 'home_jumping': home_jumping}

    @staticmethod
    def validate_settings(starting_cards, target_score, uno_mode='classic'):
        if type(starting_cards) is not int or starting_cards not in STARTING_HANDS:
            raise ValueError('Starting cards must be 5, 7 or 10.')
        if type(target_score) is not int or target_score not in TARGET_SCORES:
            raise ValueError('Target score must be 100, 250, 500 or 1000.')
        if not isinstance(uno_mode,str) or uno_mode not in Uno.MODES:
            raise ValueError('Choose Classic or Extreme UNO.')
        return {'starting_cards': starting_cards, 'target_score': target_score, 'uno_mode': uno_mode}

    def _accept(self):
        while not self.stop.is_set():
            try:
                sock, _ = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            sock.settimeout(1)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            with self.lock:
                if len(self.pending) >= 12:
                    sock.close()
                    continue
                self.pending.add(sock)
            threading.Thread(target=self._serve, args=(sock,), daemon=True).start()

    def _serve(self, sock):
        peer, seat = None, None
        try:
            stream = frames(sock, self.stop, first_frame_timeout=HANDSHAKE_TIMEOUT)
            hello = next(stream)
            with self.lock:
                if hello.get('type') != 'hello' or hello.get('version') != VERSION:
                    raise ValueError('App versions do not match. Use the latest UNO Together folder on every PC.')
                if not isinstance(hello.get('room'), str) or not secrets.compare_digest(hello['room'], self.code):
                    raise ValueError('Room code is incorrect. Ask your friend for the six-digit code.')
                profile=cosmetics(hello.get('profile'))
                if hello.get('profile') is not None and profile!=hello['profile']:
                    raise ValueError('Choose a supported player profile.')
                if hello.get('host_key') == self.host_key:
                    seat = 0
                elif hello.get('resume'):
                    resume = hello['resume']
                    seat = next((i for i in range(1, self.player_count) if isinstance(resume, str)
                                 and self.tokens[i] and secrets.compare_digest(resume, self.tokens[i])), None)
                    if seat is None:
                        raise ValueError('Saved seat was not found in this room. Join normally for a new seat.')
                elif self.join_locked:
                    raise ValueError('The host locked this room to new players. Ask the host to unlock it.')
                elif self.game is None and None in self.tokens[1:]:
                    seat = self.tokens.index(None, 1)
                elif self.game is None and self.bot_seats:
                    # A friend may claim the lowest-numbered bot seat before dealing.
                    seat = min(self.bot_seats)
                    bot = self.peers[seat]
                    if isinstance(bot, BotPeer):
                        bot.close()
                        self.bot_seats.discard(seat)
                        self.peers[seat] = None
                        self.tokens[seat] = None
                        self.ready[seat] = False
                else:
                    raise ValueError('This table is full. Resume your saved seat or ask the host to create a new room with more seats.')
                if self.peers[seat] is not None:
                    raise SeatReconnecting('This player is already connected. Waiting for the previous connection to close.')
                name = hello.get('name')
                if not isinstance(name, str):
                    raise ValueError('Enter a player name.')
                name = ''.join(c for c in name if c.isprintable()).strip()[:20]
                if not name:
                    raise ValueError('Enter a player name.')
                token = self.tokens[seat] or secrets.token_urlsafe(24)
                self.tokens[seat], self.names[seat] = token, name
                self.profiles[seat]=profile
                peer = Peer(sock, name, token)
                peer.seat = seat
                self.peers[seat] = peer
                self.pending.discard(sock)
                peer.send({'type': 'welcome', 'seat': seat, 'resume': token, 'room': self.code, 'version': VERSION})
                # Small batches stay below the frame limit even with Unicode text.
                history = list(self.chat)
                for offset in range(0, len(history), 10):
                    peer.send({'type': 'chat_history', 'messages': history[offset:offset+10]})
                self.revision += 1
                self.last_event = f'{name} connected.'
                self._maybe_start_round()
                self._broadcast()
            # Keep the same buffered stream, including frames coalesced with hello.
            for message in stream:
                with self.lock:
                    seat = peer.seat
                    if seat >= self.player_count or self.peers[seat] is not peer:
                        break
                    request = message.get('request')
                    tracked = type(request) is int and request > 0
                    if not tracked or request > peer.last_request:
                        if tracked: peer.last_request = request
                        self._message(seat, message)
                    if tracked: self._send(seat, {'type': 'ack', 'request': request})
        except (OSError, ValueError, StopIteration, UnicodeError, TypeError, KeyError) as exc:
            if peer is None:
                try:
                    sock.sendall(encode({'type': 'error', 'fatal': not isinstance(exc, SeatReconnecting),
                                         'forget_resume': str(exc).startswith('Saved seat was not found'),
                                         'retryable': isinstance(exc, SeatReconnecting),
                                         'message': str(exc) or 'Connection closed.'}))
                except OSError:
                    pass
        finally:
            with self.lock:
                if peer is not None: seat = peer.seat
                self.pending.discard(sock)
                if peer is not None and seat < self.player_count and self.peers[seat] is peer:
                    self.peers[seat] = None
                    self._stop_jumpscares({seat})
                    self.revision += 1
                    self.last_event = f'{self.names[seat]} disconnected. Play is paused until they reconnect.'
                    self._broadcast()
            sock.close()

    def snapshot(self, seat):
        connected = [peer is not None for peer in self.peers]
        state = {'type': 'state', 'revision': self.revision, 'seat': seat,
                 'player_count': self.player_count,
                 'game_kind': self.game_kind, 'board_settings': dict(self.board_settings),
                 'settings': dict(self.settings), 'theme': self.theme,
                 'turn_timer': self.turn_timer, 'round_limit': self.round_limit,
                 'bot_difficulty': self.bot_difficulty, 'bot_seats': sorted(self.bot_seats),
                 'settings_version': self.settings_version,
                 'paused': self.paused, 'join_locked': self.join_locked,
                 'muted': list(self.muted), 'occupied': [token is not None for token in self.tokens],
                 'next_die': self.next_die, 'party_serial': self.party_serial, 'party_effect': self.party_effect,
                 'kitchen_serial': self.kitchen_serial,
                 'jumpscare_serial': self.jumpscare_serial if seat in self.jumpscare_targets else 0,
                 'jumpscare_stop_serial': self.jumpscare_stop_serial if seat in self.jumpscare_stop_targets else 0,
                 'jumpscare_active_targets': sorted(self.jumpscare_targets) if seat == 0 else [],
                 'names': list(self.names), 'connected': connected, 'ready': list(self.ready),
                 'room': self.code, 'port': self.port, 'event': self.last_event,
                 'last_move': self.last_move, 'activity': list(self.activity),
                 'turn_seconds_left': self._turn_seconds_left(), 'game': None}
        state.update(self.feature_snapshot(seat))
        if self.game is None:
            return state
        u = self.game
        if isinstance(u, Maedn):
            state['game'] = u.snapshot(seat)
            if not all(connected) or self.paused: state['game']['actions'] = []; state['game']['destinations'] = {}
            return state
        actions = u.actions_for(seat)
        audit = None
        if u.audit and seat == u.turn:
            who, evidence, color, guilty = u.audit
            audit = {'seat': who, 'hand': evidence, 'color': color, 'guilty': guilty}
        state['game'] = {'kind': 'uno', 'hand': list(u.hands[seat]), 'counts': list(map(len, u.hands)),
                         'top': u.discard[-1], 'color': u.color, 'turn': u.turn, 'direction': u.direction,
                         'uno_mode': u.uno_mode, 'stack_penalty': u.stack_penalty,
                          'launcher_serial':u.launcher_serial,'launcher_burst':u.launcher_burst,'launcher_owner':u.launcher_owner,
                         'phase': u.phase, 'points': list(u.match_points), 'target_score': u.target_score,
                         'round_number': self.round_number, 'dealer': u.dealer,
                         'dealer_draws': u.dealer_draws, 'round_breakdown': u.round_breakdown,
                         'missed_uno': u.missed_uno,
                         'deck_count': len(u.deck),
                         'done': u.done, 'match_done': getattr(u, 'match_done', max(u.match_points) >= u.target_score),
                         'winner': getattr(u, 'match_winner', u.winner), 'round_winner': u.winner,
                         'round_points': u.round_points,
                         'note': u.note, 'actions': actions if all(connected) and not self.paused else [],
                         'audit': audit, 'drawn_index': u.drawn_index if seat == u.turn and u.phase == 'drawn' else None,
                         'called': seat in u.uno_called or (u.announced and seat == u.turn)}
        return state

    def _stop_jumpscares(self, seats=None):
        """Send a stop signal to active video-surprise seats (all of them by default)."""
        seats = set(self.jumpscare_targets if seats is None else seats) & self.jumpscare_targets
        if not seats: return False
        self.jumpscare_targets -= seats
        self.jumpscare_stop_targets = seats
        self.jumpscare_stop_serial += 1
        return True

    def _send(self, seat, value):
        peer = self.peers[seat]
        if peer:
            try:
                peer.send(value)
            except OSError:
                peer.close()

    def _broadcast(self):
        self.record_round()
        self.checkpoint()
        marker = (self.revision, self.last_event)
        if self.last_event and marker != self._activity_marker:
            self.activity.append({'revision': self.revision, 'time': time.strftime('%H:%M'), 'text': self.last_event})
            self._activity_marker = marker
        for seat in range(self.player_count):
            self._send(seat, self.snapshot(seat))

    def _turn_seconds_left(self):
        if not self.turn_timer or self.game is None or self.game.done or self.paused:
            return None
        return max(0, self.turn_timer - int(time.monotonic()-self._turn_started))

    def _reject(self, seat, message):
        self._send(seat, {'type': 'error', 'message': message, 'fatal': False})
        self._send(seat, self.snapshot(seat))

    def _maybe_start_round(self):
        if self.paused or not all(self.ready) or not all(self.peers) or self.game is not None and not self.game.done:
            return
        old = self.game
        if old is not None and old.done and self.night_queue:
            self.game_kind=self.night_queue.pop(0)
            old=None
        self.next_die = None
        self.new_round()
        if self.game_kind == 'maedn':
            self.game = Maedn(player_count=self.player_count, **self.board_settings)
            self.round_number += 1
            self.ready = [False] * self.player_count
            self.last_move = None
            self.last_event = self.game.note
            return
        continuing = old and max(old.match_points) < self.settings['target_score'] and not getattr(old, 'match_done', False)
        scores = old.match_points if continuing else [0] * self.player_count
        self.round_number = self.round_number+1 if continuing else 1
        self.game = Uno(dealer=(old.dealer + 1) % self.player_count if continuing else None,
                        scores=scores, player_count=self.player_count, **self.settings)
        self.ready = [False] * self.player_count
        self.last_move = None
        self.last_event = f'Round {self.round_number}. P{self.game.dealer+1} deals. '+self.game.note

    def _message(self, seat, message):
        if self.feature_command(seat,message): return
        kind = message.get('type')
        if kind == 'manage':
            self._manage(seat, message)
            return
        if kind == 'chat':
            if self.muted[seat]:
                self._send(seat, {'type': 'chat_error', 'message': 'The host muted your chat. You can still read messages and play.'})
                return
            text = message.get('text')
            if not isinstance(text, str) or len(text) > CHAT_LENGTH:
                self._send(seat, {'type': 'chat_error', 'message': f'Use up to {CHAT_LENGTH} characters.'})
                return
            text = ''.join(c for c in text if c.isprintable()).strip()
            if not text:
                self._send(seat, {'type': 'chat_error', 'message': 'Type a message first.'})
                return
            now = time.monotonic()
            recent = self.chat_times[seat]
            while recent and now-recent[0] >= 5:
                recent.popleft()
            if len(recent) >= 5:
                self._send(seat, {'type': 'chat_error', 'message': 'Chat is moving fast. Try again in a few seconds.'})
                return
            recent.append(now)
            self.chat_serial += 1
            entry = {'id': self.chat_serial, 'seat': seat, 'name': self.names[seat],
                     'text': text, 'time': time.strftime('%H:%M')}
            self.chat.append(entry)
            # Chat never changes a game revision or interrupts a move in flight.
            for recipient in range(self.player_count):
                self._send(recipient, {'type': 'chat', 'message': entry})
            return
        if kind == 'ping':
            self._send(seat, {'type': 'pong'})
            return
        if kind == 'settings':
            if seat != 0 or self.game is not None:
                self._reject(seat, 'Only the host can change settings, before the game starts.')
                return
            try:
                settings = self.validate_settings(message.get('starting_cards'), message.get('target_score'),
                                                  message.get('uno_mode',self.settings.get('uno_mode','classic')))
                turn_timer = self._validate_choice(message.get('turn_timer', self.turn_timer), (0,30,45,60), 'Turn timer')
                round_limit = self._validate_choice(message.get('round_limit', self.round_limit), (0,3,5,10), 'Round limit')
                game_kind, board_settings = self.validate_game(message.get('game_kind', self.game_kind),
                    message.get('three_rolls', self.board_settings['three_rolls']),
                    message.get('home_jumping', self.board_settings['home_jumping']))
                theme = message.get('theme',self.theme)
                if not isinstance(theme, str) or theme not in THEMES:
                    raise ValueError('Choose a valid table design.')
                players = message.get('player_count', self.player_count)
                if type(players) is not int or not 2 <= players <= MAX_PLAYERS:
                    raise ValueError('Choose between 2 and 6 players.')
                bot_count = message.get('bot_count', len(self.bot_seats))
                bot_difficulty = message.get('bot_difficulty', self.bot_difficulty)
                if type(bot_count) is not int or not 0 <= bot_count < players:
                    raise ValueError('Bot seats must be between 0 and the number of guest seats.')
                if bot_difficulty not in ('easy','normal','hard'):
                    raise ValueError('Choose an easy, normal or hard bot difficulty.')
                if any(peer is not None and not isinstance(peer, BotPeer) for peer in self.peers[players:]):
                    raise ValueError('Those seats still have connected players. Ask them to leave before reducing the player count.')
            except ValueError as exc:
                self._reject(seat, str(exc))
                return
            self.settings = settings
            self.turn_timer, self.round_limit = turn_timer, round_limit
            self.bot_difficulty = bot_difficulty
            self.game_kind, self.board_settings = game_kind, board_settings
            self.theme = theme
            extra = max(0, players-self.player_count)
            self.peers = self.peers[:players] + [None]*extra
            self.names = self.names[:players] + ['Open seat']*extra
            self.tokens = self.tokens[:players] + [None]*extra
            self.chat_times = self.chat_times[:players] + [deque() for _ in range(extra)]
            self.muted = self.muted[:players] + [False]*extra
            self.profiles=self.profiles[:players]+[cosmetics() for _ in range(extra)]
            self.night_scores=self.night_scores[:players]+[0]*extra
            self.player_count = players
            self.bot_seats = {i for i in self.bot_seats if i < players and isinstance(self.peers[i], BotPeer)}
            self._install_bots(bot_count, bot_difficulty)
            self.settings_version += 1
            self.ready = [False] * self.player_count
            self.revision += 1
            self.last_event = 'The host changed table settings. Everyone must choose Ready again.'
            self._broadcast()
            return
        if kind == 'ready':
            if self.paused:
                self._reject(seat, 'The host paused this game. Wait for the host to resume.')
                return
            if self.game is not None and not self.game.done:
                self._reject(seat, 'Finish this round before starting another.')
                return
            if message.get('settings_version', self.settings_version) != self.settings_version:
                self._reject(seat, 'The host changed the settings. Check them and choose Ready again.')
                return
            if 'ready' in message and type(message['ready']) is not bool:
                self._reject(seat, 'Ready must be true or false.')
                return
            self.ready[seat] = message.get('ready', not self.ready[seat])
            self._maybe_start_round()
            self.revision += 1
            self._broadcast()
            return
        if kind != 'action':
            self._reject(seat, 'Unknown command.')
            return
        if self.paused:
            self._reject(seat, 'The host paused this game. Wait for the host to resume.')
            return
        if self.game is None or not all(self.peers):
            self._reject(seat, 'Every player must be connected to play.')
            return
        if type(message.get('revision')) is not int or message['revision'] != self.revision:
            self._reject(seat, 'The table changed. Your view has been refreshed; choose again.')
            return
        action = message.get('action')
        if (not isinstance(action, list) or not 1 <= len(action) <= 3 or
                not isinstance(action[0], str) or any(type(v) not in (str, int) for v in action)):
            self._reject(seat, 'Invalid action.')
            return
        action = tuple(action)
        u = self.game
        if action not in [tuple(a) for a in self.snapshot(seat)['game']['actions']]:
            self._reject(seat, 'That action is unavailable. Wait for your turn or choose a highlighted card or pawn.')
            return
        card = u.hands[seat][action[1]] if action[0] in ('play','stack') else None
        original_roll = None
        if isinstance(u, Maedn) and action[0] == 'roll' and self.next_die is not None:
            original_roll = u.roll_die
            value = self.next_die
            u.roll_die = lambda: value
            self.next_die = None
        try:
            accepted = u.perform(seat, action)
        finally:
            if original_roll is not None: u.roll_die = original_roll
        if not accepted:
            self._reject(seat, 'Move rejected. Please choose again.')
            return
        self.last_event = u.note
        if isinstance(u, Uno) and u.done and (max(u.match_points) >= self.settings['target_score'] or
                                                (self.round_limit and self.round_number >= self.round_limit)):
            u.match_done = True
            leaders = [i for i, score in enumerate(u.match_points) if score == max(u.match_points)]
            u.match_winner = u.winner if u.winner in leaders else leaders[0]
        self.revision += 1
        move_kind='launch' if isinstance(u,Uno) and u.uno_mode=='extreme' and action[0]=='draw' else action[0]
        self.last_move = {'revision': self.revision, 'seat': seat, 'kind': move_kind, 'card': card}
        self._broadcast()

    def _manage(self, seat, message):
        """Administrative commands use the authenticated connection, never a supplied role."""
        if seat != 0:
            self._reject(seat, 'Only the room owner can manage players or games.')
            return
        command = message.get('command')
        # Video surprises never touch game state, so a busy table must not make them go stale.
        if command not in ('jumpscare', 'end_jumpscare') and (
                type(message.get('revision')) is not int or message['revision'] != self.revision):
            self._reject(seat, 'The room changed. Review the host panel and choose again.')
            return
        if command == 'kitchen':
            if self.game is not None:
                self._reject(seat, 'The kitchen banner is available in the waiting room only.')
                return
            self.kitchen_serial += 1
            self.last_event = 'The host called everyone to the kitchen party!'
            self.revision += 1
            self._broadcast()
            return
        if command in ('kick', 'mute'):
            target = message.get('seat')
            if type(target) is not int or not 1 <= target < self.player_count or self.tokens[target] is None:
                self._reject(seat, 'Choose an occupied guest seat. The host cannot be removed or muted.')
                return
        if command in ('pause', 'lock', 'mute') and type(message.get('value')) is not bool:
            self._reject(seat, 'Choose on or off for this control.')
            return
        if command == 'pause':
            if self.game is None or self.game.done:
                self._reject(seat, 'Pause is available during a running game.')
                return
            self.paused = message['value']
            self.last_event = 'The host paused the game. Chat is still available.' if self.paused else 'The host resumed the game.'
        elif command == 'lock':
            self.join_locked = message['value']
            self.last_event = 'The host locked the room to new players.' if self.join_locked else 'The host unlocked the room to new players.'
        elif command == 'mute':
            self.muted[target] = message['value']
            self.last_event = f'The host {"muted" if self.muted[target] else "unmuted"} {self.names[target]} in chat.'
        elif command == 'compact':
            if self.game is not None:
                self._reject(seat, 'Return to the lobby before removing open seats.')
                return
            # Seat numbers change below, so end any running surprise first.
            self._stop_jumpscares()
            keep = [i for i in range(self.player_count) if i == 0 or self.tokens[i] is not None]
            for field in ('peers', 'tokens', 'names', 'muted', 'chat_times', 'profiles', 'night_scores'):
                values = getattr(self, field)
                setattr(self, field, [values[i] for i in keep])
            if len(keep) == 1:
                self.peers.append(None); self.tokens.append(None); self.names.append('Open seat')
                self.muted.append(False); self.chat_times.append(deque())
                self.profiles.append(cosmetics()); self.night_scores.append(0)
            self.player_count = len(self.peers)
            for index, peer in enumerate(self.peers):
                if peer is not None: peer.seat = index
            self._sync_bot_seats()
            self.ready = [False]*self.player_count
            self.settings_version += 1
            self.last_event = 'The host removed open seats. Check your new player number and choose Ready again.'
        elif command in ('lobby', 'kick'):
            was_running = self.game is not None
            if command == 'kick':
                name, peer = self.names[target], self.peers[target]
                self._stop_jumpscares({target})
                self.peers[target] = None
                self._sync_bot_seats()
                self.tokens[target] = None
                self.profiles[target]=cosmetics(); self.night_scores[target]=0
                self.names[target] = 'Open seat'
                self.muted[target] = False
                self.chat_times[target].clear()
                if peer:
                    try:
                        peer.send({'type': 'error', 'fatal': True, 'forget_resume': True,
                                   'message': 'The host removed you from this room.'})
                    except OSError:
                        pass
                    peer.close()
                self.last_event = f'The host removed {name}.' + (' The game ended; everyone is back in the lobby.' if was_running else '')
            else:
                self.last_event = 'The host ended the game and returned everyone to the lobby. Scores are reset.'
            self.game = None
            self.new_round()
            self.next_die = None
            self.round_number = 0
            self.paused = False
            self.last_move = None
            self.ready = [False] * self.player_count
            self.settings_version += 1
        elif command in ('restart', 'new_match'):
            if self.game is None or not all(self.peers):
                self._reject(seat, 'Everyone must be connected before restarting. Return to the lobby to change players.')
                return
            old = self.game
            self.next_die = None
            if command == 'restart' and old.done:
                self._reject(seat, 'This game has finished. Start a new match or use Ready for the next round.')
                return
            if self.game_kind == 'uno':
                scores = list(old.match_points) if command == 'restart' else [0]*self.player_count
                self.game = Uno(dealer=old.dealer if command == 'restart' else None,
                                scores=scores, player_count=self.player_count, **self.settings)
            else:
                self.game = Maedn(player_count=self.player_count, **self.board_settings)
            if command == 'new_match': self.round_number = 1
            self.new_round()
            self.paused = False
            self.ready = [False]*self.player_count
            self.settings_version += 1
            self.last_move = None
            self.last_event = 'The host restarted the round. Match scores are kept.' if command == 'restart' and self.game_kind == 'uno' else 'The host started a fresh game. Scores and progress are reset.'
        elif command == 'jumpscare':
            # Works in the lobby and during a game; it never changes game state.
            target = message.get('target')
            humans = [i for i in range(1, self.player_count)
                      if self.peers[i] is not None and not isinstance(self.peers[i], BotPeer)]
            if target == 'all':
                targets = set(humans)
                if not targets:
                    self._reject(seat, 'No connected guests to surprise yet.')
                    return
                who = 'everyone'
            elif type(target) is int and target in humans:
                targets = {target}
                who = self.names[target]
            else:
                self._reject(seat, 'Choose a connected guest by their player seat.')
                return
            self._stop_jumpscares(self.jumpscare_targets - targets)
            self.jumpscare_targets = targets
            self.jumpscare_serial += 1
            self.last_event = f'The host sent a video jumpscare to {who}!'
        elif command == 'end_jumpscare':
            if not self._stop_jumpscares():
                self._reject(seat, 'There is no active video surprise to end.')
                return
            self.last_event = 'The host ended the video surprise.'
        elif command == 'party':
            effect = message.get('effect')
            if effect in ('confetti', 'boo', 'fireworks', 'sparkles', 'applause'):
                self.party_serial += 1
                self.party_effect = effect
                party_notes={'confetti':'The host started a confetti party!','boo':'Boo! The host sent a silly surprise.',
                             'fireworks':'The host started the fireworks!','sparkles':'The host sent a sparkle shower!',
                             'applause':'The host started a round of applause!'}
                self.last_event = party_notes[effect]
            elif effect == 'die':
                value = message.get('value')
                if not isinstance(self.game, Maedn) or self.game.done or type(value) is not int or not 1 <= value <= 6:
                    self._reject(seat, 'Choose a die value from 1 to 6 during a running board game.')
                    return
                self.next_die = value
                self.last_event = f'Fun mode: the host set the next dice roll to {value}.'
            elif effect in ('wild', 'draw_four'):
                u = self.game
                if not isinstance(u, Uno) or u.done or u.phase != 'ready' or u.turn != 0 or self.paused or not all(self.peers):
                    self._reject(seat, 'Take a bonus card only at the start of your own UNO turn, while everyone is connected.')
                    return
                card = ('Wild', 'Wild' if effect == 'wild' else '+4')
                source = u.deck if card in u.deck else u.discard if card in u.discard[:-1] else None
                if source is None:
                    self._reject(seat, 'That card is already in players’ hands or on top. Try later.')
                    return
                source.remove(card)
                u.hands[0].append(card)
                u.uno_called.discard(0); u.announced = False
                if u.missed_uno == 0: u.missed_uno = None
                u.note = 'Fun mode: the host took a bonus '+card[1]+' card.'
                self.last_event = u.note
                self.last_move = None
            else:
                self._reject(seat, 'Unknown fun effect.')
                return
        else:
            self._reject(seat, 'Unknown host control.')
            return
        self.revision += 1
        self._broadcast()

    def close(self):
        with self.lock:
            if self.stop.is_set(): return
            self.stop.set()
            self.listener.close()
            self.checkpoint(force=True)
            for peer in self.peers:
                if peer:
                    peer.close()
            for sock in tuple(self.pending):
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                sock.close()


class RoomClient:
    def __init__(self, host, port, code, name, resume='', host_key='', profile=None):
        self.host, self.port, self.code, self.name = host, port, code, name
        self.resume, self.host_key = resume, host_key
        self.profile=cosmetics(profile); self.latency_ms=None; self.reconnect_attempt=0
        self.events = queue.Queue()
        self.outbox = queue.Queue(maxsize=24)
        self.stop = threading.Event()
        self.retry_now = threading.Event()
        self.sock = None
        self.connected = False
        threading.Thread(target=self._run, daemon=True, name='uno-client').start()

    def send(self, message):
        if not self.connected or self.stop.is_set():
            return False
        try:
            self.outbox.put_nowait(message)
            return True
        except queue.Full:
            return False

    def _run(self):
        retry = 0
        while not self.stop.is_set():
            try:
                self.reconnect_attempt=retry+1
                self.events.put({'type': 'connection', 'status': f'Reconnecting… attempt {retry+1}' if self.resume else 'Connecting…'})
                sock = socket.create_connection((self.host, self.port), timeout=4)
                self.sock = sock
                sock.settimeout(.15)
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                sock.sendall(encode({'type': 'hello', 'version': VERSION, 'room': self.code, 'name': self.name,
                                     'resume': self.resume, 'host_key': self.host_key,'profile':self.profile}))
                buffer = b''
                last_receive = last_ping = time.monotonic()
                ping_sent=None
                while not self.stop.is_set():
                    now = time.monotonic()
                    if now-last_receive > 15:
                        raise ConnectionError('Host stopped responding.')
                    if now-last_ping > 3:
                        sock.sendall(encode({'type': 'ping'}))
                        ping_sent=time.monotonic()
                        last_ping = now
                    if self.connected:
                        for _ in range(8):
                            try:
                                command = self.outbox.get_nowait()
                            except queue.Empty:
                                break
                            sock.sendall(encode(command))
                    try:
                        chunk = sock.recv(4096)
                    except socket.timeout:
                        continue
                    if not chunk:
                        raise ConnectionError('Connection closed.')
                    last_receive = now
                    buffer += chunk
                    while b'\n' in buffer:
                        line, buffer = buffer.split(b'\n', 1)
                        if len(line) > MAX_FRAME:
                            raise ValueError('Host message is too large.')
                        event = json.loads(line)
                        if not isinstance(event, dict):
                            raise ValueError('Invalid host message.')
                        if event.get('type') == 'welcome':
                            self.resume = event['resume']
                            self.connected = True
                            retry = 0
                        if event.get('type')=='pong' and ping_sent is not None:
                            self.latency_ms=max(0,round((time.monotonic()-ping_sent)*1000)); ping_sent=None
                            self.events.put({'type':'health','latency_ms':self.latency_ms})
                        if event.get('type') == 'error' and event.get('retryable'):
                            raise ConnectionError(event.get('message', 'Waiting to reconnect.'))
                        if event.get('type') == 'error' and event.get('fatal'):
                            if event.get('forget_resume'): self.resume = ''
                            self.events.put(event)
                            self.stop.set()
                            break
                        if event.get('type') != 'pong':
                            self.events.put(event)
                    if len(buffer) > MAX_FRAME:
                        raise ValueError('Host message is too large.')
            except (OSError, ValueError, UnicodeError, KeyError) as exc:
                self.events.put({'type': 'connection', 'status': 'Connection lost. Reconnecting…' if self.resume else 'Could not connect.', 'detail': str(exc)})
                if not self.resume:
                    self.events.put({'type': 'error', 'fatal': True,
                                     'message': connection_error(self.host, self.port, exc)})
                    self.stop.set()
            finally:
                self.connected = False
                if self.sock:
                    self.sock.close()
                    self.sock = None
                while not self.outbox.empty():
                    try:
                        self.outbox.get_nowait()
                    except queue.Empty:
                        break
            retry += 1
            self.retry_now.wait(min(5, retry))
            self.retry_now.clear()

    def retry_connection(self):
        """Wake the reconnect loop immediately after a user asks to retry."""
        if not self.stop.is_set() and not self.connected:
            self.retry_now.set()

    def close(self):
        self.stop.set()
        self.connected = False
        if self.sock:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

