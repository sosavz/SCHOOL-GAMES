# Playroom — UNO & Mensch ärgere dich nicht — Friends’ guide

**Two games are included: UNO and Mensch ärgere dich nicht, both for 2–6 players on separate PCs.** The host clicks one of the two illustrated game tiles on the home screen, or chooses the game in **Host settings**. Friends join the same way for either game, using just their name and the lobby code.

## Before you start: this copy uses the host’s local network

The host connection is built into this copy: **192.168.178.193**, port **47624**. You do not type an IP address or port in the game. You only enter your name and the host’s six-digit lobby code.

**This address works on the host’s Wi-Fi/LAN. It cannot reach the host from a different home or network.** If you are playing remotely, read “Playing from different networks” below before trying to join. A lobby code identifies the room; it does not create the connection between networks.

## 1. Get the game onto your PC

1. Get the current **UNO Together Windows.zip** from your host once. This copy includes automatic updates. Older copies need the new ZIP once to gain the updater.
2. Save the ZIP somewhere easy to find, such as Downloads.
3. Right-click the ZIP and choose **Extract All…**, then **Extract**. Open the extracted **UNO Together** folder.
4. Keep the whole folder together, including **runtime**. Do not move only the launcher or delete the other files. You do not need to install Python.
5. Double-click **Start UNO Together.cmd**. Run it from the extracted folder, not from inside the ZIP viewer.

The included portable runtime is for **64-bit Windows 10 or Windows 11**. You do not need an UNO account for local play.

## Automatic updates

Once the host sends you the current **UNO Together Windows.zip**, there is no account or one-time setup. Updates are downloaded from the public game page when you open **Start UNO Together.cmd**, even while the host PC is switched off. The game continues to open if the internet or update server is unavailable.

**After setup:** simply open **Start UNO Together.cmd** as usual. You do not need another ZIP for ordinary published game updates. The host must publish each new version first; changing files on their PC alone does not publish it. Changes to the bundled Python runtime occasionally require a new full ZIP.

**During an update:** keep the folder in place. Saved names, themes and other preferences remain on your PC. Updates never install during a match. You can choose **Play installed version** to skip a slow download; everyone should use the same version before playing together.

**If an update fails:** the existing game opens. Check **Settings → Updates** for the installed version and last result. Check internet access, then close and reopen the game. An interrupted installation is recovered on the next launch.

**Updates do not host multiplayer games.** Someone still needs to host the match, and the network connection described below is still required.

## 2. Join your friend’s lobby

1. Connect your PC to the same home Wi-Fi/LAN as the host. Use the remote setup below if you are elsewhere.
2. Ask the host to create a room and send you its current **six-digit lobby code**.
3. Open the game (its window is called **Playroom**) and enter your name in **YOUR NAME**. Choose a name your friends will recognize.
4. Under **My friend is hosting**, enter the code in the large box. Include any leading zero. Do not paste an IP address, invitation message or web link into this box.
5. Click **Join room →** or press **Enter** while the code box is selected. The host address and port are already built in.
6. In the lobby, check your name and the selected game, then click **Ready to play**. Everyone, including the host, must be connected and Ready before the game starts.

Your host should choose the number of people actually playing, including themselves. A six-seat lobby waits for six people. If only four people are playing, the host can change the waiting room to four seats using **Host settings** before starting.

The code changes whenever the host creates a new room. An old screenshot or yesterday’s code will not join the new room. If you already joined the same room on this PC, entering its code again automatically restores your saved seat.

## Optional lobby surprises

Video surprises are **off by default on every PC**. In the waiting room, a guest can opt in with **Allow full-screen surprise videos** beneath Chat. The host can then type `/jumpscare Exact Player Name` in the lobby chat; only that named, connected guest who opted in will see the bundled clip. Press **Esc** or **Close video** to stop it locally at any time. The host can type `/endjps` to send a stop signal. These commands work only before a game starts and do not change game state.

Type `/party` as host to open short table-wide effects: confetti, fireworks, sparkles, applause or a silly boo. In the waiting-room chat, `/küche` shows everyone a large, five-second kitchen-party banner. The menu also keeps the existing game-specific fun options.

## 3. Choose your design

Click **Settings** at the top of the window. Choose one of twelve designs:

- **Playroom:** a bright cream and purple design with rounded controls and illustrated game tiles. This is the new default.
- **Classic:** green card table and the familiar UNO card backs.
- **Spider-Man:** navy and red colors, web details and mask card backs.
- **Hello Kitty:** pink table, bow decorations and illustrated kitty card backs.
- **Formula 1:** dark racing table, track details and race-car card backs.
- **Starlight, Deep Sea, Woodland, Candy Clouds, Arcade and Sunset:** original space, ocean, forest, pastel, neon and warm evening designs.
- **Larissa:** a cozy kitchen with cabinets, tiled backsplash, sunny window, counter, sink, stove, herbs, a heart-framed name plaque for Weirauch, Banker and Chicowski, and a plate with crossed wooden spoons on card backs.

The host selects the shared room design in **Host settings** before play. Anyone can open **Settings** at any time, including during a match, and choose a personal design for their own screen. This does not change the design other players see or the host's shared room choice. The red, yellow, green and blue playing cards keep their normal meaning. In **Settings**, turn **Animations** off for instant moves, enable optional **Gentle sounds**, or hide the helpful hints. Sound starts off. Choose text size, high contrast, and Gentle or Playful animation pace here too. Press **F11** for fullscreen; press **Esc** to return. Your name and preferences are remembered on this PC. This redesign starts with Playroom once; later design choices stay saved.

**How to play** opens a three-step illustrated lesson for the selected game. Use **Next**, then **Let’s play**, or choose **All rules** for details. The side panel gives one short instruction for the current turn. The large buttons and glowing cards or pawns show what you can do next.

Cards slide into play, dice tumble before showing the host’s result, pawns hop between spaces, and wins get a confetti celebration. These effects follow the actual game result. Move buttons become available when an effect finishes; time-sensitive UNO calls and catches remain available.

## Practice against bots

On the home screen, choose UNO or Mensch ärgere dich nicht and set the player count to **2–6**, then click **Practice vs bots · this PC only**. You play as the host; bots fill the other seats and take their turns automatically. Practice rooms use a local-only connection, so friends cannot join them. Use this mode to test rules, themes and controls before hosting a multiplayer game.

## 4. Check the host’s rules

The lobby shows the selected game and its rules before you choose Ready. The host can change **Game** between **UNO** and **Mensch ärgere dich nicht** before play starts. A change clears everyone’s Ready vote. UNO has the following settings; board-game options are described in the next section.

- **Players:** 2–6, including the host.
- **UNO mode:** Classic is the default. Extreme lets Draw Two cards stack; the next player can add a +2 or draw the whole accumulated total and lose their turn. +4 cards never stack.
- **Starting cards:** 5, 7 or 10 per person. The classic setting is 7. An opening Draw Two gives the first player two extra cards and skips their turn.
- **Points to win:** 100, 250, 500 or 1,000. The classic target is 500.

**Classic UNO is the default:** a 108-card deck, seven starting cards, draw one card at a time and first to 500 points. No stacking, jump-in, 7–0 swaps or special theme cards are used. Extreme is an optional host-selected mode where only +2 cards stack. Custom choices are saved. The host can restore the classic defaults with **Use classic UNO · 7 cards / 500 points**.

**To change the waiting-room settings:** the host clicks **Host settings** beside the rules summary, changes the player count, **UNO rules**, **Cards to start**, **Points to win**, the turn timer, round limit, bot seats or shared room design, and clicks **Apply settings**. Use **Quick game**, **Standard**, or **Long night** as a starting preset; every value remains adjustable. Use **Use classic UNO · 7 cards / 500 points** to restore the original card and score defaults. Everyone sees the change immediately and must choose Ready again. Guests cannot change these settings.

**Game-night options:** turn timers are off by default. Choose 30, 45 or 60 seconds to show a countdown and have the host make a legal move automatically when time expires. UNO can end after 3, 5 or 10 rounds; set the round limit to 0 to play until someone reaches the point target. Add up to five **Easy**, **Normal** or **Hard** bots to an online lobby. Bots ready automatically. Friends take open seats first and can replace a bot before the first deal. **Practice vs bots** remains a private, local room on one PC.

You can add seats up to six without creating a new room. Reducing the count removes the highest-numbered seats first. Connected players in those seats must leave before they can be removed; offline reservations in removed seats are released. The other players and the room chat stay connected. Once the first round has started, settings are locked for that match; use **Host controls → Return everyone to lobby** to end the match and change them.

## 5. Play Mensch ärgere dich nicht

1. The host opens **Host settings**, chooses **Mensch ärgere dich nicht** under **Game**, selects 2–6 players, and clicks **Apply settings**. This works on the home screen or in an existing waiting room. Everyone checks the options and chooses **Ready to play**.
2. Find your player number and color on the scoreboard and board. Each player has four numbered pawns. One starts on the colored **arrow** square and three wait in base. The starting player is chosen by rolling the highest die, with ties rolled again.
3. When the banner says **YOUR TURN**, click the large **Roll die [Space]** button or press **Space**. Everyone sees the same result. Click a highlighted pawn or its **Pawn 1–4** button to move it. Number keys **1–4** also select a pawn. Point at a movable pawn to preview its destination.
4. A **six gives another roll**. While you still have pawns in base, a six must bring one onto your start square when it is free. If your own pawn is on the start square, you must move it away whenever possible; this clearing rule also applies to rolls other than six while pawns remain in base.
5. Landing on another player’s pawn sends it back to their base. Colored start squares are not safe squares. You may jump over pawns on the main track, but cannot land on your own. Capturing is optional if another move is legal.
6. After a full circuit, enter your own four-space colored **home lane (1–4)**. The roll must fit exactly: you cannot overshoot the end or land on your own pawn. Move all four pawns home to finish. The first finisher wins; the remaining players continue for the other places. Once one player remains, the final places appear.
7. Everyone selects the large **Ready for another game** button to play again. Finished players can watch and chat while the others finish.

Tables of 2–4 use a 40-space board. Tables of 5–6 use a 60-space, six-arm board. Two players use opposite colors. Moves and dice are checked by the host, and the board updates for every player. For solo testing, choose **Practice vs bots · this PC only** from the home screen; in a regular room, all seats are human players.

**Board-game lobby options:**

- **Three attempts:** off by default. When enabled, you get up to three tries for a six if your remaining pawns are in base and none of your home pawns can advance. If you have a movable home pawn, you get the normal single attempt. A six still gives an extra roll.
- **Allow jumping over your pawns inside the home lane:** on by default. Turn it off to block moves that would jump a pawn already in your home lane. Landing on your own pawn is always forbidden.

The options follow the publisher’s base rules and listed variants. No barriers, backward captures or forced-capture rule is included. The game menu and options lock after play starts; use **Host controls → Return everyone to lobby** to end the game and change them. **How to play** opens the rules for the selected game. Space and number shortcuts are inactive while typing or selecting text in chat. Themes change the surrounding interface; pawn colors stay consistent.

Rules reference: [Schmidt Spiele — Mensch ärgere dich nicht](https://www.schmidtspiele.de/files/Produkte/4/49020%20-%20Jubil%C3%A4umsausgabe/49020_49021_Mensch_aergere_Dich_nicht_DE.pdf).

## 6. Play a round of UNO

1. Watch the large banner above the table. **YOUR TURN** means you can act; otherwise it names the player whose turn it is. Their player tile is highlighted above the table. Player numbers show seat order, and the table shows the direction of play.
2. On your turn, click a card that matches the active color, number or symbol. Glowing borders and checkmarks identify playable cards.
3. For a Wild card, choose the next color in the popup. Press **Esc** to cancel the picker before playing.
4. To draw, click the draw pile or **Draw card**. If the new card is playable, you may play **only that newly drawn card**, or click **Keep & pass**.
5. With two cards left, click the large **UNO! [U]** button before playing down to one. If you forget, another player can use **Catch UNO!**, making you draw two. You can still call UNO late before someone catches you.
6. Empty your hand to win the round. You score the cards left in all opponents’ hands. Everyone clicks the wide **Ready for next round** button to continue; after someone reaches the score target or selected round limit, choose **Quick rematch · same table** to start fresh. Scores reset only when everyone opts in.

The large action buttons stay at the bottom left. **Draw card [D]**, **UNO! [U]**, **Keep & pass [P]**, and challenge actions light up when they are available. Disabled buttons cannot be used yet. **Cancel ready** withdraws your vote before everyone is ready.

**Skip** skips the next player. **Reverse** changes direction; with two players, it acts like Skip. In Classic, **Draw Two** makes the next player draw two and miss a turn. In Extreme, the player facing a +2 may stack a +2 from their hand, increasing the pile by two and passing the choice on, or draw the whole pile and miss their turn. Draw Four cards do not stack.

**Wild Draw Four** may be challenged by the next player. It is lawful only if the player had no card of the previous active color. A successful challenge makes the offender draw four; a failed challenge makes the challenger draw six and miss their turn. Only the challenger sees the challenged hand.

You may bluff with a +4, but the color picker warns you when your hand contains the active color. A matching number in another color does not make a +4 illegal. A regular Wild can be played even when you have a matching color.

If the last card is **Draw Two** or **Wild Draw Four**, its penalty is applied automatically before scoring, and the round ends immediately. The score panel shows the points contributed by each opponent’s remaining cards. A final +4 does not leave the table waiting for a challenge decision. The first dealer of a match is selected by drawing the highest number; action cards count as zero, and tied players draw again. The dealer rotates clockwise between rounds within that match.

Your hand is private. Other players normally see only its card count and card backs. Use the **‹ / ›** arrows below your hand if it spans several pages.

The **Sorted by color / As dealt** button below the cards switches between a sorted hand and the original order. Sorting only changes your own display. After drawing a playable card, its page opens automatically and **NEW** identifies it. The turn banner also names the new card. Other cards in your hand stay unavailable until the next turn.

**Keyboard shortcuts:** 1–7 = choose a card on the visible page; D = draw; U = call UNO; P = keep the drawn card and pass; R/Y/G/B = choose Red/Yellow/Green/Blue in the Wild picker; Esc = close the color picker (or leave fullscreen when no picker is open). Card shortcuts are inactive while you type or select text in chat.

## Chat with your table

1. Use **Chat** on the right side of the lobby or game table. Click the message box at the bottom, type your message, and press **Enter** or click **Send →**.
2. Every connected player in the room sees your message, your player number, name and the host’s local time. This is a group chat; there are no private messages. Messages are displayed as plain text.
3. Messages can contain up to **240 characters**. The counter shows your message length. If you send too quickly, wait a few seconds and retry; your draft stays in the box if the host rejects it.
4. Switch to **Activity** to read shared, timestamped game events such as plays, turn changes, captures, reconnects and host actions. The room sends one feed to everyone. The **Chat** tab shows a count of new messages while you are looking at Activity. Switch back to read them. You can scroll up to read earlier messages without being pulled back down by every new one.
5. The **Chat** button in the top bar hides or shows the whole sidebar to give the table more room. Your draft and history stay intact.
6. Chat stays available between rounds and while waiting for another player. A connected player can still chat when someone else is disconnected. Your unsent draft survives a design change, the first deal and an automatic reconnect.

The host keeps the latest **80 messages** for the current room in memory. New arrivals and reconnecting players receive this recent history. Closing the host ends the room and clears its chat; messages are not saved as a chat log on disk. Leaving clears your local chat view and draft. If your connection drops while sending, check the conversation before resending your kept draft.

Use the latest ZIP on **every PC**. This host-controls release uses protocol version 7. Everyone must update, including players using the previous two-game release. Close the old app before starting the updated copy.

## Host controls: manage your room

The room owner sees **Host controls** in the top bar, in both the waiting room and the game. Guests cannot use these commands. The host checks every request; opening a modified client does not grant owner permissions.

- **Kick:** remove a connected guest or an offline reservation. Their saved seat is revoked and automatic reconnect stops. If a game exists, kicking ends it, resets scores and returns everyone to the lobby. A confirmation explains this before you continue. The room code and chat stay intact.
- **Remove open seats:** in the lobby, close unused seats and renumber the remaining players without disconnecting them. Offline reservations remain until kicked. At least two seats remain. Everyone must choose Ready again. Use this after a kick if you want to continue with fewer people.
- **Mute / Unmute:** stop a guest from sending chat. They can still read messages and play. A replacement player does not inherit the mute.
- **Lock new joins / Unlock new joins:** prevent new players from taking free seats. Existing players can still reconnect using their saved seat. A kick is not a permanent ban: a removed person can join again with the room code if the room is unlocked and has space.
- **Pause / Resume:** freeze moves in either running game while leaving chat available. Only the host resumes. A disconnected player still needs to reconnect before play can continue.
- **Restart round:** in UNO, redeal the current round with the same dealer and keep match scores. In Mensch ärgere dich nicht, reset the board and choose a new starter. Everyone must be connected. Restart clears a host pause.
- **New match:** immediately start fresh with all players connected, resetting scores and progress. The confirmation explains the reset.
- **Return everyone to lobby:** end the game and reset scores, keeping the room code, connected players, chat, join lock and chat mutes. Change the game or rules through **Game settings**, then everyone chooses Ready again.

Commands are tied to the current room state. If someone moves or reconnects while a confirmation is open, the app may ask you to review the updated room and try again. Closing the host app still closes the whole room.

## 7. If someone disconnects

- A connection drop pauses play for everyone. Keep the game open; it tries to reconnect automatically.
- If you closed the game, reopen the same extracted copy and click **Resume last room**, or enter that room’s code again. The host must still have the room open.
- Keep the generated **uno_session.json** file beside your app. It remembers your seat. Each friend has their own session file; use the original ZIP when sending the game to someone new.
- Leaving or closing an active game asks for confirmation. Choose **Keep playing** to stay. Closing the host app ends the room. The current board, hand and scores are held in memory, so they cannot be recovered after the host closes it.
- A seat remains reserved while its player is disconnected. Before the first deal, the host can remove unused seats through Host settings; reducing the count releases offline reservations in removed seats. If someone permanently leaves, the host can kick their reserved seat. This ends the game and returns everyone to the lobby. Then use **Remove open seats** and choose Ready again.

## Playing from different networks

**This release’s fixed address, 192.168.178.193, is local. Installing Tailscale alone will not make this particular address reachable from another network.** You also need a game copy configured with the host’s reachable Tailscale address. The host can have that address built in, so friends still join using only a lobby code.

1. Everyone installs [Tailscale for Windows](https://tailscale.com/download/windows) and signs in to their own Tailscale account. Keep Tailscale connected.
2. The host opens their Tailscale admin console, goes to **Machines**, finds the PC running UNO and selects **Share → Copy invite link**. They send an invitation to each friend, or use a reusable invitation.
3. Open the invitation from your host and accept it while signed in. Find the shared host PC in your Tailscale app.
4. Tell the host the shared PC’s Tailscale IPv4 address as it appears to you. It normally begins with **100**. The host needs a game copy with that address built in; the current local address must be replaced. A full Tailscale hostname can also be used if the host’s setup supports it.
5. Everyone extracts the newly configured game copy. Keep Tailscale connected, have the host create a room, then enter your name and the current lobby code as usual.

Tailscale is separate software and is not included in the game ZIP. The host may need to allow the UNO/Python app through Windows Firewall on the network in use. Any custom Tailscale access policy must allow TCP connections to the host on port **47624**. No router port forwarding is needed with this setup.

Official help: [Tailscale quickstart](https://tailscale.com/docs/how-to/quickstart), [sharing a private game server](https://tailscale.com/docs/use-cases/personal-or-at-home-use/share-private-game-server), [sharing a device](https://tailscale.com/docs/features/sharing).

## Troubleshooting

**“Could not connect” or “connection timed out”** — Check the network requirement first. If you are in different homes, this local-address copy cannot connect directly. If you are on the same LAN, make sure the host room is open, the host PC still has 192.168.178.193, and Windows Firewall allows the app. Guest Wi-Fi can block devices from reaching each other.

**“Connection was refused”** — Ask the host to open a room and keep it open. They should close any duplicate UNO host window. The port is fixed to 47624.

**“Room code is incorrect”** — Get the current six digits from the host. Room codes are not Tailscale invitation links and are not IP addresses.

**“App versions do not match”** — Close the game and get the latest ZIP from your host. Everyone must use the same release.

**“This table is full”** — Use Resume last room if you already joined. Do not extract a second copy to try to take your old seat. If you are new and the first round has not started, the host can add a seat in Host settings. An active match needs a new room to add players.

**“Those seats still have connected players”** — The host tried to reduce the player count below an occupied seat. Players in the highest-numbered seats being removed must leave first. Existing connected players are never removed automatically.

**The lobby will not start** — Check the connected count, the chosen player count and every Ready status. A host settings change clears Ready votes.

**The game is paused** — Someone is disconnected. The banner above the table shows who is missing; play resumes when everyone reconnects.

**Reconnecting takes a moment** — Keep the window open. The previous connection may need to time out before your saved seat becomes available; the game retries automatically. Click **Reconnect now** to request an immediate retry. Your seat and game stay held while the room waits. If you opened two copies on the same PC, close the older copy first.

**The game will not open** — Extract the entire ZIP and keep its runtime folder. Send the host the contents of **uno_crash.log** if that file appears beside the launcher.

## Quick checklist for the host

1. Use the PC at the address built into this release. If the network address changes, the friends’ copy needs to be updated.
2. Open **Host settings**. Choose **Game**, 2–6 players, and that game’s options, then **Apply settings**. UNO offers starting hand size and score target; Mensch ärgere dich nicht offers three attempts and home-lane jumping.
3. Click **Create a room →**. Allow the app through Windows Firewall for your private home network if prompted.
4. Click **Copy code** and send those six digits to your friends. Send the original ZIP and this guide too; do not send your personal session file.
5. Everyone chooses Ready. Keep the host app open and the PC awake until you finish.

The redesigned app is called **Playroom**; the folder and launcher keep the familiar **UNO Together** name. Only UNO and Mensch ärgere dich nicht are included.

These are fan-made visual themes. The host-selected room theme is shared with everyone and does not change card colors or game rules.

Rules reference: [Mattel classic UNO](https://service.mattel.com/instruction_sheets/W2085.pdf), with the [two-player rules](https://service.mattel.com/instruction_sheets/J4299-0520.pdf) for two-person tables. The app supports two to six players.
