param(
    [Parameter(Mandatory=$true)][string]$VideoPath,
    [Parameter(Mandatory=$true)][string]$StopFile
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" WindowState="Maximized" Topmost="True"
        Background="Black" ShowInTaskbar="True" Focusable="True">
  <Grid>
    <MediaElement x:Name="Clip" LoadedBehavior="Manual" UnloadedBehavior="Stop"
                  Stretch="Uniform" Volume="0.8" />
    <Button x:Name="CloseButton" Content="Close video  ·  Esc" HorizontalAlignment="Right"
            VerticalAlignment="Top" Margin="18" Padding="18,10" FontSize="16"
            FontWeight="Bold" Foreground="White" Background="#CC20263E"
            BorderBrush="White" BorderThickness="2" Focusable="True" />
  </Grid>
</Window>
'@

$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$clip = $window.FindName('Clip')
$closeButton = $window.FindName('CloseButton')
$closeButton.Add_Click({ $window.Close() })
$window.Add_KeyDown({ if ($_.Key -eq [Windows.Input.Key]::Escape) { $window.Close() } })
$clip.Add_MediaEnded({ $window.Close() })
$clip.Add_MediaFailed({ $window.Close() })
$clip.Source = [Uri]::new((Resolve-Path -LiteralPath $VideoPath).Path)

$stopTimer = [Windows.Threading.DispatcherTimer]::new()
$stopTimer.Interval = [TimeSpan]::FromMilliseconds(200)
$stopTimer.Add_Tick({
    if (Test-Path -LiteralPath $StopFile) {
        Remove-Item -LiteralPath $StopFile -Force -ErrorAction SilentlyContinue
        $window.Close()
    }
})
$window.Add_Closed({ $stopTimer.Stop(); $clip.Stop() })
$window.Add_Loaded({ $clip.Play(); $stopTimer.Start() })
$window.ShowDialog() | Out-Null
