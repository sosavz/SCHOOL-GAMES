"""Small legal-move opponents for loopback practice games."""
import random


def choose_action(server, seat, state, difficulty='normal'):
    """Choose a legal action from the authoritative private snapshot for this seat."""
    view=state.get('game') or {}
    actions=[tuple(a) for a in view.get('actions',())]
    if not actions: return None
    if difficulty == 'easy':
        # Easy opponents deliberately make varied, legal choices.
        return random.choice(actions)
    game=server.game
    # Handle timing-sensitive calls and forced response phases first.
    for kind in ('uno_late','catch'):
        candidates=[a for a in actions if a[0]==kind]
        if candidates:
            if kind=='catch':
                missed=getattr(game,'missed_uno',None)
                if missed is not None and len(game.hands[missed])==1: return candidates[0]
            else: return candidates[0]
    if view.get('kind')=='maedn':
        if actions[0][0]=='roll': return actions[0]
        return max(actions,key=lambda action:_maedn_score(game,seat,action)+(5 if difficulty=='hard' else 0))
    if view.get('phase')=='challenge':
        audit=view.get('audit') or {}
        desired='challenge' if not audit.get('guilty',True) else 'accept'
        return next((a for a in actions if a[0]==desired),actions[0])
    if view.get('phase')=='audit': return next((a for a in actions if a[0]=='continue'),actions[0])
    hand=view.get('hand',())
    if len(hand)==2 and not view.get('called'):
        announce=next((a for a in actions if a[0]=='uno'),None)
        if announce: return announce
    plays=[a for a in actions if a[0] in ('play','stack')]
    if plays:
        if difficulty == 'hard':
            # Save wild cards when a colored play keeps the hand flexible.
            return max(plays,key=lambda action:_uno_score(hand,action)+(12 if action[0]=='play' and hand[action[1]][0]!='Wild' else 0))
        return max(plays,key=lambda action:_uno_score(hand,action))
    for kind in ('pass','draw','take_penalty','continue','accept'):
        action=next((a for a in actions if a[0]==kind),None)
        if action: return action
    return actions[0]


def _uno_score(hand,action):
    if action[0]=='stack': return 50
    index=action[1]
    color,value=hand[index]
    remaining=[c for i,c in enumerate(hand) if i!=index]
    color_count=sum(1 for c,_ in remaining if c==color)
    color_priority=0
    if color=='Wild':
        color_priority=sum(1 for c,_ in remaining if c==action[2])
    special=9 if value in ('Skip','Reverse','+2') else 0
    wild_cost=-3 if color=='Wild' else 0
    draw_penalty=2 if value in ('+2','+4') else 0
    return color_priority*6+color_count*4+special+draw_penalty+wild_cost


def _maedn_score(game,seat,action):
    piece=action[1]
    old=game.pieces[seat][piece]
    target=game.destination(seat,piece,game.die)
    if target is None: return -1000
    if target>=game.track_length: return 100+target-game.track_length
    score=(20 if old==-1 else max(0,target-old))
    cell=game.track_cell(seat,target)
    captures=sum(1 for other,pawns in enumerate(game.pieces) if other!=seat
                 for position in pawns if game.track_cell(other,position)==cell)
    return score+captures*35+random.random()
