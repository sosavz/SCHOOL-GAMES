"""Small pre-game updater. Network work never edits files or touches Tk."""
from pathlib import Path
import json
import queue
import runpy
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
import update_core as updates

ROOT=Path(__file__).resolve().parent


def startup_update(root):
    window=tk.Tk(); window.title('Playroom · Updates'); window.geometry('520x250')
    window.configure(bg='#f3f1eb'); window.resizable(False,False)
    tk.Label(window,text='Getting your table ready.',font=('Segoe UI',22,'bold'),bg='#f3f1eb',fg='#20263e').pack(pady=(25,10))
    note=tk.Label(window,text='Checking for a new version…',font=('Segoe UI',11),bg='#f3f1eb',fg='#697188',wraplength=470)
    note.pack(pady=5)
    bar=ttk.Progressbar(window,mode='indeterminate',length=440); bar.pack(pady=16); bar.start(15)
    inbox=queue.Queue(); cancel=threading.Event(); finished=[False]; fatal=[None]
    def status(message):
        try: updates.atomic_json(root/'update_status.json',{'message':message,'checked':time.strftime('%Y-%m-%d %H:%M')})
        except OSError: pass
    def close():
        if finished[0]: return
        cancel.set(); finished[0]=True; bar.stop(); window.destroy()
    skip=tk.Button(window,text='Play installed version',command=close,font=('Segoe UI',11,'bold'),relief='flat',
                   bg='#e9e7f5',fg='#20263e',padx=16,pady=8)
    skip.pack(); window.protocol('WM_DELETE_WINDOW',close)
    def worker():
        try:
            manifest=updates.check(root)
            if cancel.is_set(): return
            if manifest is None: inbox.put(('done','You have the latest version.')); return
            inbox.put(('note','Downloading version '+manifest['version']+'…'))
            data=updates.download(manifest['package'],manifest['size'],
                                  progress=lambda a,b:inbox.put(('progress',(a,b))),cancel=cancel)
            updates.verify_package(manifest,data)
            if not cancel.is_set(): inbox.put(('install',(manifest,data)))
        except Exception as exc:
            if not cancel.is_set(): inbox.put(('error',str(exc)))
    def poll():
        if finished[0]: return
        try:
            while True:
                kind,value=inbox.get_nowait()
                if kind=='note': note.configure(text=value)
                elif kind=='progress':
                    bar.stop(); bar.configure(mode='determinate',maximum=max(1,value[1]),value=value[0])
                elif kind=='install':
                    skip.configure(state='disabled'); window.protocol('WM_DELETE_WINDOW',lambda:None)
                    note.configure(text='Installing the update…'); window.update_idletasks()
                    try:
                        updates.install(root,*value)
                        status('Updated to '+value[0]['version']+'.')
                    except Exception as exc:
                        status('Update could not be installed: '+str(exc))
                        # install rolls back; if recovery itself fails, do not launch a mixed version.
                        try: updates.recover(root)
                        except Exception as recovery_error: fatal[0]=recovery_error
                        note.configure(text='Update didn’t install. Opening your previous version.')
                    close(); return
                elif kind=='done': status(value); close(); return
                elif kind=='error':
                    status('Could not check/download public updates. Kept the installed version. '+value)
                    note.configure(text='Updates are unavailable. Opening your installed game…')
                    window.after(650,close); return
        except queue.Empty: pass
        window.after(40,poll)
    threading.Thread(target=worker,daemon=True,name='playroom-update-check').start()
    window.after(40,poll)
    window.mainloop()
    if fatal[0] is not None: raise fatal[0]


def main(root=ROOT,game_runner=None,update_runner=startup_update):
    root=Path(root).resolve()
    try:
        with updates.GameLock(root):
            updates.recover(root)
            update_runner(root)
            sys.path.insert(0,str(root)); sys.dont_write_bytecode=True
            if game_runner: game_runner()
            else: runpy.run_path(str(root/'uno_app.py'),run_name='__main__')
    except Exception as exc:
        messagebox.showerror('Playroom',str(exc))


if __name__=='__main__': main()
