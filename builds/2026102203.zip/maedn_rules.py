"""Mensch ärgere dich nicht: authoritative dice, captures, home lanes and places."""
import secrets


class Maedn:
    def __init__(self, player_count=4, three_rolls=False, home_jumping=True, starter=None):
        if type(player_count) is not int or not 2 <= player_count <= 6:
            raise ValueError('Choose between 2 and 6 players.')
        if type(three_rolls) is not bool or type(home_jumping) is not bool:
            raise ValueError('Board-game options must be on or off.')
        if starter is not None and (type(starter) is not int or not 0 <= starter < player_count):
            raise ValueError('Invalid starting player.')
        self.player_count = player_count
        self.three_rolls, self.home_jumping = three_rolls, home_jumping
        self.board_sides = 4 if player_count <= 4 else 6
        self.track_length = self.board_sides * 10
        self.slots = [0, 2] if player_count == 2 else list(range(player_count))
        # Publisher setup: one pawn on A, the other three in the base (B).
        self.pieces = [[0, -1, -1, -1] for _ in range(player_count)]
        self.rankings = []
        self.winner = None
        self.done = False
        self.die = None
        self.die_owner = None
        self.phase = 'roll'
        self.last_capture = None
        self.opening_rolls = []
        if starter is None:
            contenders = list(range(player_count))
            while len(contenders) > 1:
                rolls = [(seat, self.roll_die()) for seat in contenders]
                self.opening_rolls.append(rolls)
                high = max(value for _, value in rolls)
                contenders = [seat for seat, value in rolls if value == high]
            starter = contenders[0]
        self.turn = starter
        self.tries_left = self.turn_tries()
        self.note = f'P{self.turn+1} starts. Roll the die, then choose a highlighted pawn.'

    @staticmethod
    def roll_die():
        return secrets.randbelow(6)+1

    def track_cell(self, seat, progress):
        return (self.slots[seat]*10+progress) % self.track_length if 0 <= progress < self.track_length else None

    def destination(self, seat, piece, die):
        old = self.pieces[seat][piece]
        if old == -1:
            if die != 6: return None
            target = 0
        else:
            target = old+die
        if target > self.track_length+3 or target in self.pieces[seat]: return None
        if not self.home_jumping and target >= self.track_length:
            if any(max(old, self.track_length-1) < pos < target for pos in self.pieces[seat]): return None
        return target

    def movable(self, seat, die):
        choices = [i for i in range(4) if self.destination(seat, i, die) is not None]
        if -1 in self.pieces[seat]:
            # Clear A whenever possible while other pawns are waiting in B.
            start_piece = next((i for i, pos in enumerate(self.pieces[seat]) if pos == 0), None)
            if start_piece in choices: return [start_piece]
            if die == 6 and start_piece is None:
                return [i for i in choices if self.pieces[seat][i] == -1]
        return choices

    def turn_tries(self):
        hand = self.pieces[self.turn]
        eligible = (-1 in hand and not any(0 <= pos < self.track_length for pos in hand)
                    and not any(self.destination(self.turn, i, die) is not None
                                for i, pos in enumerate(hand) if pos >= self.track_length for die in range(1, 7)))
        return 3 if self.three_rolls and eligible else 1

    def actions_for(self, seat):
        if self.done or seat != self.turn: return []
        if self.phase == 'roll': return [('roll',)]
        return [('move', i) for i in self.movable(seat, self.die)]

    def advance(self, repeat=False):
        if not repeat or self.turn in self.rankings:
            self.turn = (self.turn+1) % self.player_count
            while self.turn in self.rankings:
                self.turn = (self.turn+1) % self.player_count
        self.phase = 'roll'
        self.tries_left = self.turn_tries()

    def perform(self, seat, action):
        if (type(seat) is not int or not isinstance(action, tuple) or
                any(type(value) not in (str, int) for value in action) or action not in self.actions_for(seat)):
            return False
        self.last_capture = None
        if action[0] == 'roll':
            self.die = self.roll_die()
            self.die_owner = seat
            self.tries_left -= 1
            self.note = f'P{seat+1} rolled {self.die}.'
            if self.movable(seat, self.die):
                self.phase = 'move'
                self.note += ' Choose a highlighted pawn.'
            elif self.die == 6:
                self.advance(repeat=True)
                self.note += ' No legal move; a six gives another roll.'
            elif self.tries_left > 0:
                self.note += f' No legal move; {self.tries_left} attempts left.'
            else:
                self.advance()
                self.note += f' No legal move. P{self.turn+1} rolls next.'
            return True
        piece = action[1]
        old = self.pieces[seat][piece]
        target = self.destination(seat, piece, self.die)
        cell = self.track_cell(seat, target)
        if cell is not None:
            for other, pawns in enumerate(self.pieces):
                if other == seat: continue
                for pawn, pos in enumerate(pawns):
                    if self.track_cell(other, pos) == cell:
                        self.pieces[other][pawn] = -1
                        self.last_capture = {'seat': other, 'piece': pawn}
        self.pieces[seat][piece] = target
        self.note = (f'P{seat+1} brought pawn {piece+1} onto the board.' if old == -1 else
                     f'P{seat+1} moved pawn {piece+1} by {self.die}.')
        if self.last_capture:
            self.note += f' P{self.last_capture["seat"]+1}’s pawn goes back to base!'
        if all(pos >= self.track_length for pos in self.pieces[seat]):
            self.rankings.append(seat)
            if self.winner is None: self.winner = seat
            self.note += f' P{seat+1} finishes in place {len(self.rankings)}!'
            if len(self.rankings) == self.player_count-1:
                self.rankings.extend(i for i in range(self.player_count) if i not in self.rankings)
                self.done, self.phase = True, 'finished'
                self.note += f' Game complete. P{self.winner+1} wins!'
                return True
        repeat = self.die == 6 and seat not in self.rankings
        self.advance(repeat=repeat)
        self.note += ' Roll again for your six.' if repeat else f' P{self.turn+1} rolls next.'
        return True

    def snapshot(self, seat):
        destinations = {str(action[1]): self.destination(seat, action[1], self.die)
                        for action in self.actions_for(seat) if action[0] == 'move'}
        return {'kind': 'maedn', 'pieces': [list(pawns) for pawns in self.pieces],
                'board_sides': self.board_sides, 'track_length': self.track_length, 'slots': list(self.slots),
                'turn': self.turn, 'phase': self.phase, 'die': self.die, 'die_owner': self.die_owner,
                'tries_left': self.tries_left, 'rankings': list(self.rankings), 'winner': self.winner,
                'done': self.done, 'note': self.note, 'last_capture': self.last_capture,
                'opening_rolls': self.opening_rolls,
                'home_counts': [sum(pos >= self.track_length for pos in pawns) for pawns in self.pieces],
                'actions': self.actions_for(seat),
                'destinations': destinations}
