"""Responsive four- and six-arm boards drawn directly with Tkinter."""
import math
import tkinter as tk

from uno_art import rounded

PAWN_COLORS = ('#d9363e', '#25955b', '#e5bd24', '#287ec3', '#8a53bc', '#e47c25')
PAWN_NAMES = ('Red', 'Green', 'Yellow', 'Blue', 'Purple', 'Orange')


def board_layout(sides):
    radius = 5 if sides == 4 else 6
    track, homes, bases, labels = [], [], [], []
    for slot in range(sides):
        angle = math.pi+slot*2*math.pi/sides
        nxt = angle+2*math.pi/sides
        vx, vy = math.cos(angle), math.sin(angle)
        nx, ny = -vy, vx
        wx, wy = math.cos(nxt), math.sin(nxt)
        tx, ty = -wy, wx
        track.extend((vx*(radius-i)+nx, vy*(radius-i)+ny) for i in range(5))
        track.extend((wx*r-tx, wy*r-ty) for r in range(radius-3, radius+1))
        track.append((wx*radius, wy*radius))
        homes.append([(vx*(radius-1-i), vy*(radius-1-i)) for i in range(4)])
        middle = angle+math.pi/sides
        br = 4.9 if sides == 4 else 5.8
        bx, by = math.cos(middle)*br, math.sin(middle)*br
        bases.append([(bx+dx, by+dy) for dx, dy in ((-.5,-.5),(.5,-.5),(-.5,.5),(.5,.5))])
        labels.append((math.cos(middle)*(br+1.35), math.sin(middle)*(br+1.35)))
    return track, homes, bases, labels


class MaednView:
    def build_maedn(self):
        scores = tk.Frame(self.body, bg=self.PANEL, padx=12, pady=5)
        scores.pack(fill='x', pady=(0,10))
        columns = min(3, self.state['player_count'])
        self.board_score_labels = []
        for col in range(columns): scores.columnconfigure(col, weight=1, uniform='board-scores')
        for seat in range(self.state['player_count']):
            label = self.label(scores, '', 10, bold=True, anchor='w')
            label.grid(row=seat//columns, column=seat%columns, sticky='ew', padx=5, pady=4)
            self.board_score_labels.append(label)
        stage = tk.Frame(self.body, bg=self.BG); stage.pack(fill='both', expand=True)
        self.build_chat(stage)
        left = tk.Frame(stage, bg=self.BG); left.pack(side='left', fill='both', expand=True)
        self.turn_panel = tk.Frame(left, bg=self.PANEL, padx=14, pady=10)
        self.turn_panel.pack(fill='x', pady=(0,6))
        self.turn_label = self.label(self.turn_panel, '', 22, self.GOLD, True, anchor='w')
        self.turn_label.pack(fill='x')
        self.phase_label = self.label(self.turn_panel, '', 10, self.MUTED, anchor='w', justify='left')
        self.phase_label.pack(fill='x', pady=(3,0))
        self.banner = self.label(left, '', 10, self.MUTED, anchor='w', justify='left', height=2)
        self.banner.pack(fill='x', pady=(0,4))
        left.bind('<Configure>', lambda e: (self.phase_label.configure(wraplength=max(200,e.width-32)),
                                            self.banner.configure(wraplength=max(200,e.width-8))))
        self.controls = tk.Frame(left, bg=self.BG)
        self.controls.pack(side='bottom', fill='x', pady=(10,0))
        for col in range(4): self.controls.columnconfigure(col, weight=1, uniform='board-actions')
        self.canvas = tk.Canvas(left, bg=self.BG, highlightthickness=0, takefocus=True)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Configure>', lambda e: self.draw())
        self.canvas.bind('<Button-1>', self.click)
        self.canvas.bind('<Motion>', self.on_hover)
        self.canvas.bind('<Leave>', lambda e: self.set_hover(None))

    def update_maedn(self):
        game = self.state['game']
        paused = not self.linked() or not all(self.state['connected'])
        for seat, label in enumerate(self.board_score_labels):
            slot = game['slots'][seat]
            rank = game['rankings'].index(seat)+1 if seat in game['rankings'] else None
            suffix = f'#{rank}' if rank else f'{game["home_counts"][seat]}/4 home'
            label.configure(text=('▶ ' if seat == game['turn'] and not game['done'] else '')+
                            f'P{seat+1} {self.short_name(seat,10)} · {PAWN_NAMES[slot]} · {suffix}')
        mine = game['turn'] == self.seat and not game['done'] and not paused
        if paused:
            title = 'GAME PAUSED'
            missing = ', '.join(self.short_name(i,12) for i,c in enumerate(self.state['connected']) if not c)
            hint = 'Reconnecting to the host…' if not self.linked() else f'Waiting for {missing} to reconnect.'
        elif game['done']:
            title = 'YOU WON!' if game['winner'] == self.seat else self.short_name(game['winner'],16)+' wins!'
            hint = 'All places are decided. Choose Ready for another game.'
        else:
            title = f'YOUR TURN · P{self.seat+1}' if mine else f'P{game["turn"]+1} · {self.short_name(game["turn"],16)}’s turn'
            if mine:
                hint = (f'Roll the die · {game["tries_left"]} attempt'+('s' if game['tries_left'] != 1 else '')+' available.'
                        if game['phase'] == 'roll' else f'You rolled {game["die"]}. Click a highlighted pawn, or its button below.')
            elif self.seat in game['rankings']:
                hint = f'You finished in place {game["rankings"].index(self.seat)+1}. Watch the remaining players and chat.'
            else:
                hint = f'Waiting for {self.short_name(game["turn"],16)}. Your color is {PAWN_NAMES[game["slots"][self.seat]]}.'
        if self.pending and not paused: hint = 'Sending your choice to the host…'
        bg = self.GREEN if mine else self.PANEL
        self.turn_panel.configure(bg=bg)
        self.turn_label.configure(text=title,bg=bg,fg=self.BUTTON_TEXT if mine else self.GOLD)
        self.phase_label.configure(text=hint,bg=bg,fg=self.BUTTON_TEXT if mine else self.MUTED)
        self.banner.configure(text=self.error_text or self.display_note(game['note']),fg=self.ERROR if self.error_text else self.MUTED)
        self.title(('Your turn! · ' if mine else '')+'Mensch ärgere dich nicht · Room '+self.state['room'])
        for child in self.controls.winfo_children(): child.destroy()
        if game['done']:
            button = self.button(self.controls,'Cancel ready' if self.state['ready'][self.seat] else 'Ready for another game',
                                 self.toggle_ready,large=True)
            button.grid(row=0,column=0,columnspan=3,sticky='ew',padx=(0,8))
            button.configure(state='normal' if self.linked() and not self.pending else 'disabled')
            self.label(self.controls,f'{sum(self.state["ready"])}/{self.state["player_count"]} ready',10,self.MUTED).grid(row=0,column=3)
        elif game['phase'] == 'move' and game['turn'] == self.seat:
            for piece in range(4):
                action = ('move',piece)
                button = self.button(self.controls,f'Pawn {piece+1}',lambda a=action:self.send_action(a),large=True)
                button.configure(padx=8,state='normal' if action in self.actions() else 'disabled')
                button.grid(row=0,column=piece,sticky='ew',padx=(0,6))
        else:
            button = self.button(self.controls,'Roll die  [Space]',lambda:self.send_action(('roll',)),large=True)
            button.grid(row=0,column=0,columnspan=2,sticky='ew',padx=(0,8))
            button.configure(state='normal' if ('roll',) in self.actions() else 'disabled')
            self.label(self.controls,'Four pawns home to finish\nSix = another roll',10,self.MUTED).grid(row=0,column=2,columnspan=2)
        self.draw_maedn()

    def board_shortcut(self, piece=None):
        if self.scene != 'maedn' or isinstance(self.focus_get(),(tk.Entry,tk.Text)): return
        self.send_action(('roll',) if piece is None else ('move',piece))

    def draw_maedn(self):
        if self.scene != 'maedn' or not self.state or not hasattr(self,'canvas') or not self.canvas.winfo_exists(): return
        c, game = self.canvas, self.state['game']
        c.delete('all'); self.hits = []
        width, height = max(100,c.winfo_width()), max(100,c.winfo_height())
        rounded(c,2,2,width-2,height-2,18,fill=self.BOARD,outline=self.BORDER,width=2)
        sides, length = game['board_sides'], game['track_length']
        track, homes, bases, labels = board_layout(sides)
        extent = 6.4 if sides == 4 else 7.4
        scale = min((width-28)/(2*extent),(height-44)/(2*extent))
        cx, cy = width/2, height/2+3
        def xy(point): return cx+point[0]*scale, cy+point[1]*scale
        r = scale*.36
        ink = self.TEXT
        self.text(width/2,16,'MENSCH ÄRGERE DICH NICHT',10,ink)
        for i, point in enumerate(track):
            x,y = xy(point); xx,yy = xy(track[(i+1)%length])
            c.create_line(x,y,xx,yy,fill=self.BORDER,width=max(1,scale*.07))
        for index, point in enumerate(track):
            x,y = xy(point)
            slot = index//10 if index%10 == 0 else None
            active = slot in game['slots'] if slot is not None else False
            color = PAWN_COLORS[slot] if active else self.TILE
            c.create_oval(x-r,y-r,x+r,y+r,fill=color,outline=self.BORDER,width=1)
            if slot is not None: self.text(x,y,'A',max(7,scale*.27),'#17251d' if slot == 2 else 'white' if active else self.TEXT)
        for slot in range(sides):
            active = slot in game['slots']
            color = PAWN_COLORS[slot] if active else self.MUTED
            for i, point in enumerate(homes[slot]):
                x,y = xy(point)
                c.create_oval(x-r,y-r,x+r,y+r,fill=self.TILE,outline=color,width=max(2,scale*.10))
                self.text(x,y,'abcd'[i],max(7,scale*.25),ink)
            for point in bases[slot]:
                x,y = xy(point)
                c.create_oval(x-r,y-r,x+r,y+r,fill=self.ACTIVE,outline=color,width=2)
            if active:
                seat = game['slots'].index(slot)
                x,y = xy(labels[slot])
                lx,ly = labels[slot]
                anchor = ('e' if lx < 0 else 'w') if abs(lx) > .1 else ('s' if ly < 0 else 'n')
                self.text(x,y,f'P{seat+1} · {self.short_name(seat,9)}'+(' · You' if seat == self.seat else ''),
                          max(7,min(10,scale*.29)),ink,anchor=anchor)
        def pawn_point(seat,piece,pos):
            slot = game['slots'][seat]
            return bases[slot][piece] if pos == -1 else homes[slot][pos-length] if pos >= length else track[(slot*10+pos)%length]
        actions = self.actions()
        if self.hover and self.hover[0] == 'move' and self.hover in actions:
            piece = self.hover[1]
            target = game['destinations'].get(str(piece))
            if target is not None:
                x,y = xy(pawn_point(self.seat,piece,game['pieces'][self.seat][piece]))
                xx,yy = xy(pawn_point(self.seat,piece,target))
                c.create_line(x,y,xx,yy,fill=self.GREEN,width=2,dash=(4,3),arrow='last')
                c.create_oval(xx-r-3,yy-r-3,xx+r+3,yy+r+3,outline=self.GREEN,width=2,dash=(3,2))
        for seat,pawns in enumerate(game['pieces']):
            slot = game['slots'][seat]
            for piece,pos in enumerate(pawns):
                x,y = xy(pawn_point(seat,piece,pos))
                action = ('move',piece)
                playable = seat == self.seat and action in actions
                if playable: c.create_oval(x-r-4,y-r-4,x+r+4,y+r+4,outline=self.GOLD,width=3)
                c.create_oval(x-r,y-r+2,x+r,y+r+2,fill=self.BORDER,outline='')
                c.create_oval(x-r,y-r,x+r,y+r,fill=PAWN_COLORS[slot],outline=self.TEXT,width=2)
                c.create_oval(x-r*.55,y-r*.65,x-r*.1,y-r*.2,fill='#ffffff',outline='')
                self.text(x,y+1,str(piece+1),max(7,scale*.31),'#17251d' if slot == 2 else 'white')
                if playable: self.hits.append((x-r-4,y-r-4,x+r+4,y+r+4,action))
        # A central die fits between all home lanes; it can also be clicked to roll.
        die_size = scale*(1.2 if sides == 4 else 2.25)
        dx,dy = cx-die_size/2,cy-die_size/2
        rounded(c,dx,dy,dx+die_size,dy+die_size,7,fill=self.PANEL,outline=self.GOLD,width=2)
        value = game['die']
        patterns = {1:[(0,0)],2:[(-1,-1),(1,1)],3:[(-1,-1),(0,0),(1,1)],
                    4:[(-1,-1),(-1,1),(1,-1),(1,1)],5:[(-1,-1),(-1,1),(0,0),(1,-1),(1,1)],
                    6:[(-1,-1),(-1,0),(-1,1),(1,-1),(1,0),(1,1)]}
        if value:
            dot = die_size*.075
            for a,b in patterns[value]:
                x,y = cx+a*die_size*.26,cy+b*die_size*.26
                c.create_oval(x-dot,y-dot,x+dot,y+dot,fill=self.TEXT,outline='')
        else: self.text(cx,cy,'?',max(10,die_size*.36),ink)
        if ('roll',) in actions: self.hits.append((dx,dy,dx+die_size,dy+die_size,('roll',)))
        caption = (f'Last roll: P{game["die_owner"]+1} → {value}' if value else 'Roll the die to begin')
        self.text(width/2,height-13,caption+' · A = start · a–d = home',8,ink)
        if game['done']:
            self.hits = []
            box_w,box_h = min(width-32,500),min(height-28,310)
            x,y = (width-box_w)/2,(height-box_h)/2
            rounded(c,x,y,x+box_w,y+box_h,14,fill=self.PANEL,outline=self.GOLD,width=2)
            self.text(width/2,y+27,'FINAL PLACES',17,self.GOLD)
            for place,seat in enumerate(game['rankings'],1):
                self.text(width/2,y+54+place*min(29,(box_h-95)/len(game['rankings'])),
                          f'{place}.  {self.short_name(seat,20)}',13,self.GOLD if place == 1 else self.TEXT)

    def show_maedn_rules(self):
        window = tk.Toplevel(self); window.title('How to play · Mensch ärgere dich nicht')
        window.geometry('690x640'); window.configure(bg=self.PANEL)
        content = tk.Text(window,bg=self.PANEL,fg=self.TEXT,font=('Segoe UI',11),wrap='word',padx=24,pady=20,spacing3=10,relief='flat')
        content.pack(fill='both',expand=True)
        content.insert('1.0', '''MENSCH ÄRGERE DICH NICHT · 2–6 PLAYERS
Each player has four numbered pawns. One begins on the colored start square with an arrow; three wait in base. The host rolls to choose the starter. Tables of up to four use a 40-space board; five or six players use 60 spaces.

ROLL, THEN CHOOSE A PAWN
Click Roll die or press Space. Click a highlighted pawn, or use Pawn 1–4 / number keys. The destination is previewed when you point at a movable pawn. Dice are generated on the host and shared with everyone.

SIXES AND YOUR START
A six gives another roll. While pawns remain in base, a six must bring one onto the start square when it is free. If your own pawn occupies the start, move it first whenever possible. This clearing rule also applies to other rolls while pawns wait in base.

CAPTURES
Land on an opponent to send their pawn back to base. You may jump over pawns on the main track, but cannot land on your own pawn. Colored start squares do not protect you. Capturing is optional when another legal move exists.

HOME AND FINISHING
After a full circuit, enter your own four-space colored home lane. Use the exact roll; you cannot overshoot the end or land on your own pawn. All four pawns home gives you a finishing place. Finished players wait while the remaining players continue. The first finisher wins; once only one remains, the final places are shown.

LOBBY OPTIONS
The host can enable Three attempts: when all remaining pawns are in base and no home pawn can advance, you get up to three tries for a six. It is off by default. Jumping over pawns inside your home lane is allowed by default; the host can turn it off. No barriers, backward captures or forced-capture variant is used.

CONNECTIONS
Chat, automatic reconnects and saved seats work as in UNO. Play pauses if anyone disconnects. Before starting, use Host settings to choose the game, player count and options. Everyone must Ready again after changes.
''')
        content.configure(state='disabled')
        self.button(window,'Close',window.destroy,secondary=True).pack(pady=12)
