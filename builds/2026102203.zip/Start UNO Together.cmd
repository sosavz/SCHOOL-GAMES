@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0runtime\pythonw.exe" (
    start "" "%~dp0runtime\pythonw.exe" -E "%~dp0launcher.py"
    exit /b
)
if exist "%~dp0..\development-kit\tools\python314\pythonw.exe" (
    start "" "%~dp0..\development-kit\tools\python314\pythonw.exe" -E "%~dp0launcher.py"
    exit /b
)
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3 "%~dp0launcher.py"
    exit /b
)
where python >nul 2>nul
if %errorlevel% equ 0 (
    python "%~dp0launcher.py"
    exit /b
)
echo Extract the complete UNO Together Windows ZIP before starting.
echo Keep the runtime folder beside uno_app.py.
pause
