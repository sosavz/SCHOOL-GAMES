"""Playroom menus, guided turns, accessible controls and visual feedback."""
import copy
import math
from pathlib import Path
import time
import tkinter as tk
from uno_net import GAMES, DEFAULT_PORT
from uno_themes import THEMES
from uno_art import rounded, paint_uno_card
from playroom_widgets import SoftButton, GameTile, Surface, mix, pawn, die
from playroom_table import TableVisuals
from host_controls import HostControls


class PlayroomUI(HostControls, TableVisuals):
    def __init__(self):
        self.fx=None; self.fx_job=None; self.hover_job=None; self.hover_amount={}
        self.chat_visible=True; self.fullscreen=False; self.ui_dialog=None
        super().__init__()
        self.minsize(960,680)
        self.geometry('1320x900')
        self.bind('<Configure>',self.resize_home,add='+')
        self.bind('<F11>',self.toggle_fullscreen)
        self.protocol('WM_DELETE_WINDOW',self.request_close)
        for i in range(7): self.bind(f'<Key-{i+1}>',lambda e,n=i:self.number_shortcut(n))
        for key,color in (('r','Red'),('y','Yellow'),('g','Green'),('b','Blue')):
            self.bind(f'<Key-{key}>',lambda e,col=color:self.color_shortcut(col))

    def paint(self): return {key:getattr(self,key) for key in THEMES[self.active_design()]}

    def button(self,parent,text,command,secondary=False,danger=False,large=False):
        return SoftButton(parent,text,command,self.paint(),secondary,large)

    def build_header(self):
        if hasattr(self,'header'): self.header.destroy()
        self.header=tk.Frame(self,bg=self.BG,padx=24,pady=13)
        self.header.pack(fill='x',before=self.body)
        mark=tk.Canvas(self.header,width=38,height=38,bg=self.BG,highlightthickness=0)
        mark.pack(side='left',padx=(0,10))
        rounded(mark,1,1,37,37,12,fill=self.GREEN,outline='')
        mark.create_oval(10,9,17,16,fill='white',outline=''); mark.create_oval(22,9,29,16,fill='white',outline='')
        mark.create_arc(10,14,29,29,start=185,extent=170,style='arc',outline='white',width=3)
        self.label(self.header,'playroom',20,self.TEXT,True).pack(side='left')
        self.connection_label=self.label(self.header,'Your people. Your table.',10,self.MUTED)
        self.connection_label.pack(side='left',padx=18)
        self.button(self.header,'Settings',self.show_appearance,secondary=True).pack(side='right',padx=(7,0))
        self.button(self.header,'How to play',self.show_rules,secondary=True).pack(side='right',padx=(7,0))
        self.button(self.header,'Chat',self.toggle_chat,secondary=True).pack(side='right')
        self.manage_button=self.button(self.header,'Host controls',self.show_host_controls,secondary=True)

    def toggle_fullscreen(self,event=None):
        self.fullscreen=not self.fullscreen; self.attributes('-fullscreen',self.fullscreen)
        return 'break'

    def toggle_chat(self):
        if not self.state: return
        self.chat_visible=not self.chat_visible; self.scene=''; self.update_view()

    def clear_body(self):
        if self.hover_job:
            self.after_cancel(self.hover_job); self.hover_job=None
        self.hover_amount={}
        super().clear_body()

    def field(self,parent,label,variable,width=None):
        self.label(parent,label,10,self.MUTED,True).pack(anchor='w',pady=(8,5))
        entry=tk.Entry(parent,textvariable=variable,font=('Segoe UI',15),bg=self.ENTRY,fg=self.TEXT,
                       insertbackground=self.TEXT,relief='flat',width=width,highlightthickness=2,
                       highlightbackground=self.BORDER,highlightcolor=self.GREEN)
        entry.pack(fill='x',ipady=9)
        return entry

    def show_home(self):
        if hasattr(self,'manage_button'): self.manage_button.pack_forget()
        self.clear_body(); self.scene='home'; self.title('Playroom · UNO & Mensch ärgere dich nicht')
        self.connection_label.configure(text='2–6 friends · Two great games')
        intro=tk.Frame(self.body,bg=self.BG); intro.pack(fill='x',pady=(0,8))
        self.label(intro,'A little play. A lot of fun.',31,self.TEXT,True).pack(side='left')
        who=tk.Frame(intro,bg=self.BG); who.pack(side='right',padx=(10,0))
        self.label(who,'YOUR NAME',8,self.MUTED,True).pack(anchor='w')
        self.name_entry=tk.Entry(who,textvariable=self.name,font=('Segoe UI',12),width=18,bg=self.PANEL,fg=self.TEXT,
                            insertbackground=self.TEXT,relief='flat',highlightthickness=2,highlightbackground=self.BORDER,highlightcolor=self.GREEN)
        self.name_entry.pack(ipady=7)
        line=tk.Frame(self.body,bg=self.BG); line.pack(fill='x',pady=(0,7))
        self.label(line,'1   PICK YOUR GAME',10,self.MUTED,True).pack(side='left')
        self.label(line,'Your friends join the game you choose.',10,self.MUTED).pack(side='right')
        choices=tk.Frame(self.body,bg=self.BG); choices.pack(fill='x',pady=(0,8))
        choices.columnconfigure(0,weight=1,uniform='games'); choices.columnconfigure(1,weight=1,uniform='games')
        self.game_tiles=[]
        for i,kind in enumerate(GAMES):
            tile=GameTile(choices,self,kind,self.choose_home_game); tile.grid(row=0,column=i,sticky='ew',padx=(0,8) if i==0 else (8,0))
            self.game_tiles.append(tile)
        self.label(self.body,'2   START A ROOM OR JOIN A FRIEND',10,self.MUTED,True).pack(anchor='w',pady=(0,9))
        columns=tk.Frame(self.body,bg=self.BG); columns.pack(fill='both',expand=True)
        for i in (0,1): columns.columnconfigure(i,weight=1,uniform='forms')
        columns.rowconfigure(0,weight=1)
        host=Surface(columns,bg=self.PANEL,padx=18,pady=12); host.grid(row=0,column=0,sticky='nsew',padx=(0,8))
        join=Surface(columns,bg=self.PANEL,padx=18,pady=12); join.grid(row=0,column=1,sticky='nsew',padx=(8,0))
        self.label(host,'I’ll host!',21,self.TEXT,True).pack(anchor='w')
        self.host_summary=self.label(host,self.settings_summary(),10,self.MUTED,wraplength=420,justify='left')
        self.host_summary.pack(anchor='w',pady=(4,10))
        row=tk.Frame(host,bg=self.PANEL); row.pack(fill='x',pady=(0,10))
        self.label(row,'How many players?',11,self.TEXT,True).pack(side='left')
        self.button(row,'−',lambda:self.change_players(-1),secondary=True).pack(side='left',padx=(14,6))
        self.home_count=self.label(row,str(self.player_count.get()),16,self.TEXT,True,width=2); self.home_count.pack(side='left')
        self.button(row,'+',lambda:self.change_players(1),secondary=True).pack(side='left',padx=6)
        host_footer=tk.Frame(host,bg=self.PANEL); host_footer.pack(side='bottom',fill='x')
        self.button(host_footer,'Create a room →',self.host_room,large=True).pack(side='left',fill='x',expand=True)
        self.button(host_footer,'Host settings',self.show_host_settings,secondary=True).pack(side='right',padx=(7,0))
        self.label(join,'My friend is hosting',21,self.TEXT,True).pack(anchor='w')
        self.label(join,'Enter their six-digit room code.',10,self.MUTED).pack(anchor='w',pady=(4,9))
        row=tk.Frame(join,bg=self.PANEL); row.pack(fill='x')
        self.code_entry=tk.Entry(row,textvariable=self.code,font=('Segoe UI',25,'bold'),width=10,justify='center',
                                 bg=self.ENTRY,fg=self.TEXT,insertbackground=self.GREEN,relief='flat',
                                 highlightthickness=2,highlightbackground=self.BORDER,highlightcolor=self.GREEN)
        self.code_entry.pack(fill='x',ipady=8)
        self.code_entry.bind('<Return>',lambda e:self.join_room())
        self.button(join,'Join room →',self.join_room,large=True).pack(side='bottom',fill='x',pady=(10,0))
        footer=tk.Frame(self.body,bg=self.BG); footer.pack(side='bottom',fill='x',pady=(8,0),before=columns)
        self.button(footer,'Connection help',self.show_connection_help,secondary=True).pack(side='left')
        self.button(footer,'Friends’ guide',self.open_friends_guide,secondary=True).pack(side='left',padx=6)
        if self.saved.get('resume') and self.saved.get('port')==DEFAULT_PORT:
            self.button(footer,'Resume last room',lambda:self.join_room(resume=True),secondary=True).pack(side='right')
        self.home_error=self.label(footer,self.error_text,10,self.ERROR,wraplength=470,justify='left')
        self.home_error.pack(side='left',padx=10)
        self.connection_error_label=self.home_error
        self.resize_home()

    def resize_home(self,event=None):
        if event is not None and event.widget is not self: return
        if self.scene!='home' or not hasattr(self,'game_tiles'): return
        height=165 if self.winfo_height()<780 else 190
        for tile in self.game_tiles:
            if tile.winfo_exists() and int(tile.cget('height'))!=height: tile.configure(height=height)

    def choose_home_game(self,kind):
        self.game_kind.set(kind); self.save_preferences()
        for tile in self.game_tiles: tile.draw()
        self.host_summary.configure(text=self.settings_summary())

    def change_players(self,amount):
        self.player_count.set(max(2,min(6,self.player_count.get()+amount)))
        self.home_count.configure(text=str(self.player_count.get()))
        self.host_summary.configure(text=self.settings_summary()); self.save_preferences()

    def number_shortcut(self,index):
        if isinstance(self.focus_get(),(tk.Entry,tk.Text)): return
        if self.scene=='maedn':
            if index<4: self.board_shortcut(index)
            return
        if self.scene!='table' or self.wild is not None: return
        game=self.state['game']
        if game['audit']: return
        order=self.hand_order(game); offset=self.page*7+index
        if offset>=len(order): return
        i=order[offset]; plays=[a for a in self.actions() if a[0]=='play' and a[1]==i]
        if not plays: return
        if game['hand'][i][0]=='Wild': self.wild=i; self.draw()
        else: self.send_action(plays[0])

    def color_shortcut(self,color):
        if self.scene!='table' or isinstance(self.focus_get(),(tk.Entry,tk.Text)): return
        opening=self.state['game']['phase']=='opening_color'
        if not opening and self.wild is None: return
        self.send_action(('color',color) if opening else ('play',self.wild,color))

    def show_host_settings(self):
        from uno_rules import STARTING_HANDS,TARGET_SCORES
        dialog=tk.Toplevel(self); dialog.title('Set up your room · Playroom'); dialog.geometry('700x780')
        dialog.resizable(False,False); dialog.configure(bg=self.BG); dialog.transient(self); dialog.grab_set()
        dialog.bind('<Escape>',lambda e:dialog.destroy())
        frame=tk.Frame(dialog,bg=self.BG,padx=26,pady=22); frame.pack(fill='both',expand=True)
        self.label(frame,'Your room, your rules.',25,self.TEXT,True).pack(anchor='w')
        in_room=self.state is not None; locked=in_room and (self.seat!=0 or self.state['game'] is not None)
        settings=self.state['settings'] if in_room else {'starting_cards':self.starting_cards.get(),'target_score':self.target_score.get()}
        board=self.state['board_settings'] if in_room else {'three_rolls':self.three_rolls.get(),'home_jumping':self.home_jumping.get()}
        current=self.state['game_kind'] if in_room else self.game_kind.get()
        game_choice=tk.StringVar(dialog,GAMES[current]); players=tk.IntVar(dialog,self.state['player_count'] if in_room else self.player_count.get())
        cards=tk.IntVar(dialog,settings['starting_cards']); target=tk.IntVar(dialog,settings['target_score'])
        theme=tk.StringVar(dialog,self.state.get('theme',self.design.get()) if in_room else self.design.get())
        three=tk.BooleanVar(dialog,board['three_rolls']); jumping=tk.BooleanVar(dialog,board['home_jumping'])
        dialog.game_choice,dialog.players,dialog.cards,dialog.target=game_choice,players,cards,target
        dialog.three_rolls,dialog.home_jumping=three,jumping
        self.label(frame,'1   CHOOSE A GAME',10,self.MUTED,True).pack(anchor='w',pady=(21,8))
        game_row=tk.Frame(frame,bg=self.BG); game_row.pack(fill='x'); game_buttons=[]
        for key,name in GAMES.items():
            button=self.button(game_row,name,lambda n=name:game_choice.set(n),secondary=True,large=True)
            button.configure(font=('Segoe UI',11,'bold'),padx=9)
            button.pack(side='left',fill='x',expand=True,padx=(0,7)); game_buttons.append((name,button))
        self.label(frame,'2   HOW MANY PLAYERS?  ·  INCLUDE YOURSELF',10,self.MUTED,True).pack(anchor='w',pady=(18,8))
        row=tk.Frame(frame,bg=self.BG); row.pack(fill='x'); count_buttons=[]
        for n in range(2,7):
            button=self.button(row,str(n),lambda value=n:players.set(value),secondary=True,large=True)
            button.pack(side='left',fill='x',expand=True,padx=(0,7)); count_buttons.append((n,button))
        self.label(frame,'3   GAME OPTIONS',10,self.MUTED,True).pack(anchor='w',pady=(18,8))
        option_slot=tk.Frame(frame,bg=self.BG,height=155); option_slot.pack(fill='x'); option_slot.pack_propagate(False)
        uno=tk.Frame(option_slot,bg=self.BG); race=tk.Frame(option_slot,bg=self.BG)
        for label,variable,values in (('Cards to start',cards,STARTING_HANDS),('Points to win',target,TARGET_SCORES)):
            row=tk.Frame(uno,bg=self.BG); row.pack(fill='x',pady=4)
            self.label(row,label,12,self.TEXT,True).pack(side='left')
            menu=tk.OptionMenu(row,variable,*values); menu.configure(bg=self.PANEL,fg=self.TEXT,highlightthickness=0,relief='flat',font=('Segoe UI',12),width=8,state='disabled' if locked else 'normal')
            menu['menu'].configure(bg=self.PANEL,fg=self.TEXT); menu.pack(side='right')
        preset=self.button(uno,'Use classic UNO · 7 cards / 500 points',lambda:(cards.set(7),target.set(500)),secondary=True)
        preset.pack(fill='x',pady=(7,0)); preset.configure(state='disabled' if locked else 'normal')
        for label,var in (('Three tries when your pawns are stuck in base',three),('Jump over pawns in your home lane',jumping)):
            tk.Checkbutton(race,text=label,variable=var,font=('Segoe UI',11),bg=self.BG,fg=self.TEXT,selectcolor=self.PANEL,
                           activebackground=self.BG,activeforeground=self.TEXT,state='disabled' if locked else 'normal').pack(anchor='w',pady=7)
        self.label(race,'Four pawns each. A six gives another roll.',10,self.MUTED).pack(anchor='w',pady=(7,0))
        self.label(frame,'4   ROOM DESIGN · EVERYONE SEES THIS',10,self.MUTED,True).pack(anchor='w',pady=(12,5))
        theme_row=tk.Frame(frame,bg=self.PANEL,padx=10,pady=8); theme_row.pack(fill='x')
        self.label(theme_row,'Choose the look for this room',11,self.TEXT,True).pack(side='left')
        theme_menu=tk.OptionMenu(theme_row,theme,*THEMES.keys())
        theme_menu.configure(bg=self.BUTTON,fg=self.TEXT,activebackground=self.ACTIVE,highlightthickness=0,
                             relief='flat',font=('Segoe UI',11,'bold'),state='disabled' if locked else 'normal')
        theme_menu['menu'].configure(bg=self.PANEL,fg=self.TEXT); theme_menu.pack(side='right')
        def refresh(*_):
            for name,button in game_buttons: button.configure(bg=self.GREEN if game_choice.get()==name else self.BUTTON,fg=self.BUTTON_TEXT if game_choice.get()==name else self.TEXT,state='disabled' if locked else 'normal')
            for n,button in count_buttons: button.configure(bg=self.GREEN if players.get()==n else self.BUTTON,fg=self.BUTTON_TEXT if players.get()==n else self.TEXT,state='disabled' if locked else 'normal')
            uno.pack_forget(); race.pack_forget()
            (uno if game_choice.get()==GAMES['uno'] else race).pack(fill='both',expand=True)
        players.trace_add('write',refresh); game_choice.trace_add('write',refresh); refresh()
        hint='This game has started. Create a new room to change its rules.' if locked else 'Changes in the waiting room reset Ready for everyone.' if in_room else 'Friends join the game, design and rules you choose here.'
        self.label(frame,hint,10,self.MUTED,wraplength=580,justify='left').pack(anchor='w',pady=(10,0))
        def apply():
            kind=next(key for key,value in GAMES.items() if value==game_choice.get())
            if in_room:
                if not self.send_command({'type':'settings','player_count':players.get(),'starting_cards':cards.get(),'target_score':target.get(),
                                          'game_kind':kind,'three_rolls':three.get(),'home_jumping':jumping.get(),
                                          'theme':theme.get()}): return
            else:
                self.player_count.set(players.get()); self.starting_cards.set(cards.get()); self.target_score.set(target.get())
                self.game_kind.set(kind); self.three_rolls.set(three.get()); self.home_jumping.set(jumping.get())
                self.design.set(theme.get()); self.refresh_palette(); self.save_preferences()
            dialog.destroy()
            self.update_view() if in_room else self.show_home()
        footer=tk.Frame(frame,bg=self.BG); footer.pack(side='bottom',fill='x',pady=(15,0))
        if not locked: self.button(footer,'Apply settings',apply,large=True).pack(side='right')
        self.button(footer,'Close' if locked else 'Cancel',dialog.destroy,secondary=True).pack(side='left')

    def begin_connection(self):
        super().begin_connection()
        for child in self.body.winfo_children(): child.destroy()
        art=tk.Canvas(self.body,height=150,bg=self.BG,highlightthickness=0); art.pack(fill='x',pady=(80,5))
        def draw_art(e=None):
            art.delete('all'); cx=art.winfo_width()/2
            for i,col in enumerate(('#514bcb','#e5bd24','#d9363e')): pawn(art,cx-70+i*70,70,28,col)
        art.bind('<Configure>',draw_art)
        self.label(self.body,'Making room for you…',28,self.TEXT,True).pack(pady=(0,10))
        self.connect_note=self.label(self.body,'Connecting to your friend’s room.',12,self.MUTED,wraplength=650)
        self.connect_note.pack()
        self.button(self.body,'Back to games',lambda:self.leave(False),secondary=True,large=True).pack(pady=24)

    def build_room(self):
        self.build_chat(self.body)
        main=tk.Frame(self.body,bg=self.BG); main.pack(side='left',fill='both',expand=True)
        self.label(main,'Everyone’s invited.',29,self.TEXT,True).pack(anchor='w',pady=(8,3))
        self.room_heading=self.label(main,'',10,self.MUTED,wraplength=670,justify='left'); self.room_heading.pack(anchor='w',pady=(0,10))
        invite=Surface(main,bg=self.PANEL,padx=22,pady=10); invite.pack(fill='x')
        self.party_canvas=invite.paper
        left=tk.Frame(invite,bg=self.PANEL); left.pack(side='left')
        self.label(left,'YOUR ROOM CODE',9,self.MUTED,True).pack(anchor='w')
        self.label(left,self.state['room'],35,self.GREEN,True).pack(anchor='w')
        self.label(left,'Send these six digits to your friends.',10,self.MUTED).pack(anchor='w')
        self.button(invite,'Copy code',self.copy_room_code,large=True).pack(side='right')
        rules=tk.Frame(main,bg=self.BG); rules.pack(fill='x',pady=(15,10))
        self.room_settings_label=self.label(rules,'',11,self.GOLD,True,justify='left',wraplength=440)
        self.room_settings_label.pack(side='left')
        if self.server: self.button(rules,'Host settings',self.show_host_settings,secondary=True).pack(side='right')
        seats=tk.Frame(main,bg=self.BG); seats.pack(fill='x',pady=(0,10))
        columns=min(3,self.state['player_count']); self.seat_labels=[]; self.seat_avatars=[]
        for i in range(columns): seats.columnconfigure(i,weight=1,uniform='seats')
        for i in range(self.state['player_count']):
            panel=Surface(seats,bg=self.PANEL,padx=12,pady=14)
            panel.grid(row=i//columns,column=i%columns,sticky='nsew',padx=4,pady=4)
            avatar=tk.Canvas(panel,width=30,height=30,bg=self.PANEL,highlightthickness=0); avatar.pack(side='left',padx=(0,8))
            self.seat_avatars.append(avatar)
            details=tk.Frame(panel,bg=self.PANEL); details.pack(side='left',fill='x',expand=True)
            name=self.label(details,'',12,self.TEXT,True); name.pack(anchor='w',pady=(0,3))
            status=self.label(details,'',10,self.MUTED); status.pack(anchor='w')
            self.seat_labels.append((name,status))
        controls=tk.Frame(main,bg=self.BG); controls.pack(fill='x',pady=(4,0))
        self.ready_button=self.button(controls,'Ready to play',self.toggle_ready,large=True)
        self.ready_button.pack(side='left',fill='x',expand=True)
        self.button(controls,'Leave room',self.leave,secondary=True).pack(side='right',padx=(10,0))
        self.room_status=self.label(main,'',10,self.MUTED,wraplength=650,justify='left'); self.room_status.pack(anchor='w',pady=10)
        main.bind('<Configure>',lambda e:(self.room_heading.configure(wraplength=max(250,e.width-8)),self.room_settings_label.configure(wraplength=max(230,e.width-155))))

    def copy_room_code(self):
        self.clipboard_clear(); self.clipboard_append(self.state['room'])
        self.room_status.configure(text='Copied! Send the code to your friends.')

    def update_room(self):
        super().update_room()
        for i,canvas in enumerate(self.seat_avatars):
            canvas.delete('all'); online=self.state['connected'][i]; ready=self.state['ready'][i]
            canvas.create_oval(1,1,29,29,fill=self.GREEN if online else self.BUTTON,outline='')
            canvas.create_text(15,15,text='✓' if ready else str(i+1),font=('Segoe UI',11,'bold'),fill=self.BUTTON_TEXT if online else self.MUTED)
        if self.state['ready'][self.seat]:
            self.ready_button.configure(text='You’re ready!  ·  Cancel')
        elif self.linked() and not self.pending:
            self.ready_button.configure(text='Ready to play  ✓')

    def build_chat(self,parent):
        rail=Surface(parent,width=254,bg=self.PANEL,padx=16,pady=15)
        self.chat_rail=rail
        if self.chat_visible: rail.pack(side='right',fill='y',padx=(14,0))
        rail.pack_propagate(False)
        self.label(rail,'Table talk',16,self.TEXT,True).pack(anchor='w')
        self.guide_title=self.label(rail,'Play together.',11,self.GREEN,True,wraplength=220,justify='left')
        self.guide_title.pack(anchor='w',pady=(12,4))
        self.guide_note=self.label(rail,'Say hello while everyone joins.',10,self.MUTED,wraplength=220,justify='left')
        self.guide_note.pack(anchor='w',pady=(0,14))
        tabs=tk.Frame(rail,bg=self.PANEL); tabs.pack(fill='x',pady=(0,10))
        self.chat_tab_button=self.button(tabs,'Chat',lambda:self.select_chat_tab('chat'))
        self.chat_tab_button.pack(side='left',fill='x',expand=True)
        self.activity_tab_button=self.button(tabs,'Activity',lambda:self.select_chat_tab('activity'),secondary=True)
        self.activity_tab_button.pack(side='left',fill='x',expand=True,padx=(5,0))
        footer=tk.Frame(rail,bg=self.PANEL); footer.pack(side='bottom',fill='x')
        if self.state.get('game'):
            self.button(footer,'Leave room',self.leave,secondary=True).pack(side='bottom',fill='x',pady=(12,0))
        self.chat_status=self.label(footer,'',9,self.MUTED,wraplength=220,justify='left',anchor='w'); self.chat_status.pack(fill='x',pady=(10,6))
        self.chat_entry=tk.Entry(footer,textvariable=self.chat_draft,font=('Segoe UI',11),bg=self.ENTRY,fg=self.TEXT,
                                 insertbackground=self.TEXT,relief='flat',highlightthickness=2,highlightbackground=self.BORDER,highlightcolor=self.GREEN)
        self.chat_entry.pack(fill='x',ipady=10); self.chat_entry.bind('<Return>',self.send_chat); self.chat_entry.bind('<KP_Enter>',self.send_chat)
        row=tk.Frame(footer,bg=self.PANEL); row.pack(fill='x',pady=(7,0))
        self.chat_count=self.label(row,'',9,self.MUTED); self.chat_count.pack(side='left')
        self.chat_send=self.button(row,'Send →',self.send_chat); self.chat_send.pack(side='right')
        log=tk.Frame(rail,bg=self.PANEL); log.pack(fill='both',expand=True)
        scroll=tk.Scrollbar(log,orient='vertical'); scroll.pack(side='right',fill='y')
        self.chat_log=tk.Text(log,width=1,height=1,wrap='word',bg=self.PANEL,fg=self.TEXT,font=('Segoe UI',10),
                              relief='flat',padx=3,pady=5,spacing3=9,selectbackground=self.GREEN,selectforeground=self.BUTTON_TEXT,
                              insertwidth=0,state='disabled',yscrollcommand=scroll.set)
        self.chat_log.pack(side='left',fill='both',expand=True); scroll.configure(command=self.chat_log.yview)
        self.chat_log.tag_configure('author',foreground=self.GOLD,font=('Segoe UI',9,'bold'),spacing3=3)
        self.chat_log.tag_configure('muted',foreground=self.MUTED)
        self.chat_render_key=None; self.update_chat_count()

    def build_table(self): self.build_game_shell(False)
    def build_maedn(self): self.build_game_shell(True)

    def build_game_shell(self,board):
        self.build_chat(self.body)
        left=tk.Frame(self.body,bg=self.BG); left.pack(side='left',fill='both',expand=True)
        self.score_labels=[]; self.board_score_labels=[]
        self.roster=tk.Canvas(left,height=64,bg=self.BG,highlightthickness=0)
        self.roster.pack(fill='x',pady=(0,10)); self.roster.bind('<Configure>',lambda e:self.draw_roster())
        self.turn_panel=Surface(left,bg=self.PANEL,padx=17,pady=10); self.turn_panel.pack(fill='x',pady=(0,5))
        self.turn_badge=tk.Canvas(self.turn_panel,width=66,height=64,bg=self.PANEL,highlightthickness=0)
        self.turn_badge.pack(side='right',padx=(8,0))
        self.turn_label=self.label(self.turn_panel,'',22,self.TEXT,True,anchor='w'); self.turn_label.pack(fill='x')
        self.phase_label=self.label(self.turn_panel,'',11,self.MUTED,anchor='w',justify='left'); self.phase_label.pack(fill='x',pady=(2,0))
        self.banner=self.label(left,'',9,self.MUTED,anchor='w',height=1); self.banner.pack(fill='x',pady=(0,7))
        left.bind('<Configure>',lambda e:self.phase_label.configure(wraplength=max(220,e.width-128)))
        if not board:
            pages=tk.Frame(left,bg=self.BG); pages.pack(side='bottom',fill='x',pady=(4,0))
            self.prev_button=self.button(pages,'‹',lambda:self.change_page(-1),secondary=True); self.prev_button.configure(pady=5)
            self.prev_button.pack(side='left')
            self.page_label=self.label(pages,'',9,self.MUTED); self.page_label.pack(side='left',padx=8)
            self.next_button=self.button(pages,'›',lambda:self.change_page(1),secondary=True); self.next_button.configure(pady=5); self.next_button.pack(side='left')
            self.sort_button=self.button(pages,'Sort cards',self.toggle_hand_order,secondary=True); self.sort_button.configure(pady=5); self.sort_button.pack(side='right')
        self.controls=tk.Frame(left,bg=self.BG); self.controls.pack(side='bottom',fill='x',pady=(9,0))
        for i in range(4 if board else 3): self.controls.columnconfigure(i,weight=1,uniform='actions')
        self.canvas=tk.Canvas(left,bg=self.BG,highlightthickness=0,takefocus=1)
        self.canvas.design=self.active_design(); self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',lambda e:self.draw()); self.canvas.bind('<Button-1>',self.click)
        self.canvas.bind('<Motion>',self.on_hover); self.canvas.bind('<Leave>',lambda e:self.set_hover(None))

    def update_table(self):
        super().update_table()
        if not self.state['game']['done']:
            buttons=[w for w in self.controls.winfo_children() if getattr(w,'is_button',False)]
            columns=min(3,len(buttons))
            for i in range(3): self.controls.columnconfigure(i,weight=1 if i<columns else 0,uniform='actions' if i<columns else '')
            for i,button in enumerate(buttons): button.grid_configure(row=i//columns,column=i%columns)
        else:
            for i in range(3): self.controls.columnconfigure(i,weight=1,uniform='actions')
        self.update_guidance(); self.draw_roster()

    def update_maedn(self):
        super().update_maedn(); self.update_guidance(); self.draw_roster()

    def update_guidance(self):
        game=self.state['game']; mine=game['turn']==self.seat; board=game.get('kind')=='maedn'
        if game['done']: title,note='One more game?','Choose Ready below. Everyone gets a fresh start.'
        elif not all(self.state['connected']): title,note='We’ll wait together.','The game pauses until your friend reconnects.'
        elif not mine: title,note='Cheer your friends on.',f'It’s {self.short_name(game["turn"],16)}’s turn. You can chat while you wait.'
        elif board:
            title,note=('1  Roll the die','Click the big Roll die button below.') if game['phase']=='roll' else ('2  Choose a glowing pawn','Click a glowing pawn or its number below. Point at it to see where it will go.')
        else:
            title,note='Match a color or symbol','Play a glowing card. No match? Choose Draw card below.'
            if game['phase']=='drawn': title,note='Keep it or play it','Only your new card can be played now. Keep & pass ends your turn.'
            elif game['phase']=='challenge': title,note='Take four or challenge','Challenge only if you think they had a matching color. A wrong challenge costs six cards.'
            elif game.get('missed_uno')==self.seat: title,note='Quick! Say UNO!','Click UNO before someone catches you.'
            elif len(game.get('hand',[]))==2: title,note='Remember to say UNO!','Click UNO before you play down to one card.'
        if not self.guidance.get(): title,note='Enjoy the game.','Open How to play whenever you need a hand.'
        self.guide_title.configure(text=title); self.guide_note.configure(text=note)
        if mine and not game['done'] and self.linked() and all(self.state['connected']):
            task=('Roll the die' if game['phase']=='roll' else 'Pick a pawn') if board else ('Pick a card' if game['phase']=='ready' else 'Make your choice')
            self.turn_label.configure(text='YOUR TURN · '+task,font=('Segoe UI',19,'bold'))
        self.draw_turn_badge()
        if self.visual_busy() and mine: self.phase_label.configure(text='Watch the move… your buttons will light up when it’s finished.')

    def draw_turn_badge(self,value=None):
        if not hasattr(self,'turn_badge') or not self.turn_badge.winfo_exists(): return
        c=self.turn_badge; c.configure(bg=self.turn_panel.cget('bg')); c.delete('all')
        game=self.state['game']
        if game['done']:
            c.create_text(33,32,text='★',font=('Segoe UI',32,'bold'),fill=self.GOLD)
        elif game.get('kind')=='maedn': die(c,32,30,47,value if value is not None else game['die'])
        else:
            c.design=self.active_design()
            paint_uno_card(c,16,4,34,51,tuple(game['top']))

    def draw_roster(self):
        if not hasattr(self,'roster') or not self.roster.winfo_exists() or not self.state or not self.state.get('game'): return
        c=self.roster; c.delete('all'); n=self.state['player_count']; w=max(100,c.winfo_width()); cell=w/n
        game=self.state['game']; board=game.get('kind')=='maedn'
        from maedn_view import PAWN_COLORS
        for i in range(n):
            x=i*cell; active=i==game['turn'] and not game['done']; connected=self.state['connected'][i]
            rounded(c,x+2,2,x+cell-4,62,14,fill=self.ACTIVE if active else self.PANEL,outline=self.GREEN if active else '',width=2)
            color=PAWN_COLORS[game['slots'][i]] if board else self.GREEN if i==self.seat else self.MUTED
            c.create_oval(x+10,12,x+28,30,fill=color if connected else self.BORDER,outline='')
            c.create_text(x+19,21,text=str(i+1),font=('Segoe UI',8,'bold'),fill='#20263e' if color=='#e5bd24' else 'white')
            limit=max(4,int((cell-44)/7))
            c.create_text(x+34,22,text='You' if i==self.seat else self.short_name(i,limit),anchor='w',font=('Segoe UI',10,'bold'),fill=self.TEXT)
            if not connected: status='Reconnecting'
            elif board:
                status=f'#{game["rankings"].index(i)+1} finished' if i in game['rankings'] else f'{game["home_counts"][i]} / 4 home'
            else: status=f'{game["counts"][i]} cards · {game["points"][i]} pts'
            c.create_text(x+12,45,text=status,anchor='w',font=('Segoe UI',8),fill=self.TEXT if active else self.MUTED)

    def visual_state_changed(self,old,new):
        game=new.get('game'); previous=old.get('game') if old else None
        if not game: self.fx=None; return
        if game and previous and old.get('last_move') and not new.get('last_move'):
            self.fx=None
        move=new.get('last_move')
        fresh=move and (not old or not old.get('last_move') or move['revision']!=old['last_move']['revision'])
        kind=None; duration=.55
        if game['done'] and (not previous or not previous['done']): kind='win'; duration=2.3
        elif not previous or previous['done'] and not game['done']: kind='deal'; duration=.65
        elif fresh and move['kind'] in ('play','draw','roll','move'):
            kind=move['kind']; duration=.65 if kind=='roll' else .78 if kind=='move' else .43
        if self.motion_pace.get()=='Gentle': duration*=.72
        if kind:
            self.play_sound('win' if kind=='win' else 'capture' if game.get('last_capture') else 'roll' if kind=='roll' else 'move')
            if self.motion.get():
                self.fx={'kind':kind,'start':time.monotonic(),'duration':duration,'old':copy.deepcopy(previous),
                         'game':copy.deepcopy(game),'move':copy.deepcopy(move)}
                self.ensure_fx()
            else: self.fx=None

    def visual_busy(self):
        return bool(self.motion.get() and self.fx and self.fx['kind']!='win' and time.monotonic()-self.fx['start']<self.fx['duration'])

    def actions(self):
        actions=super().actions()
        # Calls and catches remain usable during card flights: animation must
        # never shorten UNO's time-sensitive call/catch window.
        if self.visual_busy(): return [a for a in actions if a[0] in ('uno','uno_late','catch')]
        return actions

    def ensure_frame(self):
        # Core's legacy card flight is replaced by one animation clock.
        return

    def ensure_fx(self):
        if self.fx_job is None and not self.closing: self.fx_job=self.after(16,self.fx_frame)

    def fx_frame(self):
        self.fx_job=None
        if self.closing: return
        if self.fx and self.motion.get() and time.monotonic()-self.fx['start']<self.fx['duration']:
            self.draw(); self.ensure_fx()
        else:
            self.fx=None
            if self.state: self.update_view()

    def play_sound(self,name):
        if not self.sound.get(): return
        try:
            import winsound
            path=Path(__file__).with_name('sounds')/(name+'.wav')
            if path.exists(): winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NODEFAULT)
        except (ImportError,RuntimeError): pass

    def set_hover(self,hover):
        if hover==self.hover: return
        self.hover=hover
        if self.motion.get() and self.scene=='table':
            if self.hover_job is None: self.hover_frame()
        else: self.draw()

    def hover_frame(self):
        self.hover_job=None
        if self.closing or self.scene!='table': return
        keys=set(self.hover_amount)
        if self.hover: keys.add(self.hover)
        unsettled=False
        for key in keys:
            target=1. if key==self.hover else 0.
            value=self.hover_amount.get(key,0)+(target-self.hover_amount.get(key,0))*.32
            if abs(value-target)<.02: value=target
            else: unsettled=True
            if value==0: self.hover_amount.pop(key,None)
            else: self.hover_amount[key]=value
        self.draw()
        if unsettled: self.hover_job=self.after(16,self.hover_frame)

    def show_appearance(self):
        window=tk.Toplevel(self); window.title('Make it yours · Playroom'); window.geometry('800x800'); window.configure(bg=self.BG)
        window.transient(self); window.grab_set()
        window.bind('<Escape>',lambda e:window.destroy())
        frame=tk.Frame(window,bg=self.BG,padx=25,pady=20); frame.pack(fill='both',expand=True)
        self.label(frame,'Make it yours.',26,self.TEXT,True).pack(anchor='w')
        self.label(frame,'Your look and comfort settings stay on this PC. The host selects the room design.',10,self.MUTED).pack(anchor='w',pady=(6,18))
        grid=tk.Frame(frame,bg=self.BG); grid.pack(fill='x')
        for i,(name,paint) in enumerate(THEMES.items()):
            def choose(n=name): window.destroy(); self.apply_design(n)
            button=SoftButton(grid,('✓  ' if name==self.active_design() else '')+name,choose,paint,large=True)
            button.grid(row=i//3,column=i%3,sticky='ew',padx=4,pady=4)
            if self.state: button.configure(state='disabled')
        for i in range(3): grid.columnconfigure(i,weight=1,uniform='themes')
        for label,variable,detail in (('Animations',self.motion,'Smooth cards, rolling dice and hopping pawns.'),
                                      ('Gentle sounds',self.sound,'Small sounds for moves, captures and wins.'),
                                      ('Helpful hints',self.guidance,'Simple tips for what to do next.')):
            row=tk.Frame(frame,bg=self.BG); row.pack(fill='x',pady=(11,0))
            tk.Checkbutton(row,text=label,variable=variable,command=self.comfort_changed,font=('Segoe UI',12,'bold'),
                           bg=self.BG,fg=self.TEXT,selectcolor=self.PANEL,activebackground=self.BG,activeforeground=self.TEXT).pack(anchor='w')
            self.label(row,detail,9,self.MUTED).pack(anchor='w',padx=28)
        size_row=tk.Frame(frame,bg=self.BG); size_row.pack(fill='x',pady=(11,0))
        self.label(size_row,'Text size',12,self.TEXT,True).pack(side='left')
        size_menu=tk.OptionMenu(size_row,self.text_size,'Small','Standard','Large','Extra large',command=lambda *_:self.accessibility_changed())
        size_menu.configure(bg=self.BUTTON,fg=self.TEXT,highlightthickness=0,relief='flat',font=('Segoe UI',11,'bold'))
        size_menu['menu'].configure(bg=self.PANEL,fg=self.TEXT); size_menu.pack(side='right')
        row=tk.Frame(frame,bg=self.BG); row.pack(fill='x',pady=(8,0))
        tk.Checkbutton(row,text='High contrast',variable=self.high_contrast,command=self.accessibility_changed,
                       font=('Segoe UI',12,'bold'),bg=self.BG,fg=self.TEXT,selectcolor=self.PANEL,
                       activebackground=self.BG,activeforeground=self.TEXT).pack(anchor='w')
        self.label(row,'Stronger text, borders and focus colors.',9,self.MUTED).pack(anchor='w',padx=28)
        pace_row=tk.Frame(frame,bg=self.BG); pace_row.pack(fill='x',pady=(8,0))
        self.label(pace_row,'Animation pace',12,self.TEXT,True).pack(side='left')
        pace=tk.OptionMenu(pace_row,self.motion_pace,'Gentle','Playful',command=lambda *_:self.accessibility_changed())
        pace.configure(bg=self.BUTTON,fg=self.TEXT,highlightthickness=0,relief='flat',font=('Segoe UI',11,'bold'))
        pace['menu'].configure(bg=self.PANEL,fg=self.TEXT); pace.pack(side='right')
        footer=tk.Frame(frame,bg=self.BG); footer.pack(side='bottom',fill='x',pady=(12,0))
        self.button(footer,'Full screen  ·  F11',self.toggle_fullscreen,secondary=True).pack(side='left')
        self.button(footer,'Updates',self.show_update_info,secondary=True).pack(side='left',padx=8)
        self.button(footer,'Done',window.destroy).pack(side='right')

    def show_update_info(self):
        import json
        from tkinter import messagebox
        import update_core
        root=Path(__file__).resolve().parent
        version=update_core.installed(root)['version']
        try:
            status=json.loads((root/'update_status.json').read_text(encoding='utf-8'))
            detail=status.get('checked','')+'\n'+status.get('message','')
        except (OSError,ValueError,TypeError): detail='No update check recorded yet.'
        messagebox.showinfo('Automatic updates · Playroom',
            'Installed version: '+version+'\n\n'+detail+
            '\n\nUpdates are checked when you open Start UNO Together.cmd.'
            '\nUpdates download automatically from the public game page. No account or setup is required.'
            '\nUpdates never interrupt a running game.',parent=self)

    def comfort_changed(self):
        self.save_preferences()
        if not self.motion.get(): self.fx=None; self.hover_amount={}
        self.scene=''
        if self.state: self.update_view()
        else: self.show_home()
        if not self.sound.get():
            try:
                import winsound
                winsound.PlaySound(None,0)
            except (ImportError,RuntimeError): pass

    def accessibility_changed(self):
        self.apply_text_size(); self.refresh_palette(); self.save_preferences()
        self.configure(bg=self.BG); self.body.configure(bg=self.BG)
        if hasattr(self,'header'): self.build_header()
        self.scene=''
        if self.state: self.update_view()
        else: self.show_home()

    def show_rules(self):
        kind=self.state.get('game_kind','uno') if self.state else self.game_kind.get()
        slides=( [('Match a card','Play the same color, number or symbol. Glowing cards are the ones you can play.'),
                  ('No match? Draw one.','Click Draw card. Play your new card if it fits, or choose Keep & pass.'),
                  ('Two cards? Say UNO!','Click UNO before playing down to one card. Empty your hand to win.')]
                 if kind=='uno' else
                 [('Roll the die','When it’s your turn, click Roll die. A six gives you another roll.'),
                  ('Choose a glowing pawn','Click a glowing pawn or its number. Landing on a friend sends their pawn back to base.'),
                  ('Bring all four home','Go around the board and into your own home lane. You need the exact roll to finish.')])
        window=tk.Toplevel(self); window.title('Let’s play · '+GAMES[kind]); window.geometry('620x550'); window.configure(bg=self.BG)
        window.transient(self); window.grab_set(); index=[0]
        window.bind('<Escape>',lambda e:window.destroy())
        art=tk.Canvas(window,height=220,bg=self.BG,highlightthickness=0); art.pack(fill='x',pady=(20,0))
        heading=self.label(window,'',25,self.TEXT,True); heading.pack(pady=(8,8))
        note=self.label(window,'',13,self.MUTED,wraplength=500,justify='center'); note.pack(padx=30)
        progress=self.label(window,'',10,self.GOLD,True); progress.pack(pady=18)
        footer=tk.Frame(window,bg=self.BG,padx=24); footer.pack(side='bottom',fill='x',pady=20)
        def full(): window.destroy(); super(PlayroomUI,self).show_rules()
        self.button(footer,'All rules',full,secondary=True).pack(side='left')
        def next_slide():
            if index[0]==2: window.destroy(); return
            index[0]+=1; render()
        next_button=self.button(footer,'Next →',next_slide,large=True); next_button.pack(side='right')
        def render(e=None):
            i=index[0]; heading.configure(text=slides[i][0]); note.configure(text=slides[i][1])
            progress.configure(text='  '.join('●' if n==i else '○' for n in range(3)))
            next_button.configure(text='Let’s play! ✓' if i==2 else 'Next →')
            art.delete('all'); cx=art.winfo_width()/2
            if kind=='uno':
                art.design=self.active_design()
                for n,card in enumerate((('Red','7'),('Blue','7')) if i==0 else (None,('Yellow','5')) if i==1 else (('Green','Reverse'),)):
                    paint_uno_card(art,cx-95+n*100 if i<2 else cx-45,28,86,130,card)
                if i==2: art.create_text(cx,188,text='UNO!',font=('Segoe UI',26,'bold'),fill=self.GREEN)
            else:
                if i==0: die(art,cx,103,114,6)
                else:
                    for n,col in enumerate(('#d9363e','#25955b','#e5bd24','#287ec3')): pawn(art,cx-100+n*66,110,26,col,n+1,ring=i==1 and n==0)
                    art.create_text(cx,178,text='Choose one' if i==1 else '4 pawns home = a win!',font=('Segoe UI',13,'bold'),fill=self.GREEN)
        art.bind('<Configure>',render); render()

    def cancel_wild(self):
        if self.wild is not None: self.wild=None; self.draw()
        elif self.fullscreen: self.toggle_fullscreen()

    def leave(self,confirm=True,preserve_error=False):
        if confirm and self.state and self.state.get('game') and not self.state['game']['done']:
            self.confirm_exit(False); return
        self.fx=None
        super().leave(False,preserve_error)

    def request_close(self):
        if self.state and self.state.get('game') and not self.state['game']['done']:
            self.confirm_exit(True)
        else: self.close()

    def confirm_exit(self,close_app):
        dialog=tk.Toplevel(self); dialog.title('Leave the table?'); dialog.geometry('510x280'); dialog.configure(bg=self.BG)
        dialog.transient(self); dialog.grab_set(); dialog.bind('<Escape>',lambda e:dialog.destroy())
        frame=tk.Frame(dialog,bg=self.BG,padx=28,pady=24); frame.pack(fill='both',expand=True)
        self.label(frame,'Leave the table?',25,self.TEXT,True).pack(anchor='w')
        note='You’re the host. Leaving closes this room for everyone.' if self.server else 'Your seat is saved. You can return while the host keeps the room open.'
        self.label(frame,note,12,self.MUTED,wraplength=440,justify='left').pack(anchor='w',pady=(14,20))
        row=tk.Frame(frame,bg=self.BG); row.pack(side='bottom',fill='x')
        def go():
            dialog.destroy()
            self.close() if close_app else self.leave(False)
        self.button(row,'Leave room',go,secondary=True).pack(side='left')
        stay=self.button(row,'Keep playing',dialog.destroy,large=True); stay.pack(side='right'); stay.focus_set()

    def close(self):
        for job in (self.fx_job,self.hover_job):
            if job is not None: self.after_cancel(job)
        self.fx_job=self.hover_job=None
        super().close()
