"""Vector card art. No external images or packages required."""
import math
from uno_themes import card_back

def rounded(canvas, x1, y1, x2, y2, radius=16, **options):
    radius = max(0, min(radius, (x2 - x1) / 2, (y2 - y1) / 2))
    points = [x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
              x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
              x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1]
    return canvas.create_polygon(points, smooth=True, splinesteps=24, **options)


def paint_uno_card(canvas, x, y, w, h, card=None, playable=False):
    """Resolution-independent deck artwork, shared by the game and SVG export."""
    ink = {'Red':'#ed2734', 'Yellow':'#f6c629', 'Green':'#17a767', 'Blue':'#168de2', 'Wild':'#161b26'}
    rounded(canvas, x+2, y+5, x+w+2, y+h+5, w*.12, fill='#b7b6cb', outline='')
    rounded(canvas, x, y, x+w, y+h, w*.12, fill='#fffdf5', outline='#ffe276' if playable else '#d9dfd6', width=3 if playable else 1)
    inset=w*.065
    color, value = card if card else ('Wild','UNO')
    fill=ink[color]
    symbol_fill='#9c7400' if color=='Yellow' else fill
    rounded(canvas,x+inset,y+inset,x+w-inset,y+h-inset,w*.08,fill=fill,outline='')
    theme = getattr(canvas, 'design', 'Classic')
    if not card and theme not in ('Classic', 'Playroom'):
        back_color = {'Spider-Man':'#10234a', 'Hello Kitty':'#ffd5e7', 'Formula 1':'#262d34'}[theme]
        rounded(canvas,x+inset,y+inset,x+w-inset,y+h-inset,w*.08,fill=back_color,outline='')
        card_back(canvas, x, y, w, h, theme)
        return
    cx,cy=x+w/2,y+h/2
    tilt=-.36
    def ellipse_point(angle, rx=w*.34, ry=h*.34):
        a,b=rx*math.cos(angle),ry*math.sin(angle)
        return (cx+a*math.cos(tilt)-b*math.sin(tilt), cy+a*math.sin(tilt)+b*math.cos(tilt))
    oval=[v for i in range(60) for v in ellipse_point(i*2*math.pi/60)]
    canvas.create_polygon(oval,fill='#f9fbf5',outline='')
    def text(px,py,label,size,paint,angle=0):
        canvas.create_text(px,py,text=label,font=('Arial',max(5,int(size)),'bold'),fill=paint,angle=angle)
    if not card:
        canvas.create_polygon([v for i in range(60) for v in ellipse_point(i*2*math.pi/60,w*.29,h*.29)],fill='#eb2838',outline='')
        text(cx+1,cy+2,'UNO',w*.29,'#161b26',18)
        text(cx,cy,'UNO',w*.29,'#ffe459',18)
        return
    corner={'Skip':'⊘','Reverse':'⇄','Wild':'W'}.get(value,value)
    text(x+w*.20,y+h*.15,corner,w*.19,'#382b12' if color=='Yellow' else 'white')
    text(x+w*.80,y+h*.85,corner,w*.19,'#382b12' if color=='Yellow' else 'white',180)
    if color=='Wild':
        for sector,c in enumerate(('Red','Yellow','Green','Blue')):
            pts=[cx,cy]+[v for i in range(16) for v in ellipse_point((sector*15+i)*2*math.pi/60,w*.29,h*.29)]
            canvas.create_polygon(pts,fill=ink[c],outline='')
        if value=='+4':
            for i,c in enumerate(('Blue','Green','Yellow','Red')):
                xx=cx-w*.23+i*w*.10
                yy=cy-h*.13+(i%2)*h*.07
                rounded(canvas,xx,yy,xx+w*.24,yy+h*.26,w*.025,fill=ink[c],outline='white',width=max(1,w*.025))
    elif value=='Skip':
        radius=w*.23
        canvas.create_oval(cx-radius,cy-radius,cx+radius,cy+radius,outline=symbol_fill,width=max(2,w*.065))
        canvas.create_line(cx-radius*.75,cy+radius*.75,cx+radius*.75,cy-radius*.75,fill=symbol_fill,width=max(2,w*.065))
    elif value=='Reverse':
        for sign in (-1,1):
            yy=cy+sign*h*.055
            canvas.create_line(cx-sign*w*.24,yy,cx+sign*w*.22,yy,fill=symbol_fill,width=max(3,w*.08),
                               arrow='last',arrowshape=(w*.16,w*.18,w*.12))
    elif value=='+2':
        for i in range(2):
            xx=cx-w*.23+i*w*.15; yy=cy-h*.19+i*h*.12
            rounded(canvas,xx,yy,xx+w*.31,yy+h*.32,w*.025,fill=fill,outline='white',width=max(1,w*.025))
    else:
        text(cx+1,cy+1,value,w*.67,'#162722')
        text(cx,cy-1,value,w*.65,symbol_fill)
        if value in ('6','9'):
            canvas.create_line(cx-w*.12,cy+h*.20,cx+w*.12,cy+h*.20,fill=fill,width=max(1,w*.025))


