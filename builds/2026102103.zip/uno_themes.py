"""Local visual themes. Card colors keep their normal UNO meaning."""
THEMES = {
    'Playroom': dict(BG='#f3f1eb', PANEL='#ffffff', TEXT='#20263e', MUTED='#697188', GOLD='#514bcb',
                     GREEN='#514bcb', BUTTON='#e9e7f5', BUTTON_TEXT='#ffffff', BOARD='#eeedf8',
                     BORDER='#d9d9e8', TILE='#ffffff', ACTIVE='#ddd9fb', ENTRY='#f3f2fa', ERROR='#b82f48'),
    'Classic': dict(BG='#0c211d', PANEL='#15372e', TEXT='#f5f3df', MUTED='#aac0af', GOLD='#ffe177',
                    GREEN='#287b59', BUTTON='#284a3c', BUTTON_TEXT='#ffffff', BOARD='#174539',
                    BORDER='#356352', TILE='#12392f', ACTIVE='#225540', ENTRY='#f5f5e9', ERROR='#ffb9a4'),
    'Spider-Man': dict(BG='#0a142b', PANEL='#15264a', TEXT='#f1f5ff', MUTED='#acbddc', GOLD='#ff7b89',
                      GREEN='#b52c48', BUTTON='#294578', BUTTON_TEXT='#ffffff', BOARD='#102344',
                      BORDER='#35527c', TILE='#0b1933', ACTIVE='#682c46', ENTRY='#eef3ff', ERROR='#ffb9a4'),
    'Hello Kitty': dict(BG='#fff1f7', PANEL='#ffe1ee', TEXT='#59283f', MUTED='#86546d', GOLD='#a31e59',
                       GREEN='#b7316a', BUTTON='#ead0e1', BUTTON_TEXT='#ffffff', BOARD='#fbd4e5',
                       BORDER='#dba1be', TILE='#fff3f8', ACTIVE='#f1b4d0', ENTRY='#fffafd', ERROR='#a3263e'),
    'Formula 1': dict(BG='#101316', PANEL='#20262c', TEXT='#f6f6f2', MUTED='#b4c0c6', GOLD='#ff8177',
                     GREEN='#c0362e', BUTTON='#37424c', BUTTON_TEXT='#ffffff', BOARD='#282e34',
                     BORDER='#4f5b65', TILE='#171c21', ACTIVE='#6b302e', ENTRY='#f3f5f5', ERROR='#ffb9a4'),
}


def decorate_table(canvas, width, height, theme, paint):
    """Subtle vector table decorations; nothing here changes game state."""
    ink = paint['BORDER']
    if theme == 'Spider-Man':
        for corner in (0, width):
            sign = 1 if corner == 0 else -1
            for fraction in (.2, .4, .6, .8, 1):
                reach = min(width*.42, height*.7) * fraction
                canvas.create_line(corner, 110+reach, corner+sign*reach*.52, 110+reach*.52,
                                   corner+sign*reach, 110, fill=ink, smooth=True, width=1)
            for fraction in (.2, .5, .8):
                canvas.create_line(corner, 110, corner+sign*width*.32*fraction,
                                   110+height*.55*(1-fraction), fill=ink, width=1)
    elif theme == 'Hello Kitty':
        for x, y, size in ((width*.14, height*.44, 16), (width*.86, height*.44, 16),
                           (width*.25, height*.68, 10), (width*.75, height*.68, 10)):
            for offset in (-size*.55, size*.55):
                canvas.create_oval(x+offset-size*.55, y-size*.55, x+offset+size*.55, y+size*.55,
                                   fill=paint['ACTIVE'], outline=ink)
            canvas.create_oval(x-size*.25, y-size*.3, x+size*.25, y+size*.3,
                               fill=ink, outline='')
    elif theme == 'Formula 1':
        for side in (14, width-24):
            for row in range(10):
                canvas.create_rectangle(side, 118+row*12, side+8, 128+row*12,
                                        fill=ink if row%2 else paint['ACTIVE'], outline='')
        canvas.create_line(width*.22, height*.45, width*.22, height*.35, width*.3, height*.29,
                           width*.7, height*.29, width*.78, height*.35, width*.78, height*.45,
                           smooth=True, fill=ink, width=2)


def card_back(canvas, x, y, w, h, theme):
    """Hand-drawn themed backs, independent of external image downloads."""
    cx, cy = x+w/2, y+h/2
    if theme == 'Spider-Man':
        canvas.create_oval(x+w*.14, y+h*.16, x+w*.86, y+h*.84, fill='#cf2343', outline='#101c38')
        for offset in (-.16, 0, .16):
            canvas.create_line(cx+offset*w, y+h*.19, cx+offset*w*.6, cy, cx+offset*w, y+h*.81,
                               fill='#762039', width=max(1,w*.012))
        for offset in (-.15, .13):
            canvas.create_line(x+w*.18, cy+offset*h, cx, cy+offset*h*.6, x+w*.82, cy+offset*h,
                               fill='#762039', width=max(1,w*.012))
        for sign in (-1, 1):
            canvas.create_polygon(cx+sign*w*.04, cy, cx+sign*w*.28, cy-h*.12,
                                  cx+sign*w*.23, cy+h*.06, cx+sign*w*.10, cy+h*.10,
                                  fill='#f9fbff', outline='#101c38', width=max(1,w*.02))
    elif theme == 'Hello Kitty':
        for sign in (-1,1):
            canvas.create_polygon(cx+sign*w*.13, cy-h*.15, cx+sign*w*.28, cy-h*.29,
                                  cx+sign*w*.33, cy-h*.07, fill='#fffefa', outline='#79425c')
        canvas.create_oval(x+w*.14,y+h*.31,x+w*.86,y+h*.72,fill='#fffefa',outline='#79425c')
        for sign in (-1,1):
            ex=cx+sign*w*.17
            canvas.create_oval(ex-w*.025,cy-h*.006,ex+w*.025,cy+h*.04,fill='#3a2632',outline='')
            for dy in (-.055, .015, .085):
                canvas.create_line(cx+sign*w*.29,cy+dy*h,cx+sign*w*.41,cy+(dy+.01)*h,
                                   fill='#79425c',width=max(1,w*.013))
        canvas.create_oval(cx-w*.045,cy+h*.045,cx+w*.045,cy+h*.085,fill='#e8be38',outline='')
        bx,by=x+w*.72,y+h*.34
        for dx in (-.075,.075):
            canvas.create_oval(bx+(dx-.07)*w,by-h*.055,bx+(dx+.07)*w,by+h*.055,
                               fill='#eb4b8d',outline='#a5285e')
        canvas.create_oval(bx-w*.04,by-h*.035,bx+w*.04,by+h*.035,fill='#c82e70',outline='')
    elif theme == 'Formula 1':
        for side in (-1,1):
            for dy in (-.15,.15):
                canvas.create_rectangle(cx+side*w*.23-w*.055,cy+dy*h-h*.065,
                                         cx+side*w*.23+w*.055,cy+dy*h+h*.065,fill='#050608',outline='#99a3a9')
        canvas.create_polygon(cx-w*.06,cy-h*.28,cx+w*.06,cy-h*.28,cx+w*.14,cy+h*.22,
                              cx-w*.14,cy+h*.22,fill='#f1493f',outline='#ffaca6')
        for dy in (-.23,.22):
            canvas.create_rectangle(cx-w*.24,cy+dy*h,cx+w*.24,cy+(dy+.04)*h,fill='#ed463d',outline='')
        canvas.create_oval(cx-w*.065,cy-h*.015,cx+w*.065,cy+h*.075,fill='#f6f7f1',outline='#1b2025')
        for row in range(2):
            for col in range(6):
                canvas.create_rectangle(x+w*(.2+col*.1),y+h*(.84+row*.04),
                                         x+w*(.3+col*.1),y+h*(.88+row*.04),
                                         fill='#eeeeee' if (row+col)%2 else '#1d2329',outline='')
