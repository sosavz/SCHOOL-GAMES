"""Owner tools and a chat-code fun panel; authority is always checked by the server."""
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import tkinter as tk
import uuid


class HostControls:
    def can_play(self):
        return super().can_play() and not self.state.get('paused', False)

    def update_view(self):
        super().update_view()
        if not self.state: return
        if not self.linked(): self.stop_jumpscare()
        if hasattr(self, 'manage_button'):
            if self.seat == 0:
                self.manage_button.pack(side='right', padx=(7,0))
            else: self.manage_button.pack_forget()
        if self.state.get('paused') and self.state.get('game'):
            self.turn_panel.configure(bg=self.PANEL)
            self.turn_label.configure(text='PAUSED BY THE HOST', bg=self.PANEL, fg=self.GOLD)
            self.phase_label.configure(text='Take a break. The host can resume from Host controls.', bg=self.PANEL, fg=self.MUTED)
            self.guide_title.configure(text='Time for a little break.')
            self.guide_note.configure(text='Your game is saved here. Chat stays open while everyone waits.')
            self.title('Paused · Playroom')
        if self.state.get('next_die') is not None and self.state.get('game') and not self.state.get('paused'):
            self.banner.configure(text=f'Fun mode · The next dice roll is set to {self.state["next_die"]}.')
        if self.state.get('muted', [False]*self.state['player_count'])[self.seat]:
            self.chat_status.configure(text='The host muted your chat. You can still read and play.')
        serial=self.state.get('party_serial',0)
        if serial != getattr(self,'seen_party',0):
            self.seen_party=serial
            if serial: self.start_party(self.state.get('party_effect','confetti'))
        kitchen_serial=self.state.get('kitchen_serial',0)
        if kitchen_serial != getattr(self,'seen_kitchen',0):
            self.seen_kitchen=kitchen_serial
            if kitchen_serial: self.start_kitchen_banner()
        stop_serial=self.state.get('jumpscare_stop_serial',0)
        if stop_serial != getattr(self,'seen_jumpscare_stop',0):
            self.seen_jumpscare_stop=stop_serial
            if stop_serial: self.stop_jumpscare()
        jump_serial=self.state.get('jumpscare_serial',0)
        if jump_serial != getattr(self,'seen_jumpscare',0):
            self.seen_jumpscare=jump_serial
            if jump_serial: self.launch_jumpscare()
        troll_serial=self.state.get('troll_serial',0)
        if troll_serial != getattr(self,'seen_troll',0):
            self.seen_troll=troll_serial
            if troll_serial and self.state.get('troll_effect'):
                self.start_troll(self.state['troll_effect'])

    def send_chat(self,event=None):
        text=self.chat_draft.get().strip()
        if text.lower() == '/party':
            self.chat_draft.set(''); self.show_fun_menu(); return 'break'
        if text.casefold() == '/küche':
            self.chat_draft.set(''); self.run_kitchen_command(); return 'break'
        if text.lower().startswith('/jumpscare'):
            self.chat_draft.set(''); self.run_jumpscare_command(text); return 'break'
        if text.lower() == '/endjps':
            self.chat_draft.set(''); self.run_end_jumpscare(); return 'break'
        if text.lower() == '/troll':
            self.chat_draft.set('')
            if self.state and self.seat == 0: self.show_troll_menu()
            else: self.chat_feedback='Only the host can open the troll menu.'; self.refresh_chat()
            return 'break'
        return super().send_chat(event)

    def run_kitchen_command(self):
        if not self.state or self.seat != 0:
            self.chat_feedback='Only the lobby host can call the kitchen banner.'; self.refresh_chat(); return
        if self.state.get('game') is not None:
            self.chat_feedback='The kitchen banner is available in the waiting room only.'; self.refresh_chat(); return
        if self.manage('kitchen'):
            self.chat_feedback='Kitchen banner sent to everyone in the lobby.'
        else: self.chat_feedback='Could not send the kitchen banner.'
        self.refresh_chat()

    def run_jumpscare_command(self,text):
        """/jumpscare → every connected guest; /jumpscare Name → one guest. Works in the lobby and mid-game."""
        if not self.state or self.seat != 0:
            self.chat_feedback='Only the host can use /jumpscare.'; self.refresh_chat(); return
        parts=text.split(maxsplit=1)
        if parts[0].lower()!='/jumpscare':
            self.chat_feedback='Usage: /jumpscare  or  /jumpscare Player Name'; self.refresh_chat(); return
        needle=parts[1].strip().casefold() if len(parts)==2 else ''
        bots=set(self.state.get('bot_seats',[]))
        guests=[i for i in range(1,self.state['player_count']) if self.state['connected'][i] and i not in bots]
        if needle in ('','all','everyone','alle'):
            if not guests:
                self.chat_feedback='No connected guests to surprise yet.'; self.refresh_chat(); return
            target,who='all','everyone'
        else:
            targets=[i for i in guests if self.state['names'][i].casefold()==needle]
            if len(targets)!=1:
                self.chat_feedback='Player not found. Use the exact name of a connected guest, or just /jumpscare for everyone.'
                self.refresh_chat(); return
            target=targets[0]; who=self.state['names'][target]
        if self.manage('jumpscare',target=target):
            self.chat_feedback=f'Surprise sent to {who}. It plays at 50% volume. /endjps stops it.'
        else: self.chat_feedback='Could not send the surprise right now. Try again in a moment.'
        self.refresh_chat()

    def jumpscare_everyone(self):
        self.run_jumpscare_command('/jumpscare')

    def run_end_jumpscare(self):
        if not self.state or self.seat != 0:
            self.chat_feedback='Only the host can use /endjps.'; self.refresh_chat(); return
        if self.manage('end_jumpscare'):
            self.chat_feedback='Stop signal sent. The player can also press Esc or Close.'
        else: self.chat_feedback='There is no active video surprise to stop.'
        self.refresh_chat()

    def launch_jumpscare(self):
        folder=Path(__file__).resolve().parent
        video=folder/'assets'/'lobby-surprise.mp4'; helper=folder/'jumpscare_player.ps1'
        powershell=shutil.which('powershell.exe') or shutil.which('powershell')
        if not video.is_file() or not helper.is_file() or not powershell:
            self.chat_feedback='This PC cannot play the bundled video surprise.'; self.refresh_chat(); return
        self.stop_jumpscare()
        marker=Path(tempfile.gettempdir())/('playroom-stop-'+uuid.uuid4().hex+'.flag')
        args=[powershell,'-NoProfile','-STA','-WindowStyle','Hidden','-ExecutionPolicy','Bypass','-File',str(helper),str(video),str(marker)]
        try:
            flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
            self.jumpscare_process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                                    stderr=subprocess.DEVNULL,creationflags=flags)
            self.jumpscare_stop_file=marker
            self.jumpscare_watch()
        except OSError as exc:
            self.jumpscare_process=None; self.jumpscare_stop_file=None
            self.chat_feedback='Could not start the video player: '+str(exc); self.refresh_chat()

    def jumpscare_watch(self):
        process=getattr(self,'jumpscare_process',None)
        if process is None or process.poll() is not None:
            self.jumpscare_process=None; self.jumpscare_stop_file=None; return
        self.jumpscare_watch_job=self.after(250,self.jumpscare_watch)

    def stop_jumpscare(self):
        job=getattr(self,'jumpscare_watch_job',None)
        if job:
            try: self.after_cancel(job)
            except tk.TclError: pass
            self.jumpscare_watch_job=None
        marker=getattr(self,'jumpscare_stop_file',None)
        process=getattr(self,'jumpscare_process',None)
        # Only signal a player that is still running; otherwise the flag file would linger in %TEMP%.
        if marker and process is not None and process.poll() is None:
            try: Path(marker).touch()
            except OSError: pass
        self.jumpscare_stop_file=None
        self.jumpscare_process=None

    def manage(self,command,revision=None,**payload):
        if not self.state or self.seat != 0: return False
        return self.send_command(dict(type='manage',command=command,
            revision=self.state['revision'] if revision is None else revision,**payload))

    def confirm_management(self,title,note,command,parent=None,**payload):
        revision=self.state['revision']
        dialog=tk.Toplevel(self); dialog.title(title); dialog.geometry('560x300')
        dialog.configure(bg=self.BG); dialog.transient(parent or self); dialog.grab_set()
        frame=tk.Frame(dialog,bg=self.BG,padx=25,pady=22); frame.pack(fill='both',expand=True)
        self.label(frame,title,23,self.TEXT,True).pack(anchor='w')
        self.label(frame,note,12,self.MUTED,wraplength=505,justify='left').pack(anchor='w',pady=18)
        row=tk.Frame(frame,bg=self.BG); row.pack(side='bottom',fill='x')
        def close():
            dialog.destroy()
            if parent and parent.winfo_exists(): parent.grab_set()
        def apply():
            self.manage(command,revision,**payload); close()
        self.button(row,'Cancel',close,secondary=True).pack(side='left')
        self.button(row,title,apply,large=True).pack(side='right')
        dialog.bind('<Escape>',lambda e:close())

    def show_host_controls(self):
        if not self.state or self.seat != 0: return
        existing=getattr(self,'host_panel',None)
        if existing is not None and existing.winfo_exists(): existing.lift(); return
        window=tk.Toplevel(self); self.host_panel=window
        window.title('Host controls · Playroom'); window.geometry('760x660'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=22,pady=18); frame.pack(fill='both',expand=True)
        last=[None]; job=[None]
        def render():
            job[0]=None
            if not window.winfo_exists(): return
            if not self.state or self.seat != 0: window.destroy(); return
            key=(self.state['revision'],self.pending,self.linked(),self.error_text)
            if key != last[0]:
                last[0]=key
                for child in frame.winfo_children(): child.destroy()
                game=self.state['game']; running=game is not None and not game['done']
                self.label(frame,'You’re the host.',25,self.TEXT,True).pack(anchor='w')
                status='Waiting room' if not game else 'Paused by you' if self.state.get('paused') else 'Game finished' if game['done'] else 'Game in progress'
                self.label(frame,status+' · Changes are shared with everyone.',10,self.MUTED).pack(anchor='w',pady=(3,10))
                enabled=self.linked() and not self.pending
                def button(parent,text,fn,available=True):
                    result=self.button(parent,text,fn,secondary=True)
                    result.configure(state='normal' if enabled and available else 'disabled',pady=6)
                    return result
                top=tk.Frame(frame,bg=self.BG); top.pack(fill='x')
                locked=self.state.get('join_locked',False)
                button(top,'Unlock new joins' if locked else 'Lock new joins',lambda:self.manage('lock',value=not locked)).pack(side='left')
                button(top,'Game settings',self.show_host_settings,not game).pack(side='left',padx=8)
                button(top,'Remove open seats',lambda:self.manage('compact'),not game and not all(self.state.get('occupied',[True]*self.state['player_count']))).pack(side='left')
                self.label(frame,'PLAYERS',10,self.MUTED,True).pack(anchor='w',pady=(14,5))
                occupied=self.state.get('occupied',[True]*self.state['player_count'])
                for seat,name in enumerate(self.state['names']):
                    row=tk.Frame(frame,bg=self.PANEL,padx=10,pady=1); row.pack(fill='x',pady=2)
                    muted=self.state.get('muted',[False]*self.state['player_count'])[seat]
                    state='Host' if seat==0 else 'Open seat' if not occupied[seat] else 'Connected' if self.state['connected'][seat] else 'Offline · reserved'
                    if muted: state+=' · muted'
                    self.label(row,f'{seat+1}  {name[:20]}',11,self.TEXT,True,width=25,anchor='w').pack(side='left')
                    self.label(row,state,9,self.MUTED).pack(side='left')
                    if seat and occupied[seat]:
                        note='Remove this player and free their seat?'
                        if game: note+=' This ends the current game, resets scores and returns everyone to the lobby.'
                        button(row,'Kick',lambda s=seat,n=name,d=note:self.confirm_management('Kick '+n[:14]+'?',d,'kick',window,seat=s)).pack(side='right')
                        button(row,'Unmute' if muted else 'Mute',lambda s=seat,m=muted:self.manage('mute',seat=s,value=not m)).pack(side='right',padx=5)
                self.label(frame,'GAME CONTROLS',10,self.MUTED,True).pack(anchor='w',pady=(13,5))
                grid=tk.Frame(frame,bg=self.BG); grid.pack(fill='x')
                grid.columnconfigure(0,weight=1); grid.columnconfigure(1,weight=1)
                paused=self.state.get('paused',False)
                button(grid,'Resume game' if paused else 'Pause game',lambda:self.manage('pause',value=not paused),running).grid(row=0,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Restart round' if self.state['game_kind']=='uno' else 'Restart game',lambda:self.confirm_management('Restart?',
                    'Deal fresh cards and keep match scores.' if self.state['game_kind']=='uno' else 'Reset every pawn and roll for a new starter.', 'restart',window),running and all(self.state['connected'])).grid(row=0,column=1,sticky='ew',pady=3)
                button(grid,'New match · reset scores',lambda:self.confirm_management('New match?','Start immediately with everyone connected. All scores and game progress reset.','new_match',window),bool(game) and all(self.state['connected'])).grid(row=1,column=0,sticky='ew',padx=(0,5),pady=3)
                button(grid,'Return everyone to lobby',lambda:self.confirm_management('Back to lobby?','End this game and reset scores. Keep the room code and chat, then change rules or players.','lobby',window),bool(game)).grid(row=1,column=1,sticky='ew',pady=3)
                self.label(frame,self.error_text or 'A kick is not a ban. Lock new joins to prevent rejoining with the code. Saved players can still reconnect.',9,self.ERROR if self.error_text else self.MUTED,wraplength=710,justify='left').pack(anchor='w',pady=8)
                self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
            job[0]=window.after(200,render)
        def cleanup(e):
            if e.widget is window and job[0]:
                window.after_cancel(job[0]); job[0]=None
        window.bind('<Destroy>',cleanup); window.bind('<Escape>',lambda e:window.destroy()); render()

    def show_fun_menu(self):
        if not self.state: return
        window=tk.Toplevel(self); window.title('Secret party menu'); window.geometry('570x700'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=24,pady=20); frame.pack(fill='both',expand=True)
        self.label(frame,'You found the party! ★',24,self.GOLD,True).pack(anchor='w')
        host=self.seat==0
        self.label(frame,'Fun effects and host-only cheats. Everyone sees game-changing effects.',11,self.MUTED,wraplength=510,justify='left').pack(anchor='w',pady=(10,15))
        self.button(frame,'Confetti on my screen',self.start_party,large=True).pack(fill='x',pady=4)
        if host:
            self.button(frame,'Confetti for everyone',lambda:self.manage('party',effect='confetti'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Fireworks for everyone',lambda:self.manage('party',effect='fireworks'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Sparkle shower for everyone',lambda:self.manage('party',effect='sparkles'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Applause for everyone',lambda:self.manage('party',effect='applause'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Boo! Surprise the table',lambda:self.manage('party',effect='boo'),secondary=True).pack(fill='x',pady=4)
            self.button(frame,'Video jumpscare for everyone',self.jumpscare_everyone,secondary=True).pack(fill='x',pady=4)
            active=[i for i in self.state.get('jumpscare_active_targets',[]) if i<len(self.state['names'])]
            if active:
                who=', '.join(self.state['names'][i] for i in active)
                self.button(frame,'End video surprise for '+who[:40],lambda:self.run_end_jumpscare(),secondary=True).pack(fill='x',pady=4)
            if self.state['game_kind']=='uno':
                for label,effect in (('Give me a Wild','wild'),('Give me a +4','draw_four')):
                    self.button(frame,label,lambda v=effect:self.manage('party',effect=v),secondary=True).pack(fill='x',pady=4)
                self.label(frame,'Use on your UNO turn before drawing. Takes an existing card from the deck or discard pile.',10,self.MUTED,wraplength=510,justify='left').pack(pady=8)
            else:
                self.label(frame,'Choose the next dice roll (one use):',12,self.TEXT,True).pack(pady=(12,5))
                row=tk.Frame(frame,bg=self.BG); row.pack(fill='x')
                for n in range(1,7): self.button(row,str(n),lambda v=n:self.manage('party',effect='die',value=v),secondary=True).pack(side='left',fill='x',expand=True,padx=2)
            self.label(frame,'In chat, any time: /jumpscare (everyone) · /jumpscare Player Name · /endjps. More pranks: /troll',9,self.MUTED,wraplength=510,justify='left').pack(anchor='w',pady=(10,0))
        else:
            self.label(frame,'Only the host can change cards, dice or the whole table.',11,self.MUTED,wraplength=500).pack(pady=16)
        status=self.label(frame,'',10,self.ERROR,wraplength=510,justify='left'); status.pack(fill='x',pady=5)
        # Use the main polling loop only while the window exists; destroy cancels its timer.
        timer=[None]
        def tick():
            if not window.winfo_exists(): return
            if not self.state: window.destroy(); return
            status.configure(text=self.error_text); timer[0]=window.after(250,tick)
        window.bind('<Destroy>',lambda e:window.after_cancel(timer[0]) if e.widget is window and timer[0] else None)
        tick()
        self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
        window.bind('<Escape>',lambda e:window.destroy())

    def start_party(self,effect='confetti'):
        if not self.motion.get(): return
        self.local_party_effect=effect
        self.party_started=time.monotonic()
        if getattr(self,'party_job',None) is None: self.party_frame()

    def start_kitchen_banner(self):
        self.kitchen_until=time.monotonic()+5.0
        if getattr(self,'party_job',None):
            try: self.after_cancel(self.party_job)
            except tk.TclError: pass
        self.paint_kitchen_banner()
        self.party_job=self.after(100,self.kitchen_banner_frame)

    def kitchen_banner_frame(self):
        self.party_job=None
        if self.closing: return
        if time.monotonic() >= getattr(self,'kitchen_until',0):
            surface=self.party_surface()
            if surface is not None: surface.delete('party')
            return
        self.paint_kitchen_banner()
        self.party_job=self.after(100,self.kitchen_banner_frame)

    def paint_kitchen_banner(self):
        c=self.party_surface()
        if c is None: return
        c.delete('party')
        w,h=max(100,c.winfo_width()),max(100,c.winfo_height())
        panel_w=min(w-32,max(320,w*.84)); panel_h=min(160,max(116,h*.28))
        x,y=w/2,h*.48
        c.create_rectangle(x-panel_w/2+8,y-panel_h/2+9,x+panel_w/2+8,y+panel_h/2+9,
                           fill='#44362c',outline='',tags='party')
        c.create_rectangle(x-panel_w/2,y-panel_h/2,x+panel_w/2,y+panel_h/2,
                           fill='#fff4da',outline='#9b5f37',width=5,tags='party')
        c.create_text(x,y-panel_h*.13,text='🍳  KÜCHENPARTY  🍳',
                      font=('Segoe UI',max(16,min(30,int(w*.032))),'bold'),fill='#795033',tags='party')
        size=max(22,min(58,int(w*.061)))
        c.create_text(x,y+panel_h*.22,text='Alle ab in die Küche!',
                      font=('Segoe UI',size,'bold'),fill='#49352b',width=panel_w-32,
                      justify='center',tags='party')

    def party_frame(self):
        self.party_job=None
        if self.closing: return
        if time.monotonic()<getattr(self,'kitchen_until',0):
            self.paint_kitchen_banner(); self.party_job=self.after(100,self.kitchen_banner_frame); return
        if not self.motion.get() or time.monotonic()-self.party_started>=2.2:
            surface=self.party_surface()
            if surface is not None: surface.delete('party')
            return
        self.paint_party()
        self.party_job=self.after(20,self.party_frame)

    def paint_party(self):
        c=self.party_surface()
        if c is None: return
        if time.monotonic()<getattr(self,'kitchen_until',0):
            self.paint_kitchen_banner(); return
        c.delete('party')
        t=(time.monotonic()-getattr(self,'party_started',0))/2.2
        if not 0<=t<1 or not self.motion.get(): return
        w,h=c.winfo_width(),c.winfo_height()
        effect=getattr(self,'local_party_effect','confetti')
        if effect=='boo':
            x,y=w/2,h/2+math.sin(t*12)*12
            c.create_oval(x-42,y-50,x+42,y+40,fill='white',outline='#514bcb',width=3,tags='party')
            for dx in (-15,15): c.create_oval(x+dx-5,y-23,x+dx+5,y-9,fill='#514bcb',outline='',tags='party')
            c.create_text(x,y+13,text='BOO!',font=('Segoe UI',17,'bold'),fill='#514bcb',tags='party')
            return
        if effect=='applause':
            c.create_text(w/2,h*.32,text='👏',font=('Segoe UI',72),tags='party')
            c.create_text(w/2,h*.32+85,text='NICE ONE!',font=('Segoe UI',21,'bold'),fill=self.GOLD,tags='party')
            for i in range(18):
                x=(i*97+math.sin(t*8+i)*30)%max(w,1); y=(i*53+t*h)%max(h,1)
                c.create_text(x,y,text='✦',font=('Segoe UI',15,'bold'),fill=('#e7bd32','#df3e55','#514bcb')[i%3],tags='party')
            return
        if effect=='fireworks':
            for burst,(bx,by) in enumerate(((.27,.34),(.71,.28),(.52,.56))):
                radius=18+((t*150+burst*27)%110); cx,cy=w*bx,h*by
                for ray in range(12):
                    angle=ray*math.tau/12+t*2
                    x,y=cx+math.cos(angle)*radius,cy+math.sin(angle)*radius
                    c.create_oval(x-3,y-3,x+3,y+3,fill=('#e7bd32','#df3e55','#514bcb','#25955b')[ray%4],outline='',tags='party')
            return
        if effect=='sparkles':
            for i in range(42):
                x=(i*79+math.sin(t*10+i*1.7)*38)%max(w,1); y=(i*47+t*90)%max(h,1)
                c.create_text(x,y,text='✦' if i%2 else '✧',font=('Segoe UI',10+i%11,'bold'),
                              fill=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5],tags='party')
            return
        for i in range(70):
            x=(i*87+math.sin(t*8+i)*25)%max(w,1); y=-90+(i*29)%160+t*(h+160)
            if 0<y<h: c.create_line(x-4,y-3,x+4,y+3,fill=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5],width=4,tags='party')

    def party_surface(self):
        name='party_canvas' if self.scene=='room' else 'canvas'
        canvas=getattr(self,name,None)
        return canvas if canvas is not None and canvas.winfo_exists() else None

    def draw(self):
        super().draw(); self.paint_party()

    # ---------------------------------------------------------------- /troll
    TROLLS = (('shake','🌋  Earthquake','Shakes their whole game window.'),
              ('fake_kick','🚪  Fake kick','“You were removed from this room”… just kidding.'),
              ('fake_lag','📶  Fake disconnect','Fake “Connection lost · Reconnecting…” screen.'),
              ('fake_penalty','🃏  Fake penalty','“+4 cards!” / “All pawns go home!”… not really.'),
              ('blackout','🔦  Lights out','Their screen goes pitch black for a moment.'),
              ('upside_down','🙃  Upside down','A giant upside-down message spins back around.'),
              ('clown_rain','🤡  Clown rain','Clowns pour down over their table.'),
              ('ghost','👻  Ghost chase','A ghost swoops across their screen.'))
    TROLL_SECONDS = {'shake':1.6,'fake_kick':3.4,'fake_lag':3.8,'fake_penalty':3.2,'blackout':3.0,
                     'upside_down':3.0,'clown_rain':3.2,'ghost':2.8}
    TROLL_KEY = '#ff00fe'  # Transparent colour for see-through effects.

    def troll_guests(self):
        bots=set(self.state.get('bot_seats',[])) if self.state else set()
        return [i for i in range(1,self.state['player_count']) if self.state['connected'][i] and i not in bots] if self.state else []

    def show_troll_menu(self):
        existing=getattr(self,'troll_menu',None)
        if existing is not None and existing.winfo_exists(): existing.lift(); return
        window=tk.Toplevel(self); self.troll_menu=window
        window.title('Troll menu · Playroom'); window.geometry('620x700'); window.resizable(False,False)
        window.configure(bg=self.BG); window.transient(self)
        frame=tk.Frame(window,bg=self.BG,padx=24,pady=18); frame.pack(fill='both',expand=True)
        self.label(frame,'Troll menu 😈',25,self.GOLD,True).pack(anchor='w')
        self.label(frame,'Harmless pranks that only play on the target’s screen. They never change cards, pawns or turns.',10,self.MUTED,wraplength=560,justify='left').pack(anchor='w',pady=(6,12))
        row=tk.Frame(frame,bg=self.BG); row.pack(fill='x')
        self.label(row,'Target',11,self.TEXT,True).pack(side='left')
        target=tk.StringVar(master=window,value='Everyone')
        picker=tk.OptionMenu(row,target,'Everyone')
        picker.configure(bg=self.BUTTON,fg=self.TEXT,highlightthickness=0,relief='flat',font=('Segoe UI',10,'bold'),width=22)
        picker.pack(side='left',padx=10)
        preview=tk.BooleanVar(master=window,value=False)
        tk.Checkbutton(row,text='Test on my screen only',variable=preview,bg=self.BG,fg=self.TEXT,selectcolor=self.BG,
                       activebackground=self.BG,activeforeground=self.TEXT,font=('Segoe UI',9,'bold'),relief='flat').pack(side='right')
        status=self.label(frame,'',10,self.MUTED,wraplength=560,justify='left')
        grid=tk.Frame(frame,bg=self.BG); grid.pack(fill='x',pady=(14,4))
        grid.columnconfigure(0,weight=1,uniform='troll'); grid.columnconfigure(1,weight=1,uniform='troll')
        choices={}
        def chosen():
            name=target.get()
            return 'all' if name=='Everyone' else choices.get(name)
        def say(text,error=False): status.configure(text=text,fg=self.ERROR if error else self.MUTED)
        def fire(effect,title):
            if preview.get():
                self.start_troll(effect); say(f'Preview: {title.split("  ",1)[-1]} on your screen.'); return
            who=chosen()
            if who is None: say('That player left. Choose another target.',True); return
            if not self.troll_guests(): say('No connected guests to troll yet. Tick “Test on my screen only” to try it.',True); return
            if self.manage('troll',effect=effect,target=who):
                say(f'{title.split("  ",1)[-1]} sent to {target.get()}! 😈')
            else: say('Could not send right now (a move may be in flight). Try again in a second.',True)
        for index,(effect,title,note) in enumerate(self.TROLLS):
            cell=tk.Frame(grid,bg=self.BG); cell.grid(row=index//2,column=index%2,sticky='ew',padx=4,pady=4)
            self.button(cell,title,lambda e=effect,t=title:fire(e,t),secondary=True).pack(fill='x')
            self.label(cell,note,8,self.MUTED,wraplength=270,justify='left').pack(anchor='w',pady=(2,0))
        self.label(frame,'VIDEO JUMPSCARE',10,self.MUTED,True).pack(anchor='w',pady=(12,4))
        jrow=tk.Frame(frame,bg=self.BG); jrow.pack(fill='x')
        def jumpscare():
            if preview.get():
                self.launch_jumpscare(); say('Preview: playing the jumpscare on your PC. Esc closes it.')
                return
            who=chosen()
            if who is None or not self.troll_guests(): say('No connected guest to scare yet.',True); return
            if self.manage('jumpscare',target=who): say(f'Jumpscare sent to {target.get()}! /endjps stops it.')
            else: say('Could not send the jumpscare right now. Try again in a second.',True)
        self.button(jrow,'😱  Send video jumpscare',jumpscare,large=True).pack(side='left',fill='x',expand=True)
        self.button(jrow,'Stop video',lambda:(self.run_end_jumpscare(),say(self.chat_feedback)),secondary=True).pack(side='left',padx=(8,0))
        status.pack(fill='x',pady=(10,0))
        self.button(frame,'Done',window.destroy).pack(side='bottom',anchor='e')
        last=[None]; job=[None]
        def refresh():
            job[0]=None
            if not window.winfo_exists(): return
            if not self.state or self.seat!=0: window.destroy(); return
            guests=self.troll_guests()
            key=tuple((i,self.state['names'][i]) for i in guests)
            if key!=last[0]:
                last[0]=key; choices.clear(); menu=picker['menu']; menu.delete(0,'end')
                for label,value in [('Everyone','all')]+[(f'P{i+1} · {self.state["names"][i]}',i) for i in guests]:
                    if value!='all': choices[label]=value
                    menu.add_command(label=label,command=lambda v=label:target.set(v))
                if target.get()!='Everyone' and target.get() not in choices: target.set('Everyone')
                if not guests and not status.cget('text'):
                    say('No guests connected yet. Tick “Test on my screen only” to try the effects yourself.')
            job[0]=window.after(700,refresh)
        window.bind('<Destroy>',lambda e:window.after_cancel(job[0]) if e.widget is window and job[0] else None)
        window.bind('<Escape>',lambda e:window.destroy())
        refresh()

    def start_troll(self,effect):
        if effect not in self.TROLL_SECONDS or self.closing: return
        if self.wm_state() in ('iconic','withdrawn'): return  # self.state is the room snapshot, not Tk's state().
        self.end_troll()
        self.troll=(effect,time.monotonic())
        opaque=effect in ('fake_kick','fake_lag','blackout')
        if effect!='shake':
            win=tk.Toplevel(self); win.overrideredirect(True)
            canvas=tk.Canvas(win,highlightthickness=0,bd=0,bg='#05060c' if opaque else self.TROLL_KEY)
            canvas.pack(fill='both',expand=True)
            if not opaque:
                try: win.attributes('-transparentcolor',self.TROLL_KEY)
                except tk.TclError: canvas.configure(bg='#05060c')  # No transparency support: fall back to opaque.
            win.bind('<Escape>',lambda e:self.end_troll()); win.bind('<Button-1>',lambda e:None)
            self.troll_win=win; self.troll_canvas=canvas
        if effect in ('fake_kick','fake_penalty'): self.play_sound('capture')
        elif effect in ('ghost','clown_rain'): self.play_sound('launch')
        self.troll_frame()

    def troll_frame(self):
        self.troll_job=None
        state=getattr(self,'troll',None)
        if not state or self.closing: return
        effect,started=state
        elapsed=time.monotonic()-started; total=self.TROLL_SECONDS[effect]
        if elapsed>=total: self.end_troll(); return
        t=elapsed/total
        try:
            if effect=='shake':
                power=14*(1-t)
                dx=int(math.sin(elapsed*55)*power); dy=int(math.cos(elapsed*47)*power*.6)
                self.body.pack_configure(padx=(max(0,28+dx),max(0,28-dx)),pady=(max(0,dy),max(0,22-dy)))
            else:
                win,c=self.troll_win,self.troll_canvas
                if not win.winfo_exists(): self.end_troll(); return
                w,h=max(200,self.winfo_width()),max(200,self.winfo_height())
                win.geometry(f'{w}x{h}+{self.winfo_rootx()}+{self.winfo_rooty()}'); win.lift(self)
                c.delete('all'); getattr(self,'paint_troll_'+effect)(c,w,h,t,elapsed)
        except tk.TclError:
            self.end_troll(); return
        self.troll_job=self.after(30,self.troll_frame)

    def end_troll(self):
        job=getattr(self,'troll_job',None)
        if job:
            try: self.after_cancel(job)
            except tk.TclError: pass
        self.troll_job=None
        state=getattr(self,'troll',None); self.troll=None
        if state and state[0]=='shake':
            try: self.body.pack_configure(padx=28,pady=(0,22))
            except tk.TclError: pass
        win=getattr(self,'troll_win',None); self.troll_win=None
        if win is not None:
            try: win.destroy()
            except tk.TclError: pass

    def troll_text(self,c,x,y,text,size,fill,**kw):
        """Bold text with a dark outline so it stays crisp over any table colour."""
        font=kw.pop('font',('Segoe UI',int(size),'bold'))
        for ox,oy in ((-2,0),(2,0),(0,-2),(0,2)):
            c.create_text(x+ox,y+oy,text=text,font=font,fill='#11131c',**kw)
        c.create_text(x,y,text=text,font=font,fill=fill,**kw)

    def paint_troll_fake_kick(self,c,w,h,t,elapsed):
        bw,bh=min(w-40,560),220; x,y=(w-bw)/2,(h-bh)/2
        if elapsed<2.2:
            c.create_rectangle(x,y,x+bw,y+bh,fill='#f4f4f4',outline='#9a9a9a',width=2)
            c.create_rectangle(x,y,x+bw,y+34,fill='#ffffff',outline='')
            c.create_text(x+14,y+17,text='Playroom',anchor='w',font=('Segoe UI',10),fill='#222222')
            c.create_text(x+bw-18,y+17,text='✕',font=('Segoe UI',11),fill='#444444')
            c.create_oval(x+28,y+66,x+76,y+114,fill='#d93a3a',outline='')
            c.create_text(x+52,y+90,text='✕',font=('Segoe UI',20,'bold'),fill='white')
            c.create_text(x+96,y+76,text='Removed from room',anchor='w',font=('Segoe UI',15,'bold'),fill='#1b1b1b')
            c.create_text(x+96,y+108,text='The host removed you from this room.\nYour saved seat was deleted.',anchor='nw',
                          font=('Segoe UI',10),fill='#333333')
            c.create_rectangle(x+bw-118,y+bh-50,x+bw-22,y+bh-18,fill='#e1e1e1',outline='#0067c0',width=2)
            c.create_text(x+bw-70,y+bh-34,text='OK',font=('Segoe UI',10),fill='#111111')
        else:
            pop=min(1,(elapsed-2.2)/.25)
            self.troll_text(c,w/2,h/2-20,'JUST KIDDING',int(28+30*pop),'#ffe177')
            self.troll_text(c,w/2,h/2+50,'😜  You’re still in the game.',18,'#ffffff')

    def paint_troll_fake_lag(self,c,w,h,t,elapsed):
        if elapsed<2.8:
            attempt=1+int(elapsed/0.9)
            c.create_text(w/2,h/2-70,text='Connection lost',font=('Segoe UI',28,'bold'),fill='#f2f2f2')
            c.create_text(w/2,h/2-28,text=f'Reconnecting… attempt {attempt}',font=('Segoe UI',13),fill='#a9b0c4')
            for i in range(12):
                angle=i*math.tau/12+elapsed*5; shade=int(60+195*i/11)
                cx,cy=w/2+math.cos(angle)*34,h/2+40+math.sin(angle)*34
                c.create_oval(cx-5,cy-5,cx+5,cy+5,fill=f'#{shade:02x}{shade:02x}{shade:02x}',outline='')
            c.create_text(w/2,h/2+112,text='Your cards may be lost if you close this window.',font=('Segoe UI',10),fill='#6f7690')
        else:
            self.troll_text(c,w/2,h/2-10,'GOTCHA! 😎',46,'#ffe177')
            c.create_text(w/2,h/2+50,text='You never left. The host is trolling you.',font=('Segoe UI',14,'bold'),fill='#ffffff')

    def paint_troll_blackout(self,c,w,h,t,elapsed):
        if t<.82:
            fade=min(1,elapsed/.9); g=int(40+150*fade)
            c.create_text(w/2,h/2,text='Who turned off the lights?',font=('Segoe UI',20,'bold'),fill=f'#{g:02x}{g:02x}{g:02x}')
            px,py=self.winfo_pointerx()-self.winfo_rootx(),self.winfo_pointery()-self.winfo_rooty()
            c.create_oval(px-26,py-26,px+26,py+26,outline='#2a2a2a',width=2)
        else:
            c.create_text(w/2,h/2,text='💡',font=('Segoe UI Emoji',64))

    def paint_troll_fake_penalty(self,c,w,h,t,elapsed):
        board=self.state and self.state.get('game_kind')=='maedn'
        bw,bh=min(w-40,620),170; x,y=(w-bw)/2,h*.38
        c.create_rectangle(x+6,y+8,x+bw+6,y+bh+8,fill='#11131c',outline='')
        c.create_rectangle(x,y,x+bw,y+bh,fill='#d93a3a' if elapsed<2.0 else '#25955b',outline='#ffffff',width=4)
        if elapsed<2.0:
            big,small=(('ALL PAWNS GO HOME!','Every one of your pawns was captured.') if board else
                       ('+4 CARDS FOR YOU!','You forgot to call UNO. Four cards added.'))
        else:
            big,small='…NOT REALLY 😉','Nothing changed. The host is just messing with you.'
        wobble=math.sin(elapsed*30)*4 if elapsed<.6 else 0
        c.create_text(w/2+wobble,y+64,text=big,font=('Segoe UI',30,'bold'),fill='#ffffff')
        c.create_text(w/2,y+118,text=small,font=('Segoe UI',13,'bold'),fill='#ffffff')

    def paint_troll_upside_down(self,c,w,h,t,elapsed):
        spin=max(0,1-max(0,t-.45)/.4)
        angle=180*spin
        if spin>0:
            self.troll_text(c,w/2,h/2,'Your screen is upside down!',30,'#ffe177',angle=angle)
        else:
            self.troll_text(c,w/2,h/2,'Nope 🙃',48,'#ffe177')

    def paint_troll_clown_rain(self,c,w,h,t,elapsed):
        for i in range(46):
            x=(i*97.3+math.sin(elapsed*3+i)*30)%w
            y=-80+((i*53)%240)+elapsed*(h+240)/self.TROLL_SECONDS['clown_rain']*1.1
            if -60<y<h+40:
                c.create_text(x,y,text='🤡' if i%5 else '🎈',font=('Segoe UI Emoji',18+(i*7)%22))
        if .25<t<.85: self.troll_text(c,w/2,h*.18,'CLOWN TABLE 🤡',30,'#ffffff')

    def paint_troll_ghost(self,c,w,h,t,elapsed):
        x=-120+(w+240)*t; y=h*.5+math.sin(t*math.tau*2)*h*.18; s=1+t*1.6
        c.create_text(x,y,text='👻',font=('Segoe UI Emoji',int(54*s)))
        if .3<t<.9: self.troll_text(c,x,y-70*s,'BOO!',int(26*s),'#ffffff')

    def close(self):
        self.end_troll()
        self.stop_jumpscare()
        if getattr(self,'party_job',None): self.after_cancel(self.party_job); self.party_job=None
        super().close()

    def leave(self,*args,**kwargs):
        self.end_troll()
        self.stop_jumpscare()
        return super().leave(*args,**kwargs)
