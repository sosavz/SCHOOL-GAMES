param(
    [Parameter(Mandatory=$true)][string]$VideoPath,
    [Parameter(Mandatory=$true)][string]$StopFile
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" WindowState="Maximized" Topmost="True"
        Background="Black" ShowInTaskbar="True" Focusable="True">
  <Grid>
    <MediaElement x:Name="Clip" LoadedBehavior="Manual" UnloadedBehavior="Stop"
                  Stretch="Uniform" Volume="0.8" />
    <Button x:Name="CloseButton" Content="Close video  |  Esc" HorizontalAlignment="Right"
            VerticalAlignment="Top" Margin="18" Padding="18,10" FontSize="16"
            FontWeight="Bold" Foreground="White" Background="#CC20263E"
            BorderBrush="White" BorderThickness="2" Focusable="True" />
  </Grid>
</Window>
'@

# Default playback device volume via Core Audio. Any failure leaves the volume untouched and the clip still plays.
$volume = $null
try {
    Add-Type -ErrorAction Stop -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), ComImport]
interface IAudioEndpointVolume {
    int RegisterControlChangeNotify(IntPtr notify); int UnregisterControlChangeNotify(IntPtr notify);
    int GetChannelCount(out uint count);
    int SetMasterVolumeLevel(float level, ref Guid context); int SetMasterVolumeLevelScalar(float level, ref Guid context);
    int GetMasterVolumeLevel(out float level); int GetMasterVolumeLevelScalar(out float level);
    int SetChannelVolumeLevel(uint channel, float level, ref Guid context); int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid context);
    int GetChannelVolumeLevel(uint channel, out float level); int GetChannelVolumeLevelScalar(uint channel, out float level);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context); int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), ComImport]
interface IMMDevice { int Activate(ref Guid iid, int context, IntPtr parameters, [MarshalAs(UnmanagedType.IUnknown)] out object result); }
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), ComImport]
interface IMMDeviceEnumerator { int EnumAudioEndpoints(int flow, int mask, out IntPtr devices); int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice device); }
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumerator {}
public class PlayroomVolume {
    IAudioEndpointVolume endpoint; float oldLevel; bool oldMute; bool changed;
    public PlayroomVolume() {
        IMMDevice device;
        Marshal.ThrowExceptionForHR(((IMMDeviceEnumerator)new MMDeviceEnumerator()).GetDefaultAudioEndpoint(0, 1, out device));
        Guid iid = typeof(IAudioEndpointVolume).GUID; object result;
        Marshal.ThrowExceptionForHR(device.Activate(ref iid, 23, IntPtr.Zero, out result));
        endpoint = (IAudioEndpointVolume)result;
    }
    public float Level { get { float v; endpoint.GetMasterVolumeLevelScalar(out v); return v; } }
    public bool Muted { get { bool m; endpoint.GetMute(out m); return m; } }
    public void Apply(float level) {
        Guid none = Guid.Empty;
        oldLevel = Level; oldMute = Muted; changed = true;
        endpoint.SetMute(false, ref none); endpoint.SetMasterVolumeLevelScalar(level, ref none);
    }
    public void Restore() {
        if (!changed) return; changed = false; Guid none = Guid.Empty;
        endpoint.SetMasterVolumeLevelScalar(oldLevel, ref none); endpoint.SetMute(oldMute, ref none);
    }
}
'@
    $volume = New-Object PlayroomVolume
} catch { $volume = $null }

$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$clip = $window.FindName('Clip')
$closeButton = $window.FindName('CloseButton')
$closeButton.Add_Click({ $window.Close() })
$window.Add_KeyDown({ if ($_.Key -eq [Windows.Input.Key]::Escape) { $window.Close() } })
$clip.Add_MediaEnded({ $window.Close() })
$clip.Add_MediaFailed({ $window.Close() })
$clip.Source = [Uri]::new((Resolve-Path -LiteralPath $VideoPath).Path)

$stopTimer = [Windows.Threading.DispatcherTimer]::new()
$stopTimer.Interval = [TimeSpan]::FromMilliseconds(200)
$stopTimer.Add_Tick({
    if (Test-Path -LiteralPath $StopFile) {
        Remove-Item -LiteralPath $StopFile -Force -ErrorAction SilentlyContinue
        $window.Close()
    }
})
$window.Add_Closed({ $stopTimer.Stop(); $clip.Stop(); if ($volume) { try { $volume.Restore() } catch {} } })
$window.Add_Loaded({
    $window.Activate() | Out-Null; $window.Focus() | Out-Null
    # Jumpscare volume: 50% and unmuted; the previous level and mute state are restored on close.
    if ($volume) { try { $volume.Apply(0.5) } catch {} }
    $clip.Play(); $stopTimer.Start()
})
try { $window.ShowDialog() | Out-Null }
finally { if ($volume) { try { $volume.Restore() } catch {} } }
