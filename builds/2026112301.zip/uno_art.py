"""Vector card art. No external images or packages required."""
import math
from uno_themes import card_back

def rounded(canvas, x1, y1, x2, y2, radius=16, **options):
    radius = max(0, min(radius, (x2 - x1) / 2, (y2 - y1) / 2))
    points = [x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
              x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
              x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1]
    return canvas.create_polygon(points, smooth=True, splinesteps=24, **options)


def paint_uno_card(canvas, x, y, w, h, card=None, playable=False):
    """Resolution-independent deck artwork, shared by the game and SVG export."""
    ink = {'Red':'#ed2734', 'Yellow':'#f6c629', 'Green':'#17a767', 'Blue':'#168de2', 'Wild':'#161b26'}
    light = {'Red':'#f8606a', 'Yellow':'#ffdc5e', 'Green':'#3fc487', 'Blue':'#4aa9ee', 'Wild':'#2c3345'}
    deep = {'Red':'#b8121f', 'Yellow':'#d29d05', 'Green':'#0b7c4a', 'Blue':'#0b62a8', 'Wild':'#07090f'}
    if playable:
        rounded(canvas, x-4, y-4, x+w+4, y+h+4, w*.15, fill='', outline='#ffe58a', width=max(2, w*.04))
    rounded(canvas, x+1, y+6, x+w+3, y+h+7, w*.13, fill='#a9a8bf', outline='')
    rounded(canvas, x, y+2, x+w+1, y+h+3, w*.12, fill='#c9c8da', outline='')
    rounded(canvas, x, y, x+w, y+h, w*.12, fill='#fffdf7', outline='#f2c94c' if playable else '#d4d7dc', width=3 if playable else 1)
    inset=w*.065
    color, value = card if card else ('Wild','UNO')
    fill=ink[color]
    symbol_fill='#9c7400' if color=='Yellow' else fill
    rounded(canvas,x+inset,y+inset,x+w-inset,y+h-inset,w*.08,fill=fill,outline=deep[color],width=max(1,w*.012))
    if card:
        # soft sheen on the upper half and a darker foot give the face some depth
        rounded(canvas,x+inset*1.6,y+inset*1.5,x+w-inset*1.6,y+h*.42,w*.07,fill=light[color],outline='')
        rounded(canvas,x+inset*1.6,y+inset*2.2,x+w-inset*1.6,y+h*.46,w*.07,fill=fill,outline='')
        canvas.create_line(x+inset*1.4,y+h-inset*1.3,x+w-inset*1.4,y+h-inset*1.3,fill=deep[color],width=max(1,w*.02))
    theme = getattr(canvas, 'design', 'Classic')
    style=getattr(canvas,'card_back_style','Room')
    if not card and style in ('Midnight','Pearl','Sunburst'):
        back,detail={'Midnight':('#171d34','#d6bd77'),'Pearl':('#edf1f4','#506c87'),'Sunburst':('#de9a28','#fff1b3')}[style]
        rounded(canvas,x+inset,y+inset,x+w-inset,y+h-inset,w*.08,fill=back,outline='')
        rounded(canvas,x+w*.14,y+h*.12,x+w*.86,y+h*.88,w*.08,fill='',outline=detail,width=max(1,w*.015))
        for index in range(8):
            angle=index*math.pi/4
            canvas.create_line(x+w*.5+math.cos(angle)*w*.12,y+h*.5+math.sin(angle)*h*.12,
                               x+w*.5+math.cos(angle)*w*.29,y+h*.5+math.sin(angle)*h*.29,fill=detail,width=max(1,w*.018))
        canvas.create_text(x+w*.5,y+h*.5,text='✦',font=('Segoe UI Symbol',max(7,int(w*.27)),'bold'),fill=detail)
        return
    if not card and theme not in ('Classic', 'Playroom'):
        from uno_themes import THEMES
        back_color = THEMES.get(theme, THEMES['Classic'])['BOARD']
        rounded(canvas,x+inset,y+inset,x+w-inset,y+h-inset,w*.08,fill=back_color,outline='')
        card_back(canvas, x, y, w, h, theme)
        return
    cx,cy=x+w/2,y+h/2
    tilt=-.36
    def ellipse_point(angle, rx=w*.34, ry=h*.34):
        a,b=rx*math.cos(angle),ry*math.sin(angle)
        return (cx+a*math.cos(tilt)-b*math.sin(tilt), cy+a*math.sin(tilt)+b*math.cos(tilt))
    shadow=[v for i in range(60) for v in ellipse_point(i*2*math.pi/60)]
    canvas.create_polygon([c+(1.5 if n%2 else .8) for n,c in enumerate(shadow)],fill=deep[color],outline='',smooth=True)
    oval=[v for i in range(60) for v in ellipse_point(i*2*math.pi/60)]
    canvas.create_polygon(oval,fill='#fbfcf7',outline='',smooth=True)
    if card and w >= 40:
        ring=[v for i in range(60) for v in ellipse_point(i*2*math.pi/60,w*.315,h*.315)]
        canvas.create_polygon(ring,fill='',outline=light[color] if color!='Wild' else '#d9dce6',width=max(1,w*.01),smooth=True)
    def text(px,py,label,size,paint,angle=0):
        canvas.create_text(px,py,text=label,font=('Arial',max(5,int(size)),'bold'),fill=paint,angle=angle)
    if not card:
        canvas.create_polygon([v for i in range(60) for v in ellipse_point(i*2*math.pi/60,w*.29,h*.29)],fill='#eb2838',outline='')
        text(cx+1,cy+2,'UNO',w*.29,'#161b26',18)
        text(cx,cy,'UNO',w*.29,'#ffe459',18)
        return
    corner={'Skip':'⊘','Reverse':'⇄','Wild':'W'}.get(value,value)
    index_ink='#382b12' if color=='Yellow' else 'white'
    for px,py,angle in ((x+w*.20,y+h*.15,0),(x+w*.80,y+h*.85,180)):
        text(px+max(1,w*.012),py+max(1,w*.012),corner,w*.19,deep[color],angle)
        text(px,py,corner,w*.19,index_ink,angle)
    if color!='Wild' and w >= 34:
        # colour-blind helper: a small shape pip per colour in the free corners
        r=w*.045; px,py=x+w*.80,y+h*.14
        for qx,qy in ((px,py),(x+w*.20,y+h*.86)):
            if color=='Red':
                canvas.create_oval(qx-r,qy-r,qx+r,qy+r,fill=index_ink,outline='')
            elif color=='Yellow':
                canvas.create_polygon(qx,qy-r*1.2,qx+r*1.1,qy+r*.8,qx-r*1.1,qy+r*.8,fill=index_ink,outline='')
            elif color=='Green':
                canvas.create_rectangle(qx-r*.9,qy-r*.9,qx+r*.9,qy+r*.9,fill=index_ink,outline='')
            else:
                canvas.create_polygon(qx,qy-r*1.2,qx+r*1.1,qy,qx,qy+r*1.2,qx-r*1.1,qy,fill=index_ink,outline='')
    if color=='Wild':
        for sector,c in enumerate(('Red','Yellow','Green','Blue')):
            pts=[cx,cy]+[v for i in range(16) for v in ellipse_point((sector*15+i)*2*math.pi/60,w*.29,h*.29)]
            canvas.create_polygon(pts,fill=ink[c],outline='')
        if value=='+4':
            for i,c in enumerate(('Blue','Green','Yellow','Red')):
                xx=cx-w*.23+i*w*.10
                yy=cy-h*.13+(i%2)*h*.07
                rounded(canvas,xx,yy,xx+w*.24,yy+h*.26,w*.025,fill=ink[c],outline='white',width=max(1,w*.025))
    elif value=='Skip':
        radius=w*.23
        canvas.create_oval(cx-radius,cy-radius,cx+radius,cy+radius,outline=symbol_fill,width=max(2,w*.065))
        canvas.create_line(cx-radius*.75,cy+radius*.75,cx+radius*.75,cy-radius*.75,fill=symbol_fill,width=max(2,w*.065))
    elif value=='Reverse':
        for sign in (-1,1):
            yy=cy+sign*h*.055
            canvas.create_line(cx-sign*w*.24,yy,cx+sign*w*.22,yy,fill=symbol_fill,width=max(3,w*.08),
                               arrow='last',arrowshape=(w*.16,w*.18,w*.12))
    elif value=='+2':
        for i in range(2):
            xx=cx-w*.23+i*w*.15; yy=cy-h*.19+i*h*.12
            rounded(canvas,xx,yy,xx+w*.31,yy+h*.32,w*.025,fill=fill,outline='white',width=max(1,w*.025))
    else:
        text(cx+1,cy+1,value,w*.67,'#162722')
        text(cx,cy-1,value,w*.65,symbol_fill)
        if value in ('6','9'):
            canvas.create_line(cx-w*.12,cy+h*.20,cx+w*.12,cy+h*.20,fill=fill,width=max(1,w*.025))


