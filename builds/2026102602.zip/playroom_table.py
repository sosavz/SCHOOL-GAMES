"""Vector game tables and deterministic presentation-only animation."""
import math
import time
from uno_art import rounded, paint_uno_card
from uno_rules import UNO_COLORS
from uno_themes import decorate_table, THEMES
from maedn_view import board_layout, PAWN_COLORS, PAWN_NAMES
from playroom_widgets import mix, pawn, die
from theme_scenes import paint_scene

CARD_COLORS={'Red':'#df3e55','Yellow':'#e5bd24','Green':'#25955b','Blue':'#287ec3','Wild':'#514bcb'}


class TableVisuals:
    def fx_progress(self):
        return min(1,max(0,(time.monotonic()-self.fx['start'])/self.fx['duration'])) if self.fx and self.motion.get() else 1

    def draw(self):
        if self.scene=='maedn': self.draw_maedn(); return
        if self.scene!='table' or not self.state or not hasattr(self,'canvas') or not self.canvas.winfo_exists(): return
        c,u=self.canvas,self.state['game']; c.delete('all'); self.hits=[]
        width,height=max(100,c.winfo_width()),max(100,c.winfo_height())
        c.design=self.active_design()
        rounded(c,2,2,width-2,height-2,25,fill=self.BOARD,outline=self.BORDER,width=1)
        paint_scene(c,width,height,self.active_design(),self.paint())
        if not self.high_contrast.get(): decorate_table(c,width,height,self.active_design(),THEMES[self.active_design()])
        mode='EXTREME' if u.get('uno_mode')=='extreme' else 'CLASSIC'
        self.text(22,22,'UNO  ·  '+mode,13,self.GOLD,anchor='w')
        direction='→' if u['direction']==1 else '←'
        self.text(width-20,22,f'Round {u.get("round_number",1)}  ·  {direction}  ·  First to {u["target_score"]}',9,self.MUTED,anchor='e')
        shown=u['audit']['hand'] if u['audit'] else u['hand']; order=list(range(len(shown))) if u['audit'] else self.hand_order(u)
        pages=max(1,(len(shown)+6)//7); self.page=max(0,min(self.page,pages-1))
        self.prev_button.configure(state='normal' if self.page>0 and not u['done'] else 'disabled')
        self.next_button.configure(state='normal' if self.page+1<pages and not u['done'] else 'disabled')
        self.page_label.configure(text=f'{self.page+1} of {pages}' if pages>1 else f'{len(shown)} cards')
        self.sort_button.configure(text='Sorted by color ✓' if self.sorted_hand.get() else 'Cards as dealt',state='disabled' if u['audit'] or u['done'] else 'normal')
        hand_h=min(150,max(80,height*.34)); hand_w=min(hand_h*.67,(width-56)/7-8)
        hand_h=hand_w/.67; hand_y=height-hand_h-18
        pile_h=max(44,min(154,hand_y-125)); pile_w=pile_h*.67
        pile_y=max(50,(hand_y-pile_h-45)/2)
        deck_x,discard_x=width/2-pile_w-36,width/2+36
        actions=self.actions(); progress=self.fx_progress(); fx=self.fx if progress<1 else None
        self.opponent_centers={i:width*(i+.5)/self.state['player_count'] for i in range(self.state['player_count']) if i!=self.seat}
        if self.active_design()!='Larissa':
            c.create_oval(width/2-195,pile_y-18,width/2+195,pile_y+pile_h+25,fill=mix(self.BOARD,self.PANEL,.35),outline='')
        if ('draw',) in actions:
            rounded(c,deck_x-7,pile_y-7,deck_x+pile_w+7,pile_y+pile_h+8,16,fill=self.ACTIVE,outline=self.GREEN,width=2)
        for offset in (8,4,0): paint_uno_card(c,deck_x-offset*.35,pile_y+offset,pile_w,pile_h)
        top=tuple(u['top'])
        if fx and fx['kind']=='play' and fx.get('old') and progress<.8: top=tuple(fx['old']['top'])
        paint_uno_card(c,discard_x,pile_y,pile_w,pile_h,top)
        self.text(deck_x+pile_w/2,pile_y+pile_h+20,'HIT LAUNCHER' if u.get('uno_mode')=='extreme' else 'DRAW ONE',10,self.GOLD if ('draw',) in actions else self.MUTED)
        self.text(discard_x+pile_w/2,pile_y+pile_h+20,'MATCH THIS',10,self.MUTED)
        self.text(width/2,pile_y+pile_h*.44,'→',24,self.MUTED)
        if u.get('phase')=='draw_stack':
            amount=u.get('stack_penalty',0)
            pulse=math.sin(time.monotonic()*5)*2 if self.motion.get() else 0
            rounded(c,width/2-125,pile_y-31-pulse,width/2+125,pile_y+4-pulse,16,fill=self.ACTIVE,outline=self.GOLD,width=2)
            self.text(width/2,pile_y-14-pulse,f'+{amount} STACK  ·  STACK +2 OR DRAW',10,self.TEXT)
        color=CARD_COLORS.get(u['color'],self.GREEN)
        match=f'{u["color"]}  ·  {u["top"][1]}' if u['top'][0]!='Wild' else f'{u["color"]} is the color'
        pill_w=min(185,width*.30)
        rounded(c,width/2-pill_w/2,9,width/2+pill_w/2,38,14,fill=self.PANEL,outline='')
        c.create_oval(width/2-pill_w/2+12,18,width/2-pill_w/2+24,30,fill=color,outline='')
        self.text(width/2+9,24,match,10,self.TEXT)
        if ('draw',) in actions: self.hits.append((deck_x-8,pile_y-8,deck_x+pile_w+8,pile_y+pile_h+31,('draw',)))
        if u.get('uno_mode')=='extreme':
            cx=deck_x+pile_w/2
            pulse=math.sin(progress*math.pi*8)*4*(1-progress) if fx and fx['kind']=='launch' else 0
            rounded(c,deck_x-12,pile_y+pile_h-35,deck_x+pile_w+12,pile_y+pile_h-8,10,fill='#25283b',outline=self.GOLD,width=2)
            caption=('SAFE' if not u.get('launcher_burst') else '+'+str(u['launcher_burst'])) if u.get('launcher_serial') else '0 · 2 · 3 · 4 · 6'
            self.text(cx+pulse,pile_y+pile_h-22,caption,10,'#ffe177')
            if fx and fx['kind']=='launch':
                owner=u.get('launcher_owner')
                end_y=hand_y if owner==self.seat else -pile_h
                end_x=deck_x if owner==self.seat else self.opponent_centers.get(owner,width/2)
                for index in range(min(6,u.get('launcher_burst',0))):
                    t=max(0,min(1,(progress-index*.06)/.68))
                    xx=deck_x+(end_x-deck_x)*t+math.sin(index*1.5)*45*t
                    yy=pile_y+pile_h*.4+math.sin(t*math.pi)*-70+t*(end_y-pile_y)
                    paint_uno_card(c,xx,yy,pile_w*.55,pile_h*.55)
        rounded(c,12,hand_y-39,width-12,height-8,20,fill=self.PANEL,outline='')
        title='Revealed hand' if u['audit'] else 'Your cards'
        self.text(28,hand_y-20,title,11,self.TEXT,anchor='w')
        hint=('Review the matching color, then Continue.' if u['audit'] else 'UNO called ✓' if u['called'] else
              'Click a glowing card' if any(a[0]=='play' for a in actions) else 'Your cards are safe here')
        self.text(width-28,hand_y-20,hint,9,self.GOLD if u['called'] else self.MUTED,anchor='e')
        visible=order[self.page*7:(self.page+1)*7]; total=len(visible)*(hand_w+8)-8
        self.card_positions={}
        for n,i in enumerate(visible):
            card=shown[i]; plays=[a for a in actions if a[0]=='play' and a[1]==i] if not u['audit'] else []
            stacks=[a for a in actions if a[0]=='stack' and a[1]==i] if not u['audit'] else []
            hit=('wild',i) if plays and card[0]=='Wild' else plays[0] if plays else stacks[0] if stacks else None
            x=(width-total)/2+n*(hand_w+8)
            lift=self.hover_amount.get(hit,0)*16 if self.motion.get() else 14 if hit and hit==self.hover else 0
            y=hand_y-lift
            if fx and fx['kind']=='deal':
                t=max(0,min(1,(progress-n*.055)/.65)); y+=(1-(1-(1-t)**3))*height*.65
            self.card_positions[i]=(x,y,hand_w,hand_h)
            if plays or stacks: rounded(c,x-4,y-4,x+hand_w+4,y+hand_h+6,13,fill=self.ACTIVE,outline=self.GOLD if stacks else self.GREEN,width=2)
            paint_uno_card(c,x,y,hand_w,hand_h,tuple(card))
            if plays or stacks:
                c.create_oval(x+hand_w-19,y-6,x+hand_w+3,y+16,fill=self.GREEN,outline=self.PANEL,width=2)
                self.text(x+hand_w-8,y+5,'+2' if stacks else '✓',8,'white')
            if hit: self.hits.append((x-3,y-3,x+hand_w+3,y+hand_h+4,hit))
            if u['drawn_index']==i and u['phase']=='drawn' and not u['audit']:
                rounded(c,x-2,y+hand_h-23,x+hand_w+2,y+hand_h,8,fill=self.GREEN,outline='')
                self.text(x+hand_w/2,y+hand_h-12,'NEW CARD',8,'white')
        if fx and fx['kind'] in ('play','draw') and fx.get('move'):
            move=fx['move']; t=1-(1-progress)**3
            if move['kind'] in ('play','stack') and move.get('card'):
                sx=width/2-hand_w/2 if move['seat']==self.seat else self.opponent_centers[move['seat']]-hand_w/2
                sy=hand_y if move['seat']==self.seat else -hand_h
                paint_uno_card(c,sx+(discard_x-sx)*t,sy+(pile_y-sy)*t-math.sin(progress*math.pi)*35,
                               hand_w+(pile_w-hand_w)*t,hand_h+(pile_h-hand_h)*t,tuple(move['card']))
            else:
                ex=width/2-pile_w/2 if move['seat']==self.seat else self.opponent_centers[move['seat']]-pile_w/2
                ey=hand_y if move['seat']==self.seat else -pile_h
                paint_uno_card(c,deck_x+(ex-deck_x)*t,pile_y+(ey-pile_y)*t-math.sin(progress*math.pi)*20,pile_w,pile_h)
        if u['done']: self.draw_finish(width,height,False)
        opening=u['phase']=='opening_color' and u['turn']==self.seat and self.can_play()
        if self.wild is not None or opening: self.draw_color_picker(width,height,opening)

    def draw_color_picker(self,width,height,opening):
        self.hits=[]; c=self.canvas; size=min(480,width-32); box_h=min(308,height-24)
        x,y=(width-size)/2,(height-box_h)/2
        rounded(c,x+3,y+7,x+size+3,y+box_h+7,22,fill=mix(self.BG,self.BORDER,.72),outline='')
        rounded(c,x,y,x+size,y+box_h,22,fill=self.PANEL,outline=self.BORDER,width=2)
        self.text(width/2,y+32,'Pick the next color',21,self.TEXT)
        self.text(width/2,y+60,'Your choice changes the game.',10,self.MUTED)
        gap=12; bw=(size-52-gap)/2; bh=min(60,max(30,(box_h-148)/2)); top=y+72
        for i,color in enumerate(UNO_COLORS):
            xx=x+26+(i%2)*(bw+gap); yy=top+(i//2)*(bh+10)
            rounded(c,xx,yy,xx+bw,yy+bh,14,fill=CARD_COLORS[color],outline='')
            symbol={'Red':'♥','Yellow':'★','Green':'●','Blue':'◆'}[color]
            self.text(xx+bw/2,yy+bh/2,f'{symbol}  {color}',15,'#20263e' if color=='Yellow' else 'white')
            action=('color',color) if opening else ('play',self.wild,color)
            if action in self.actions(): self.hits.append((xx,yy,xx+bw,yy+bh,action))
        hand=self.state['game']['hand']; valid=self.wild is not None and 0<=self.wild<len(hand)
        bluff=valid and hand[self.wild][1]=='+4' and any(card[0]==self.state['game']['color'] for card in hand)
        self.text(width/2,y+box_h-54,'You have a matching color. A +4 could be challenged.' if bluff else 'Click a color to play your Wild.',9,self.ERROR if bluff else self.MUTED)
        if not opening:
            self.text(width/2,y+box_h-28,'Cancel  ·  Esc',11,self.GOLD)
            self.hits.append((width/2-100,y+box_h-49,width/2+100,y+box_h-8,('cancel',)))

    def draw_maedn(self):
        if self.scene!='maedn' or not self.state or not hasattr(self,'canvas') or not self.canvas.winfo_exists(): return
        c,g=self.canvas,self.state['game']; c.delete('all'); self.hits=[]
        width,height=max(100,c.winfo_width()),max(100,c.winfo_height())
        rounded(c,2,2,width-2,height-2,25,fill=self.BOARD,outline=self.BORDER,width=1)
        paint_scene(c,width,height,self.active_design(),self.paint())
        sides,length=g['board_sides'],g['track_length']; track,homes,bases,labels=board_layout(sides)
        extent=6.2 if sides==4 else 7.1
        scale=max(5,min((width-150)/(2*extent),(height-62)/(2*extent))); cx,cy=width/2,height/2-2
        r=scale*.34
        def xy(point): return cx+point[0]*scale,cy+point[1]*scale
        def point(seat,piece,pos):
            slot=g['slots'][seat]
            return bases[slot][piece] if pos==-1 else homes[slot][pos-length] if pos>=length else track[(slot*10+pos)%length]
        self.text(19,20,'THE RACE HOME',10,self.MUTED,anchor='w')
        self.text(width-19,20,'Your color: '+PAWN_NAMES[g['slots'][self.seat]],10,self.TEXT,anchor='e')
        # Soft colored home lanes and base pads visually connect each player's pawns.
        for slot in range(sides):
            if slot not in g['slots']: continue
            color=PAWN_COLORS[slot]; lane=[xy(p) for p in homes[slot]]
            c.create_line(*lane[0],*lane[-1],fill=mix(color,self.BOARD,.83),width=scale*.96,capstyle='round')
            coords=[xy(p) for p in bases[slot]]
            x1=min(p[0] for p in coords)-r*1.5; y1=min(p[1] for p in coords)-r*1.5
            x2=max(p[0] for p in coords)+r*1.5; y2=max(p[1] for p in coords)+r*1.5
            rounded(c,x1,y1,x2,y2,scale*.5,fill=mix(color,self.BOARD,.88),outline='')
        for i,p in enumerate(track):
            x,y=xy(p); xx,yy=xy(track[(i+1)%length])
            c.create_line(x,y,xx,yy,fill=mix(self.BOARD,self.BORDER,.52),width=max(1,scale*.12))
        for i,p in enumerate(track):
            x,y=xy(p); slot=i//10 if i%10==0 else None
            color=PAWN_COLORS[slot] if slot is not None and slot in g['slots'] else None
            c.create_oval(x-r,y-r+2,x+r,y+r+2,fill=mix(self.BOARD,self.BORDER,.5),outline='')
            c.create_oval(x-r,y-r,x+r,y+r,fill=mix(color,self.TILE,.15) if color else self.TILE,outline=self.BORDER,width=1)
            if color: self.text(x,y,'↑',max(8,scale*.31),'#20263e' if slot==2 else 'white')
        for slot in range(sides):
            color=PAWN_COLORS[slot] if slot in g['slots'] else '#c9c9c2'
            for i,p in enumerate(homes[slot]):
                x,y=xy(p); c.create_oval(x-r,y-r,x+r,y+r,fill=mix(color,'#ffffff',.86),outline=color,width=2)
                self.text(x,y,str(i+1),max(7,scale*.25),mix(color,'#20263e',.2))
            for p in bases[slot]:
                x,y=xy(p); c.create_oval(x-r,y-r,x+r,y+r,fill=mix(color,'#ffffff',.94),outline=mix(color,'#ffffff',.45),width=1)
            if slot in g['slots']:
                seat=g['slots'].index(slot); lx,ly=labels[slot]; x,y=xy((lx,ly))
                anchor=('e' if lx<0 else 'w') if abs(lx)>.1 else ('s' if ly<0 else 'n')
                self.text(x,y,'You' if seat==self.seat else self.short_name(seat,10),max(8,min(11,scale*.3)),self.TEXT,anchor=anchor)
        actions=self.actions(); progress=self.fx_progress(); fx=self.fx if progress<1 else None
        moving=None; oldpos=None
        if fx and fx['kind']=='move' and fx.get('old') and fx.get('move'):
            seat=fx['move']['seat']
            differences=[i for i,(a,b) in enumerate(zip(fx['old']['pieces'][seat],g['pieces'][seat])) if a!=b]
            if differences: moving=(seat,differences[0]); oldpos=fx['old']['pieces'][seat][differences[0]]
        if self.hover and self.hover[0]=='move' and self.hover in actions:
            piece=self.hover[1]; target=g['destinations'].get(str(piece))
            if target is not None:
                x,y=xy(point(self.seat,piece,g['pieces'][self.seat][piece])); xx,yy=xy(point(self.seat,piece,target))
                c.create_line(x,y,xx,yy,fill=self.GREEN,width=2,dash=(4,4),arrow='last')
                c.create_oval(xx-r*1.6,yy-r*1.6,xx+r*1.6,yy+r*1.6,outline=self.GREEN,width=3)
                self.text(xx,yy-r*2.3,'HERE',8,self.GREEN)
        for seat,pawns in enumerate(g['pieces']):
            slot=g['slots'][seat]
            for piece,pos in enumerate(pawns):
                x,y=xy(point(seat,piece,pos)); action=('move',piece)
                if moving==(seat,piece):
                    route=[point(seat,piece,oldpos)]+[point(seat,piece,p) for p in range(max(0,oldpos+1),pos+1)]
                    t=min(1,progress/.82)*(len(route)-1); step=min(len(route)-2,int(t)); part=t-step
                    if len(route)>1:
                        ax,ay=xy(route[max(0,step)]); bx,by=xy(route[max(0,step)+1])
                        smooth=part*part*(3-2*part); x=ax+(bx-ax)*smooth; y=ay+(by-ay)*smooth-math.sin(part*math.pi)*scale*.38
                capture=g.get('last_capture')
                if fx and fx['kind']=='move' and fx.get('old') and capture=={'seat':seat,'piece':piece}:
                    before=fx['old']['pieces'][seat][piece]
                    ax,ay=xy(point(seat,piece,before)); t=max(0,min(1,(progress-.68)/.32)); ease=1-(1-t)**3
                    x=ax+(x-ax)*ease; y=ay+(y-ay)*ease-math.sin(t*math.pi)*scale
                playable=seat==self.seat and action in actions
                size=r*.98
                if fx and fx['kind']=='deal':
                    t=max(0,min(1,(progress-(seat*4+piece)*.01)/.65))
                    pop=1+2.2*(t-1)**3+1.2*(t-1)**2
                    size*=max(.1,pop)
                pawn(c,x,y,size,PAWN_COLORS[slot],piece+1,ring=playable)
                if playable: self.hits.append((x-r*1.7,y-r*1.7,x+r*1.7,y+r*1.7,action))
        size=scale*(1.15 if sides==4 else 2.18); value=g['die']; dx,dy=cx,cy; tilt=0
        if fx and fx['kind']=='roll':
            value=(int(progress*22)%6)+1 if progress<.85 else g['die']
            dx+=math.sin(progress*math.pi*12)*size*.055*(1-progress)
            dy-=abs(math.sin(progress*math.pi*6))*size*.13*(1-progress)
            tilt=math.sin(progress*math.pi*10)*.18*(1-progress)
        die(c,dx,dy,size,value,tilt=tilt)
        if fx and fx['kind']=='roll': self.draw_turn_badge(value)
        if ('roll',) in actions:
            self.hits.append((cx-size/2-5,cy-size/2-5,cx+size/2+5,cy+size/2+5,('roll',)))
        caption=(f'{self.short_name(g["die_owner"],14)} rolled {g["die"]}' if g['die_owner'] is not None else 'Roll the die, then choose a pawn')
        self.text(width/2,height-13,caption,9,self.MUTED)
        if g['done']: self.draw_finish(width,height,True)

    def draw_finish(self,width,height,board):
        c,g=self.canvas,self.state['game']; self.hits=[]
        box_w=min(width-36,550); box_h=min(height-22,356); x,y=(width-box_w)/2,(height-box_h)/2
        rounded(c,x+3,y+7,x+box_w+3,y+box_h+7,24,fill=mix(self.BORDER,'#171c38',.2),outline='')
        rounded(c,x,y,x+box_w,y+box_h,24,fill=self.PANEL,outline=self.BORDER,width=2)
        self.text(width/2,y+33,'★  '+('You did it!' if g['winner']==self.seat else self.short_name(g['winner'],16)+' wins!')+'  ★',22,self.GOLD)
        subtitle='All four pawns made it home.' if board else f'+{g["round_points"]} points · A round worth celebrating.'
        self.text(width/2,y+65,subtitle,10,self.MUTED)
        seats=g['rankings'] if board else sorted(range(self.state['player_count']),key=lambda i:-g['points'][i])
        step=min(29,(box_h-126)/max(1,len(seats)))
        for rank,seat in enumerate(seats):
            yy=y+95+rank*step
            self.text(x+27,yy,f'{rank+1}.  '+('You' if seat==self.seat else self.short_name(seat,20 if board else 12)),12,self.TEXT,anchor='w')
            detail='Winner' if board and rank==0 else 'Finished' if board and rank<len(seats)-1 else 'Last place' if board else f'{g["points"][seat]} pts'
            if not board and g.get('round_breakdown') is not None:
                contribution=f'+{g["round_points"]} won' if seat==g['winner'] else f'{g["round_breakdown"][seat]} left in hand'
                detail=contribution+'  ·  '+detail
            self.text(x+box_w-27,yy,detail,10,self.GOLD if seat==g['winner'] else self.MUTED,anchor='e')
        next_game=self.state.get('night_queue',[])
        next_label=('Next: '+('UNO' if next_game[0]=='uno' else 'Mensch')+' · everyone chooses Ready') if next_game else 'Ready for another? Use the big button below.'
        stars=self.state.get('night_scores',[0]*self.state['player_count'])[self.seat]
        self.text(width/2,y+box_h-24,f'★ {stars} night wins · '+next_label,9,self.MUTED)
        if self.fx and self.fx['kind']=='win' and self.motion.get():
            t=self.fx_progress()
            for i in range(54):
                xx=(i*127.13+math.sin(t*8+i)*22)%width; yy=(-80+(i*37)%150+t*(height+150))
                if 0<yy<height:
                    color=('#e7bd32','#df3e55','#514bcb','#25955b','#287ec3')[i%5]
                    angle=t*6+i; dx,dy=math.cos(angle)*5,math.sin(angle)*5
                    c.create_line(xx-dx,yy-dy,xx+dx,yy+dy,fill=color,width=4)
