"""Classic 108-card UNO for 2–6 players; first to 500 points."""
import random
EMPTY = -1

UNO_COLORS = ('Red', 'Yellow', 'Green', 'Blue')
STARTING_HANDS = (5, 7, 10)
TARGET_SCORES = (100, 250, 500, 1000)
UNO_PAINT = {'Red': '#ed2734', 'Yellow': '#b68d12', 'Green': '#17a767', 'Blue': '#168de2', 'Wild': '#161b26'}


class Engine:
    def __init__(self):
        self.turn = 0
        self.done = False
        self.winner = None
        self.highlight = []
        self.note = ""
        self.last = None

    def finish(self, winner):
        self.done = True
        self.winner = winner

    def finish_scores(self, scores):
        self.finish(EMPTY if scores[0] == scores[1] else int(scores[1] > scores[0]))


class Uno(Engine):
    """Classic UNO plus an optional server-validated stackable Draw Two mode."""
    MODES = ('classic', 'extreme')
    def __init__(self, dealer=None, scores=None, player_count=2, starting_cards=7, target_score=500,
                 uno_mode='classic'):
        super().__init__()
        if type(player_count) is not int or not 2 <= player_count <= 6:
            raise ValueError('Choose between 2 and 6 players.')
        if dealer is not None and (type(dealer) is not int or not 0 <= dealer < player_count):
            raise ValueError('Invalid dealer.')
        if scores is not None and len(scores) != player_count:
            raise ValueError('Each player needs a score.')
        self.player_count = player_count
        if type(starting_cards) is not int or starting_cards not in STARTING_HANDS:
            raise ValueError('Choose 5, 7 or 10 starting cards.')
        if type(target_score) is not int or target_score not in TARGET_SCORES:
            raise ValueError('Choose a target of 100, 250, 500 or 1000 points.')
        if uno_mode not in self.MODES:
            raise ValueError('Choose Classic or Extreme UNO.')
        self.starting_cards, self.target_score = starting_cards, target_score
        self.uno_mode = uno_mode
        self.stack_penalty = 0
        self.launcher_serial=0
        self.launcher_burst=0
        self.launcher_owner=None
        self.direction = 1
        self.deck = [(c, '0') for c in UNO_COLORS]
        self.deck += [(c, v) for c in UNO_COLORS for v in tuple(map(str, range(1, 10)))+('Skip', 'Reverse', '+2') for _ in range(2)]
        self.deck += [('Wild', v) for v in ('Wild', '+4') for _ in range(4)]
        self.dealer_draws = None
        if dealer is None:
            # The opening dealer is chosen by drawing the highest number.
            # Action cards count as zero; tied players draw again.
            contenders = list(range(player_count))
            self.dealer_draws = [None] * player_count
            while len(contenders) > 1:
                draws = random.sample(self.deck, len(contenders))
                for seat, card in zip(contenders, draws): self.dealer_draws[seat] = card
                high = max(int(card[1]) if card[1].isdigit() else 0 for card in draws)
                contenders = [seat for seat, card in zip(contenders, draws)
                              if (int(card[1]) if card[1].isdigit() else 0) == high]
            dealer = contenders[0]
        self.dealer = dealer
        random.shuffle(self.deck)
        self.hands = [[] for _ in range(player_count)]
        for _ in range(starting_cards):
            for offset in range(1, player_count+1):
                self.hands[(dealer+offset) % player_count].append(self.deck.pop())
        self.turn = self.next_player(self.dealer)
        self.match_points = list(scores if scores is not None else [0] * player_count)
        self.round_points = 0
        self.round_breakdown = None
        self.phase = 'ready'
        self.drawn_index = None
        self.announced = False
        self.uno_called = set()
        self.missed_uno = None
        self.challenge = None
        self.audit = None
        self.continue_turn = None
        while True:
            card = self.deck.pop()
            if card[1] != '+4': break
            self.deck.insert(0, card)
            random.shuffle(self.deck)
        self.discard = [card]
        self.color = card[0]
        self.note = f'P{self.dealer+1} dealt. Match the color, number or symbol.'
        if card[1] == 'Wild':
            self.phase = 'opening_color'
            self.note = f'Opening Wild: P{self.turn+1} chooses the starting color and plays first.'
        elif card[1] == 'Reverse':
            self.direction = -1
            self.turn = self.dealer
            self.note = f'Opening Reverse: P{self.turn+1} starts; play runs counterclockwise.'
        elif card[1] in ('Skip', '+2'):
            if card[1] == '+2': self.take(self.turn, 2)
            self.turn = self.next_player(self.turn)
            self.note = f'Opening {card[1]}: P{self.turn+1} starts.'

    def next_player(self, player, steps=1):
        return (player + self.direction * steps) % self.player_count

    def take(self, player, count):
        taken = 0
        for _ in range(count):
            if not self.deck and len(self.discard) > 1:
                self.deck, self.discard = self.discard[:-1], self.discard[-1:]
                random.shuffle(self.deck)
            if self.deck:
                self.hands[player].append(self.deck.pop())
                taken += 1
        if taken:
            self.uno_called.discard(player)
            if self.missed_uno == player: self.missed_uno = None
            if player == self.turn: self.announced = False
        return taken

    @staticmethod
    def card_points(card):
        color, value = card
        return int(value) if value.isdigit() else 50 if color == 'Wild' else 20

    def end_round(self, player):
        if self.done: return
        self.stack_penalty = 0
        self.round_breakdown = [sum(self.card_points(c) for c in hand) if seat != player else 0
                                for seat, hand in enumerate(self.hands)]
        self.round_points = sum(self.round_breakdown)
        self.match_points[player] += self.round_points
        self.finish(player)
        self.phase, self.drawn_index, self.missed_uno = 'finished', None, None
        self.announced = False
        self.challenge = self.audit = self.continue_turn = None
        self.note = f'P{player+1} wins the round: +{self.round_points} points. '
        self.note += (f'First to {self.target_score} wins the match.' if self.match_points[player] < self.target_score
                      else f'P{player+1} wins the {self.target_score}-point match!')

    def matches(self, card):
        return card[0] == 'Wild' or card[0] == self.color or card[1] == self.discard[-1][1]

    def legal(self):
        if self.done: return []
        if self.phase == 'opening_color': return [('color', c) for c in UNO_COLORS]
        if self.phase == 'draw_stack':
            actions = [('take_penalty',)]
            actions += [('stack', i) for i, card in enumerate(self.hands[self.turn]) if card[1] == '+2']
            if len(self.hands[self.turn]) == 2 and not self.announced: actions.append(('uno',))
            if self.missed_uno is not None and self.missed_uno != self.turn: actions.append(('catch',))
            return actions
        if self.phase == 'challenge':
            return [('accept',), ('challenge',)] + ([('catch',)] if self.missed_uno is not None and self.missed_uno != self.turn else [])
        if self.phase == 'audit': return [('continue',)]
        actions = [('pass',)] if self.phase == 'drawn' else [('draw',)]
        if self.missed_uno is not None and self.missed_uno != self.turn: actions.append(('catch',))
        if len(self.hands[self.turn]) == 2 and not self.announced: actions.append(('uno',))
        indices = [self.drawn_index] if self.phase == 'drawn' else range(len(self.hands[self.turn]))
        for i in indices:
            color, value = self.hands[self.turn][i]
            if self.matches((color, value)):
                actions += [('play', i, c) for c in UNO_COLORS] if color == 'Wild' else [('play', i, color)]
        return actions

    def actions_for(self, seat):
        if self.done or type(seat) is not int or not 0 <= seat < self.player_count: return []
        actions = list(self.legal()) if seat == self.turn else []
        if self.missed_uno is not None:
            extra = ('uno_late',) if seat == self.missed_uno else ('catch',)
            if extra not in actions: actions.append(extra)
        return actions

    def perform(self, seat, action):
        """One authoritative entry point, including out-of-turn UNO calls/catches."""
        if action not in self.actions_for(seat): return False
        if action[0] == 'catch':
            return self.catch_uno()
        if action[0] == 'uno_late':
            self.uno_called.add(seat)
            self.missed_uno = None
            self.note = f'P{seat+1} called UNO before being caught.'
            return True
        return self.play(action)

    def catch_uno(self):
        if self.missed_uno is None: return False
        caught = self.missed_uno
        taken = self.take(caught, 2)
        self.missed_uno = None
        self.note = f'P{caught+1} forgot UNO and draws {taken} cards.'
        return True

    def play(self, action):
        if action not in self.legal(): return False
        p, kind = self.turn, action[0]
        if kind == 'uno':
            self.announced = True
            self.note = f'P{p+1} called UNO before playing their next-to-last card.'
            return True
        if kind == 'catch':
            return self.catch_uno()
        if kind == 'color':
            self.color, self.phase = action[1], 'ready'
            self.note = f'Opening color: {self.color}.'
            return True
        if kind == 'continue':
            self.turn, self.phase = self.continue_turn, 'ready'
            self.audit = self.continue_turn = None
            self.note = f'Challenge resolved. Active color: {self.color}.'
            return True
        if kind == 'take_penalty':
            amount = self.stack_penalty
            drawn = self.take(p, amount)
            self.stack_penalty = 0
            self.phase, self.drawn_index = 'ready', None
            self.turn = self.next_player(p)
            self.note = f'P{p+1} drew {drawn} stacked cards. Turn passes to P{self.turn+1}.'
            return True
        if kind in ('accept', 'challenge'):
            offender, guilty, evidence, old_color = self.challenge
            self.missed_uno = None
            if kind == 'accept':
                self.take(p, 4)
                self.turn, self.phase = self.next_player(p), 'ready'
                self.note = f'P{p+1} draws four and misses their turn.'
                if not self.hands[offender]: self.end_round(offender)
            else:
                self.take(offender if guilty else p, 4 if guilty else 6)
                self.audit = (offender, evidence, old_color, guilty)
                self.continue_turn = p if guilty else self.next_player(p)
                self.phase = 'audit'
                self.note = (f'Challenge successful: P{offender+1} draws four; P{p+1} keeps the turn.' if guilty
                             else f'Challenge failed: P{p+1} draws six and misses the turn.')
                if not self.hands[offender]: self.end_round(offender)
            self.challenge = None
            return True
        # Starting a normal move closes the opponent's missed-UNO catch window.
        self.missed_uno = None
        if kind == 'draw':
            self.announced = False
            if self.uno_mode=='extreme':
                # The host resolves every burst before any decorative animation.
                count=random.choices((0,2,3,4,6),weights=(35,30,20,10,5),k=1)[0]
                self.launcher_burst=self.take(p,count)
                self.launcher_owner=p; self.launcher_serial+=1
                self.turn=self.next_player(p); self.phase='ready'; self.drawn_index=None
                self.note=(f'P{p+1} hit the launcher: '+(f'{self.launcher_burst} cards!' if self.launcher_burst else 'click… safe this time!')+
                           f' P{self.turn+1} plays next.')
                return True
            if self.take(p, 1):
                self.drawn_index = len(self.hands[p])-1
                if self.matches(self.hands[p][-1]):
                    self.phase = 'drawn'
                    self.note = f'P{p+1} drew a playable card and may play it or keep it.'
                    return True
            self.phase, self.drawn_index = 'ready', None
            self.turn = self.next_player(p)
            self.note = f'P{p+1} drew no playable card. Turn passes to P{self.turn+1}.'
            return True
        if kind == 'pass':
            self.phase, self.drawn_index = 'ready', None
            self.turn, self.announced = self.next_player(p), False
            self.note = f'P{p+1} kept the drawn card. Turn passes to P{self.turn+1}.'
            return True
        old_color = self.color
        if kind == 'stack':
            # Any previous missed-UNO window closes when the next player acts.
            self.missed_uno = None
            card = self.hands[p].pop(action[1])
            self.discard.append(card)
            old_penalty = self.stack_penalty
            self.stack_penalty += 2
            self.color = card[0]
            if len(self.hands[p]) == 1 and not self.announced: self.missed_uno = p
            called = self.announced
            self.uno_called.discard(p)
            if len(self.hands[p]) == 1 and called: self.uno_called.add(p)
            self.announced = False
            self.turn = self.next_player(p)
            self.phase = 'draw_stack'
            self.note = f'P{p+1} stacked +2 on +{old_penalty}. P{self.turn+1} must stack +2 or draw {self.stack_penalty}.'
            if not self.hands[p]:
                self.take(self.turn, self.stack_penalty)
                self.end_round(p)
            return True
        card = self.hands[p].pop(action[1])
        self.discard.append(card)
        self.color, self.phase, self.drawn_index = action[2], 'ready', None
        value = card[1]
        if len(self.hands[p]) == 1 and not self.announced: self.missed_uno = p
        called = self.announced
        self.uno_called.discard(p)
        if len(self.hands[p]) == 1 and called: self.uno_called.add(p)
        self.announced = False
        self.note = f'P{p+1} played {card[0]} {value}. Active color: {self.color}.'
        if len(self.hands[p]) == 1:
            self.note += ' UNO!' if called else ' UNO was not called: another player may catch it.'
        if value == '+4':
            if not self.hands[p]:
                self.take(self.next_player(p), 4)
                self.end_round(p)
                return True
            evidence = list(self.hands[p])
            guilty = any(c == old_color for c, v in evidence)
            self.challenge = (p, guilty, evidence, old_color)
            self.turn, self.phase = self.next_player(p), 'challenge'
            self.note += ' Accept four cards or challenge the play.'
        else:
            if value == 'Reverse':
                self.direction *= -1
                self.turn = p if self.player_count == 2 else self.next_player(p)
            elif value in ('Skip', '+2'):
                if value == '+2' and self.uno_mode == 'extreme' and self.hands[p]:
                    self.stack_penalty = 2
                    self.turn, self.phase = self.next_player(p), 'draw_stack'
                    self.note += f' P{self.turn+1} can stack another +2 or draw 2.'
                else:
                    if value == '+2': self.take(self.next_player(p), 2)
                    self.turn = self.next_player(p, 2)
            else:
                self.turn = self.next_player(p)
            if not self.hands[p]: self.end_round(p)
        return True

    def bot(self):
        actions = self.legal()
        if not actions: return None
        if ('catch',) in actions: return ('catch',)
        if ('uno',) in actions: return ('uno',)
        if self.phase == 'opening_color':
            return max(actions, key=lambda a: sum(c == a[1] for c, v in self.hands[self.turn]))
        if self.phase == 'challenge':
            # Uses public information, never the stored hidden evidence.
            return ('challenge',) if random.random() < .18 else ('accept',)
        if self.phase == 'audit': return ('continue',)
        hand = self.hands[self.turn]
        options = [a for a in actions if a[0] == 'play' and not
                   (hand[a[1]][1] == '+4' and any(c == self.color for c, v in hand))]
        if not options: return ('pass',) if self.phase == 'drawn' else ('draw',)
        return max(options, key=lambda a: (hand[a[1]][1] in ('+2', 'Skip', 'Reverse'),
                   sum(c == a[2] for c, v in hand), hand[a[1]][0] != 'Wild', self.card_points(hand[a[1]])))


