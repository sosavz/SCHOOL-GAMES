"""Profiles, recovery, theme previews and game-night tools around the shared UI."""
from pathlib import Path
import sys
import tkinter as tk
from tkinter import messagebox
from playroom_data import AVATARS, BACKS, achievements, cosmetics, load_profile, read_json, record_result
from room_features import load_room
from uno_net import DEFAULT_PORT, GAMES, RoomClient, RoomServer
from uno_themes import THEMES
from uno_art import paint_uno_card
from playroom_widgets import SoftButton, pawn
from update_core import atomic_json
from cosmetics_art import paint_avatar


class PlayroomExtras:
    def __init__(self):
        self.data_root=Path(getattr(sys.modules[type(self).__module__],'ROOT',Path(__file__).resolve().parent))
        self.profile=load_profile(self.data_root)
        data=read_json(self.data_root/'playroom_presets.json',{})
        self.preset_data=data if isinstance(data,dict) else {}
        self.rule_presets=self.preset_data.get('presets',{})
        if not isinstance(self.rule_presets,dict): self.rule_presets={}
        self.rule_presets={name:rules for name,rules in list(self.rule_presets.items())[:32]
                           if isinstance(name,str) and 0<len(name)<=32 and name.isprintable() and isinstance(rules,dict)}
        self.planned_queue=[kind for kind in self.preset_data.get('queue',[]) if isinstance(kind,str) and kind in GAMES][:12] if isinstance(self.preset_data.get('queue',[]),list) else []
        super().__init__()

    def build_header(self):
        super().build_header()
        self.button(self.header,'Player',self.show_profile,secondary=True).pack(side='right',padx=(5,0))
        self.button(self.header,'Game night',self.show_night,secondary=True).pack(side='right',padx=(5,0))
        for child in self.header.winfo_children():
            if isinstance(child,SoftButton): child.configure(font=('Segoe UI',9,'bold'),padx=10,pady=10)
        self.connection_label.configure(width=24,font=('Segoe UI',9))

    def show_home(self):
        super().show_home()
        if (self.data_root/'playroom_host_save.json').is_file():
            self.button(self.home_error.master,'Restore host table',self.restore_host,secondary=True).pack(side='right',padx=5)

    def host_room(self):
        super().host_room()
        if self.server:
            with self.server.lock:
                self.server.night_queue=list(self.planned_queue)
                self.server.revision+=1; self.server._broadcast()

    def restore_host(self):
        if self.client: return
        try:
            saved=load_room(self.data_root/'playroom_host_save.json')
            self.server=RoomServer(DEFAULT_PORT,save_path=self.data_root/'playroom_host_save.json',saved_room=saved)
            name=self.name.get().strip() or saved['names'][0]
            self.name.set(name)
            self.client=RoomClient('127.0.0.1',self.server.port,self.server.code,name,
                                   host_key=self.server.host_key,profile=self.profile)
            self.practice_mode=self.server.practice
        except (ValueError,OSError,TypeError,KeyError) as exc:
            if self.server: self.server.close(); self.server=None
            self.error_text=str(exc); self.home_error.configure(text=self.error_text); return
        self.begin_connection()

    def update_view(self):
        super().update_view()
        if not self.state: return
        if record_result(self.profile,self.state.get('round_result'),self.seat):
            try: atomic_json(self.data_root/'playroom_profile.json',self.profile)
            except OSError: self.error_text='Player statistics could not be saved on this PC.'
        self.update_connection_health()

    def update_connection_health(self):
        if not getattr(self,'client',None) or not getattr(self,'state',None): return
        ping=getattr(self.client,'latency_ms',None)
        status='Measuring ping…' if ping is None else f'{ping} ms · '+('Good' if ping<150 else 'Fair' if ping<400 else 'Slow')
        if not self.linked(): status=f'Reconnecting · attempt {getattr(self.client,"reconnect_attempt",1)}'
        if self.server and self.state.get('saved_at'): status+=' · Saved'
        self.connection_label.configure(text=status)

    def draw(self):
        if hasattr(self,'canvas'): self.canvas.card_back_style=self.profile['card_back']
        super().draw()

    def send_action(self,action):
        if getattr(self,'fx',None): self.fx=None
        return super().send_action(action)

    def update_room(self):
        super().update_room()
        profiles=self.state.get('profiles',[])
        for seat,canvas in enumerate(self.seat_avatars):
            profile=profiles[seat] if seat<len(profiles) else cosmetics()
            canvas.delete('all')
            paint_avatar(canvas,15,14,13,profile['avatar'],self.paint())
            if self.state['ready'][seat]: canvas.create_text(25,26,text='✓',fill=self.GOLD,font=('Segoe UI',10,'bold'))
        if self.state.get('night_queue'):
            self.room_settings_label.configure(text=self.room_settings_label.cget('text')+'\nUp next: '+' → '.join(GAMES[kind] for kind in self.state['night_queue'][:3]))
        if self.state.get('save_error') and self.seat==0: self.room_status.configure(text=self.state['save_error'],fg=self.ERROR)

    def dialog(self,title,width=700,height=700,close_button=True):
        window=tk.Toplevel(self); window.title(title); window.configure(bg=self.BG)
        window.geometry(f'{width}x{min(height,max(420,self.winfo_screenheight()-100))}')
        window.transient(self); window.grab_set(); window.bind('<Escape>',lambda e:window.destroy())
        footer=tk.Frame(window,bg=self.BG,padx=20,pady=12); footer.pack(side='bottom',fill='x')
        canvas=tk.Canvas(window,bg=self.BG,highlightthickness=0)
        scroll=tk.Scrollbar(window,command=canvas.yview); scroll.pack(side='right',fill='y')
        canvas.pack(fill='both',expand=True); canvas.configure(yscrollcommand=scroll.set)
        body=tk.Frame(canvas,bg=self.BG,padx=22,pady=18); item=canvas.create_window(0,0,window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        canvas.bind('<MouseWheel>',lambda e:canvas.yview_scroll(-int(e.delta/120),'units'))
        if close_button: self.button(footer,'Done',window.destroy).pack(side='right')
        return window,body,footer

    def show_profile(self):
        window,body,footer=self.dialog('Your player · Playroom',660,730)
        self.label(body,'Your player.',25,self.TEXT,True).pack(anchor='w')
        self.label(body,'Cosmetics change your look. Statistics stay on this PC.',10,self.MUTED).pack(anchor='w',pady=(3,14))
        avatar=tk.StringVar(window,self.profile['avatar']); back=tk.StringVar(window,self.profile['card_back'])
        row=tk.Frame(body,bg=self.BG); row.pack(fill='x',pady=6)
        for index,(name,symbol) in enumerate(AVATARS.items()):
            self.button(row,name,lambda value=name:avatar.set(value),secondary=True).grid(row=index//3,column=index%3,sticky='ew',padx=3,pady=3)
        for index in range(3): row.columnconfigure(index,weight=1)
        controls=tk.Frame(body,bg=self.BG); controls.pack(fill='x',pady=10)
        self.label(controls,'Card back',12,self.TEXT,True).pack(side='left')
        tk.OptionMenu(controls,back,*BACKS).pack(side='right')
        preview=tk.Canvas(body,height=155,bg=self.PANEL,highlightthickness=0); preview.pack(fill='x')
        def redraw(*_):
            preview.delete('all'); preview.design=self.active_design(); preview.card_back_style=back.get()
            paint_avatar(preview,65,70,38,avatar.get(),self.paint())
            paint_uno_card(preview,140,12,80,120)
            preview.create_text(260,70,text=back.get(),anchor='w',font=('Segoe UI',15,'bold'),fill=self.TEXT)
        avatar.trace_add('write',redraw); back.trace_add('write',redraw); redraw()
        self.label(body,'YOUR GAME NIGHT RECORD',11,self.GOLD,True).pack(anchor='w',pady=(20,6))
        for kind,name in GAMES.items():
            stats=self.profile['stats'][kind]
            self.label(body,f'{name}: {stats["wins"]} wins / {stats["played"]} friend rounds · {stats["practice"]} practice rounds',11,self.TEXT,wraplength=570,justify='left').pack(anchor='w',pady=5)
        self.label(body,f'Current winning streak: {self.profile["streak"]} · Best: {self.profile["best_streak"]}',11,self.TEXT).pack(anchor='w',pady=8)
        earned=achievements(self.profile)
        self.label(body,'★ '+('\n★ '.join(earned) if earned else 'Your first victory earns your first badge.'),11,self.GOLD,wraplength=570,justify='left').pack(anchor='w',pady=6)
        def save():
            self.profile.update(cosmetics({'avatar':avatar.get(),'card_back':back.get()}))
            try: atomic_json(self.data_root/'playroom_profile.json',self.profile)
            except OSError as exc: messagebox.showerror('Player',str(exc),parent=window); return
            if self.client:
                self.client.profile=cosmetics(self.profile)
                self.client.send({'type':'profile','profile':cosmetics(self.profile)})
            window.destroy()
            if self.state: self.update_view()
        self.button(footer,'Save player',save,large=True).pack(side='left')

    def current_rules(self):
        if self.state:
            return dict(self.state['settings'],**self.state['board_settings'],game_kind=self.state['game_kind'],
                        player_count=self.state['player_count'],theme=self.state['theme'],
                        turn_timer=self.state.get('turn_timer',0),round_limit=self.state.get('round_limit',0),
                        bot_count=len(self.state.get('bot_seats',[])),bot_difficulty=self.state.get('bot_difficulty','normal'))
        return {key:getattr(self,key).get() for key in ('player_count','starting_cards','target_score','uno_mode','game_kind',
                'three_rolls','home_jumping','turn_timer','round_limit','bot_count','bot_difficulty')} | {'theme':self.design.get()}

    def store_presets(self):
        atomic_json(self.data_root/'playroom_presets.json',{'presets':self.rule_presets,'queue':self.planned_queue})

    def apply_rule_preset(self,rules):
        required=set(self.current_rules())
        if not isinstance(rules,dict) or set(rules)!=required: raise ValueError('This preset is incomplete.')
        RoomServer.validate_settings(rules['starting_cards'],rules['target_score'],rules['uno_mode'])
        RoomServer.validate_game(rules['game_kind'],rules['three_rolls'],rules['home_jumping'])
        if type(rules['player_count']) is not int or not 2<=rules['player_count']<=6 or rules['theme'] not in THEMES: raise ValueError('Invalid preset.')
        if rules['turn_timer'] not in (0,30,45,60) or rules['round_limit'] not in (0,3,5,10): raise ValueError('Invalid preset timer.')
        if type(rules['bot_count']) is not int or not 0<=rules['bot_count']<rules['player_count'] or rules['bot_difficulty'] not in ('easy','normal','hard'): raise ValueError('Invalid preset bots.')
        if self.state: return self.send_command(dict(type='settings',**rules))
        for key,value in rules.items():
            if key=='theme': continue
            getattr(self,key).set(value)
        self.apply_design(rules['theme']); self.save_preferences()
        return True

    def show_night(self):
        window,body,footer=self.dialog('Game night · Playroom',740,760)
        self.label(body,'Your game night.',25,self.TEXT,True).pack(anchor='w')
        self.label(body,'One star for each round won, across both games.',11,self.MUTED).pack(anchor='w',pady=(4,10))
        if self.state:
            for seat in sorted(range(self.state['player_count']),key=lambda i:-self.state.get('night_scores',[0]*self.state['player_count'])[i]):
                score=self.state.get('night_scores',[0]*self.state['player_count'])[seat]
                self.label(body,f'★ {score}   {self.state["names"][seat]}',12,self.TEXT,True).pack(anchor='w',pady=2)
            ping=getattr(self.client,'latency_ms',None)
            self.label(body,f'Connection: {self.client.host}:{self.client.port} · '+('Measuring ping' if ping is None else f'{ping} ms')+
                       ('\nLocal host save: '+str(self.state.get('saved_at') or 'not saved yet') if self.server else ''),10,self.MUTED).pack(anchor='w',pady=(9,10))
        owner=not self.state or self.seat==0
        queue=list(self.state.get('night_queue',[])) if self.state else list(self.planned_queue)
        self.label(body,'UP NEXT · AFTER THE CURRENT ROUND',10,self.GOLD,True).pack(anchor='w',pady=(12,6))
        playlist=tk.Listbox(body,height=5,font=('Segoe UI',12),bg=self.PANEL,fg=self.TEXT,selectbackground=self.GREEN,selectforeground='white',exportselection=False)
        playlist.pack(fill='x')
        def refresh():
            playlist.delete(0,'end')
            for index,kind in enumerate(queue): playlist.insert('end',f'{index+1}.  {GAMES[kind]}')
        refresh()
        feedback=self.label(body,'Everyone must choose Ready before the next game starts.',10,self.MUTED,wraplength=650,justify='left')
        feedback.pack(anchor='w',pady=5)
        if not owner: return
        row=tk.Frame(body,bg=self.BG); row.pack(fill='x',pady=6)
        def add(kind):
            if len(queue)<12: queue.append(kind); refresh()
        for kind,name in GAMES.items(): self.button(row,'+ '+name,lambda value=kind:add(value),secondary=True).pack(side='left',padx=(0,5))
        def remove():
            selected=playlist.curselection()
            if selected: queue.pop(selected[0]); refresh()
        self.button(row,'Remove',remove,secondary=True).pack(side='right')
        row=tk.Frame(body,bg=self.BG); row.pack(fill='x',pady=4)
        def move(offset):
            selected=playlist.curselection()
            if selected and 0<=selected[0]+offset<len(queue):
                index=selected[0]; queue[index],queue[index+offset]=queue[index+offset],queue[index]
                refresh(); playlist.selection_set(index+offset)
        self.button(row,'Move up',lambda:move(-1),secondary=True).pack(side='left')
        self.button(row,'Move down',lambda:move(1),secondary=True).pack(side='left',padx=5)
        def schedule():
            if self.state:
                if not self.send_command({'type':'night','queue':queue,'revision':self.state['revision']}): return
            else:
                self.planned_queue=list(queue)
                try: self.store_presets()
                except OSError as exc: feedback.configure(text=str(exc)); return
            feedback.configure(text='Playlist saved. The current game stays first; queued games follow it.')
        self.button(row,'Save playlist',schedule).pack(side='right')
        self.label(body,'FAVORITE RULE PRESETS',10,self.GOLD,True).pack(anchor='w',pady=(17,7))
        selection=tk.StringVar(window,next(iter(self.rule_presets),'Choose a saved preset'))
        row=tk.Frame(body,bg=self.BG); row.pack(fill='x')
        options=tk.OptionMenu(row,selection,*(list(self.rule_presets) or ['Choose a saved preset'])); options.pack(side='left',fill='x',expand=True)
        def load():
            try:
                if selection.get() not in self.rule_presets: raise ValueError('Save a preset first.')
                if self.apply_rule_preset(self.rule_presets[selection.get()]): window.destroy()
            except (ValueError,TypeError,KeyError) as exc: feedback.configure(text=str(exc))
        load_button=self.button(row,'Load',load,secondary=True); load_button.pack(side='right')
        running=bool(self.state and self.state['game'] is not None)
        if running: load_button.configure(state='disabled')
        preset_name=tk.StringVar(window)
        row=tk.Frame(body,bg=self.BG); row.pack(fill='x',pady=7)
        tk.Entry(row,textvariable=preset_name,font=('Segoe UI',12),bg=self.ENTRY,fg=self.TEXT).pack(side='left',fill='x',expand=True,ipady=8)
        def save():
            name=''.join(c for c in preset_name.get() if c.isprintable()).strip()[:32]
            if not name: feedback.configure(text='Give your preset a name.'); return
            if name not in self.rule_presets and len(self.rule_presets)>=32:
                feedback.configure(text='You have 32 presets. Reuse an existing name to replace one.'); return
            self.rule_presets[name]=self.current_rules()
            try: self.store_presets()
            except OSError as exc: feedback.configure(text=str(exc)); return
            selection.set(name); menu=options['menu']; menu.delete(0,'end')
            for item in self.rule_presets: menu.add_command(label=item,command=lambda value=item:selection.set(value))
            feedback.configure(text='Saved preset: '+name)
        self.button(row,'Save current rules',save,secondary=True).pack(side='right',padx=(6,0))
        self.label(body,'TIMER & BOTS · CHANGE IN THE WAITING ROOM',10,self.GOLD,True).pack(anchor='w',pady=(17,7))
        rules=self.current_rules(); values={}
        for label,key,choices in (('Turn timer (seconds)','turn_timer',(0,30,45,60)),('UNO rounds per match','round_limit',(0,3,5,10)),
                                  ('Bot seats','bot_count',tuple(range(rules['player_count']))),('Bot difficulty','bot_difficulty',('easy','normal','hard'))):
            row=tk.Frame(body,bg=self.BG); row.pack(fill='x',pady=4)
            self.label(row,label,11,self.TEXT).pack(side='left')
            variable=tk.StringVar(window,str(rules[key])); values[key]=variable
            control=tk.OptionMenu(row,variable,*choices); control.configure(state='disabled' if running else 'normal'); control.pack(side='right')
        def apply_options():
            try:
                selected=dict(rules,**{key:variable.get() if key=='bot_difficulty' else int(variable.get()) for key,variable in values.items()})
                if self.apply_rule_preset(selected): window.destroy()
            except (ValueError,TypeError) as exc: feedback.configure(text=str(exc))
        if not running: self.button(body,'Apply room options',apply_options).pack(fill='x',pady=10)

    def show_appearance(self):
        before=set(self.winfo_children()); super().show_appearance()
        windows=[w for w in self.winfo_children() if w not in before and isinstance(w,tk.Toplevel)]
        if not windows: return
        window=windows[-1]
        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)
        for button in walk(window):
            if isinstance(button,SoftButton):
                name=button.cget('text').lstrip('✓  ')
                if name in THEMES: button.command=lambda value=name:self.show_theme_preview(value,window)

    def show_theme_preview(self,name,parent=None):
        from theme_scenes import paint_scene
        parent=parent or self
        window=tk.Toplevel(parent); window.title('Preview · '+name); window.geometry('660x400')
        window.configure(bg=THEMES[name]['BG']); window.transient(parent); window.grab_set()
        paint=THEMES[name]
        art=tk.Canvas(window,bg=paint['BG'],height=290,highlightthickness=0); art.pack(fill='both',expand=True)
        def redraw(e=None):
            art.delete('all'); w,h=art.winfo_width(),art.winfo_height()
            paint_scene(art,w,h,name,paint)
            art.design=name; art.card_back_style=self.profile['card_back']
            paint_uno_card(art,w*.22,h*.30,62,93)
            paint_uno_card(art,w*.35,h*.30,62,93,('Red','7'))
            for index,color in enumerate(('#d9363e','#25955b','#e5bd24','#287ec3')): pawn(art,w*.58+index*35,h*.56,15,color,index+1)
            art.create_text(w/2,28,text=name,font=('Segoe UI',22,'bold'),fill=paint['TEXT'])
            art.create_text(w/2,h-20,text='A coordinated scene for UNO, Mensch and the menus',font=('Segoe UI',10),fill=paint['TEXT'])
        art.bind('<Configure>',redraw)
        footer=tk.Frame(window,bg=paint['BG'],padx=18,pady=12); footer.pack(fill='x')
        def close():
            window.destroy()
            if parent is not self and parent.winfo_exists(): parent.grab_set()
        def apply():
            window.destroy()
            if parent is not self and parent.winfo_exists(): parent.destroy()
            self.apply_design(name)
        SoftButton(footer,'Apply this design',apply,paint,large=True).pack(side='right')
        SoftButton(footer,'Back',close,paint,secondary=True).pack(side='left')
        window.protocol('WM_DELETE_WINDOW',close); window.bind('<Escape>',lambda e:close())
