"""Small original vector avatars, readable at roster and profile-preview sizes."""
import math


def paint_avatar(c,x,y,r,kind,paint,tag='player-avatar'):
    base=paint['GREEN']; light='#fff7e8'; dark='#20263e'
    c.create_oval(x-r,y-r,x+r,y+r,fill=base,outline=paint['BORDER'],width=1,tags=(tag,))
    def oval(a,b,d,e,fill,outline=''):
        c.create_oval(x+a*r,y+b*r,x+d*r,y+e*r,fill=fill,outline=outline,width=max(1,r*.05))
    def polygon(points,fill):
        c.create_polygon(*[v for a,b in points for v in (x+a*r,y+b*r)],fill=fill,outline='')
    def line(points,color,width=.07):
        c.create_line(*[v for a,b in points for v in (x+a*r,y+b*r)],fill=color,width=max(1,r*width),smooth=True)
    if kind=='Cat':
        polygon(((-.72,-.08),(-.67,-.75),(-.13,-.39)),light)
        polygon(((.72,-.08),(.67,-.75),(.13,-.39)),light)
        oval(-.70,-.48,.70,.65,light)
        oval(-.39,-.14,-.22,.06,dark); oval(.22,-.14,.39,.06,dark)
        polygon(((-.12,.16),(.12,.16),(0,.31)),'#d96b83')
        for side in (-1,1):
            line(((side*.29,.22),(side*.83,.12)),dark,.035)
            line(((side*.29,.35),(side*.80,.45)),dark,.035)
    elif kind=='Rocket':
        polygon(((-.23,.36),(0,.86),(.23,.36)),'#ffc54d')
        polygon(((-.24,-.18),(-.58,.48),(-.15,.32)),light)
        polygon(((.24,-.18),(.58,.48),(.15,.32)),light)
        oval(-.27,-.73,.27,.44,light)
        polygon(((-.21,-.44),(0,-.86),(.21,-.44)),'#f48283')
        oval(-.14,-.32,.14,-.04,'#57c7d4',dark)
    elif kind=='Chef':
        oval(-.46,-.12,.46,.72,light)
        c.create_rectangle(x-r*.48,y-r*.32,x+r*.48,y+r*.04,fill='white',outline='')
        for center in (-.32,0,.32): oval(center-.25,-.73,center+.25,-.22,'white')
        oval(-.25,.17,-.13,.29,dark); oval(.13,.17,.25,.29,dark)
        line(((-.20,.45),(0,.55),(.20,.45)),dark,.06)
    elif kind=='Racer':
        oval(-.67,-.67,.67,.65,light)
        polygon(((-.68,-.15),(.60,-.15),(.66,.15),(.05,.32),(-.68,.19)),dark)
        line(((-.43,-.01),(.28,-.01)),'#7bd6df',.11)
        polygon(((-.38,.45),(.62,.28),(.57,.58),(-.28,.65)),'#f47d7e')
    elif kind=='Flower':
        for index in range(6):
            angle=index*math.pi/3; a,b=math.cos(angle)*.39,math.sin(angle)*.39
            oval(a-.30,b-.30,a+.30,b+.30,light)
        oval(-.25,-.25,.25,.25,'#ffc94f')
    else:
        points=[]
        for index in range(10):
            angle=-math.pi/2+index*math.pi/5; radius=.78 if index%2==0 else .34
            points.append((math.cos(angle)*radius,math.sin(angle)*radius))
        polygon(points,'#ffe18a')
