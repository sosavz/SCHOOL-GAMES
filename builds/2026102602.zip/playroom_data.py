"""Private local profiles and validated JSON match checkpoints. Never pickle data."""
from collections import Counter
import json
from pathlib import Path
import re
from maedn_rules import Maedn
from uno_rules import Uno, UNO_COLORS
from update_core import atomic_json

AVATARS = {'Star': '★', 'Cat': '♣', 'Rocket': '▲', 'Flower': '✿', 'Racer': '◆', 'Chef': '♨'}
BACKS = ('Room', 'Midnight', 'Pearl', 'Sunburst')
PRIVATE_FILES = {'playroom_host_save.json', 'playroom_profile.json', 'playroom_presets.json'}


def cosmetics(value=None):
    value = value if isinstance(value, dict) else {}
    return {'avatar': value.get('avatar') if isinstance(value.get('avatar'),str) and value.get('avatar') in AVATARS else 'Star',
            'card_back': value.get('card_back') if isinstance(value.get('card_back'),str) and value.get('card_back') in BACKS else 'Room'}


def read_json(path, default=None, limit=262144):
    try:
        if path.stat().st_size > limit:
            return default
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError, RecursionError):
        return default


def load_profile(root):
    raw = read_json(Path(root)/'playroom_profile.json', {})
    if not isinstance(raw, dict): raw = {}
    result = cosmetics(raw)
    result['stats'] = {}
    for kind in ('uno', 'maedn'):
        source = raw.get('stats', {}).get(kind, {}) if isinstance(raw.get('stats'), dict) else {}
        if not isinstance(source,dict): source={}
        result['stats'][kind] = {key: value if type(value := source.get(key)) is int and 0 <= value <= 10**9 else 0
                                 for key in ('played', 'wins', 'practice')}
    for key in ('streak', 'best_streak'):
        result[key] = raw.get(key, 0) if type(raw.get(key, 0)) is int and 0 <= raw.get(key, 0) <= 10**9 else 0
    result['recent'] = [item for item in raw.get('recent', []) if isinstance(item, str) and re.fullmatch('[a-f0-9]{32}', item)][-1000:] if isinstance(raw.get('recent'), list) else []
    return result


def record_result(profile, result, seat):
    if not isinstance(result, dict) or result.get('id') in profile['recent']:
        return False
    if result.get('kind') not in ('uno', 'maedn') or not re.fullmatch('[a-f0-9]{32}', str(result.get('id', ''))):
        return False
    stats = profile['stats'][result['kind']]
    if result.get('practice'):
        stats['practice'] += 1
    else:
        stats['played'] += 1
        won = result.get('winner') == seat
        stats['wins'] += int(won)
        profile['streak'] = profile['streak']+1 if won else 0
        profile['best_streak'] = max(profile['best_streak'], profile['streak'])
    profile['recent'] = (profile['recent']+[result['id']])[-1000:]
    return True


def achievements(profile):
    stats = profile['stats']
    return [name for name, earned in (
        ('First victory', sum(s['wins'] for s in stats.values()) >= 1),
        ('Both tables mastered', all(s['wins'] for s in stats.values())),
        ('On fire · 3 wins in a row', profile['best_streak'] >= 3),
        ('Game-night regular · 10 rounds', sum(s['played'] for s in stats.values()) >= 10)) if earned]


def engine_data(game):
    if game is None: return None
    value = {key: list(item) if isinstance(item, set) else item
             for key, item in vars(game).items() if not callable(item)}
    return json.loads(json.dumps(value))


def integer(value, low, high):
    if type(value) is not int or not low <= value <= high: raise ValueError('Invalid number in saved match.')
    return value


def seat_or_none(value, count):
    return None if value is None else integer(value, 0, count-1)


def restore_engine(kind, data, count, settings, board):
    if data is None: return None
    if not isinstance(data, dict): raise ValueError('Invalid saved game.')
    game = Uno(dealer=0, player_count=count, **settings) if kind == 'uno' else Maedn(player_count=count, starter=0, **board)
    allowed = set(vars(game)) | ({'match_done', 'match_winner'} if kind == 'uno' else set())
    if set(data)-allowed: raise ValueError('Unknown saved game fields.')
    values = {**engine_data(game), **data}
    if values['player_count'] != count: raise ValueError('Saved player count differs.')
    integer(values['turn'], 0, count-1)
    seat_or_none(values['winner'], count)
    if type(values['done']) is not bool or not isinstance(values['note'], str) or len(values['note']) > 2000:
        raise ValueError('Invalid saved game status.')
    if values['done'] and values['winner'] is None or values['done']!=(values['phase']=='finished'):
        raise ValueError('Inconsistent saved game result.')
    if kind == 'uno':
        if values['phase'] not in ('ready','drawn','opening_color','draw_stack','challenge','audit','finished'):
            raise ValueError('Invalid saved card phase.')
        if values['direction'] not in (-1,1) or values['color'] not in (*UNO_COLORS,'Wild'):
            raise ValueError('Invalid saved direction or color.')
        integer(values['dealer'],0,count-1)
        if values['uno_mode'] != settings['uno_mode'] or values['starting_cards'] != settings['starting_cards'] or values['target_score'] != settings['target_score']:
            raise ValueError('Saved card rules differ.')
        valid_cards=set(game.deck+game.discard+sum(game.hands,[]))
        def cards(items):
            if not isinstance(items,list) or len(items)>108: raise ValueError('Invalid saved cards.')
            result=[]
            for card in items:
                if not isinstance(card,list) or len(card)!=2 or not all(isinstance(v,str) for v in card):
                    raise ValueError('Invalid saved card.')
                if tuple(card) not in valid_cards: raise ValueError('Unknown saved card.')
                result.append(tuple(card))
            return result
        if not isinstance(values['hands'],list) or len(values['hands'])!=count: raise ValueError('Invalid saved hands.')
        values['hands']=[cards(hand) for hand in values['hands']]
        for key in ('deck','discard'): values[key]=cards(values[key])
        if not values['discard']: raise ValueError('Missing discard pile.')
        reference=Counter(game.deck+game.discard+sum(game.hands,[]))
        if Counter(values['deck']+values['discard']+sum(values['hands'],[])) != reference:
            raise ValueError('Saved deck does not contain the original 108 cards.')
        if not isinstance(values['match_points'],list) or len(values['match_points'])!=count: raise ValueError('Invalid saved scores.')
        for score in values['match_points']: integer(score,0,10**9)
        integer(values['round_points'],0,10**9)
        breakdown=values['round_breakdown']
        if breakdown is not None:
            if not isinstance(breakdown,list) or len(breakdown)!=count: raise ValueError('Invalid round scores.')
            for points in breakdown: integer(points,0,10**9)
        if 'match_done' in values and type(values['match_done']) is not bool: raise ValueError('Invalid match result.')
        if 'match_winner' in values: seat_or_none(values['match_winner'],count)
        if values['dealer_draws'] is not None:
            if not isinstance(values['dealer_draws'],list) or len(values['dealer_draws'])!=count: raise ValueError('Invalid dealer draws.')
            for card in values['dealer_draws']:
                if card is not None: cards([card])
        integer(values['stack_penalty'],0,216)
        integer(values.get('launcher_serial',0),0,10**9)
        integer(values.get('launcher_burst',0),0,108)
        seat_or_none(values.get('launcher_owner'),count)
        for key in ('missed_uno','continue_turn'): seat_or_none(values[key],count)
        if type(values['announced']) is not bool: raise ValueError('Invalid UNO announcement.')
        if not isinstance(values['uno_called'],list): raise ValueError('Invalid UNO calls.')
        values['uno_called']={integer(seat,0,count-1) for seat in values['uno_called']}
        index=values['drawn_index']
        if index is not None: integer(index,0,len(values['hands'][values['turn']])-1)
        if values['phase']=='drawn' and index is None: raise ValueError('Missing drawn card.')
        for key in ('challenge','audit'):
            item=values[key]
            if item is not None:
                if not isinstance(item,list) or len(item)!=4: raise ValueError('Invalid saved challenge.')
                integer(item[0],0,count-1)
                evidence=2 if key=='challenge' else 1
                guilty=1 if key=='challenge' else 3
                color=3 if key=='challenge' else 2
                if type(item[guilty]) is not bool or item[color] not in UNO_COLORS: raise ValueError('Invalid challenge evidence.')
                item[evidence]=cards(item[evidence]); values[key]=tuple(item)
        if values['phase']=='challenge' and values['challenge'] is None: raise ValueError('Missing challenge.')
        if values['phase']=='audit' and (values['audit'] is None or values['continue_turn'] is None): raise ValueError('Missing audit.')
    else:
        if values['phase'] not in ('roll','move','finished'): raise ValueError('Invalid saved board phase.')
        for key in ('board_sides','track_length','slots','three_rolls','home_jumping'):
            if values[key] != getattr(game,key): raise ValueError('Saved board layout differs.')
        if not isinstance(values['pieces'],list) or len(values['pieces'])!=count: raise ValueError('Invalid saved pawns.')
        for pieces in values['pieces']:
            if not isinstance(pieces,list) or len(pieces)!=4: raise ValueError('Invalid saved pawns.')
            for pos in pieces: integer(pos,-1,game.track_length+3)
            active=[pos for pos in pieces if pos!=-1]
            if len(active)!=len(set(active)): raise ValueError('Overlapping saved pawns.')
        if values['die'] is not None: integer(values['die'],1,6)
        if values['phase']=='move' and values['die'] is None: raise ValueError('Missing saved die.')
        seat_or_none(values['die_owner'],count); integer(values['tries_left'],0,3)
        if not isinstance(values['rankings'],list) or len(set(values['rankings']))!=len(values['rankings']): raise ValueError('Invalid rankings.')
        for seat in values['rankings']: integer(seat,0,count-1)
        if values['done'] and (len(values['rankings'])!=count or values['rankings'][0]!=values['winner']):
            raise ValueError('Invalid finished rankings.')
    game.__dict__.update(values)
    if kind=='uno':
        for key in ('dealer_draws',):
            if game.__dict__[key] is not None: game.__dict__[key]=[tuple(card) if card else None for card in game.__dict__[key]]
    for seat in range(count): game.actions_for(seat)
    return game


def validate_checkpoint(value):
    if not isinstance(value,dict) or value.get('schema')!=1: raise ValueError('This saved match is not supported.')
    count=integer(value.get('player_count'),2,6)
    kind=value.get('game_kind')
    if kind not in ('uno','maedn'): raise ValueError('Invalid saved game type.')
    if not re.fullmatch('[0-9]{6}',str(value.get('code',''))): raise ValueError('Invalid saved room code.')
    for field in ('names','tokens','profiles','muted','night_scores'):
        if not isinstance(value.get(field),list) or len(value[field])!=count: raise ValueError('Invalid saved player seats.')
    for name in value['names']:
        if not isinstance(name,str) or len(name)>20: raise ValueError('Invalid saved name.')
    for token in value['tokens']:
        if token is not None and (not isinstance(token,str) or not re.fullmatch('[A-Za-z0-9_-]{20,80}',token)): raise ValueError('Invalid saved seat key.')
    for score in value['night_scores']: integer(score,0,10**9)
    if not isinstance(value.get('night_queue'),list) or len(value['night_queue'])>12 or any(kind not in ('uno','maedn') for kind in value['night_queue']): raise ValueError('Invalid saved playlist.')
    if not isinstance(value.get('bots'),list) or any(type(seat) is not int or not 1<=seat<count for seat in value['bots']): raise ValueError('Invalid saved bot seats.')
    for key in ('round_id','room_id'):
        if not re.fullmatch('[a-f0-9]{32}',str(value.get(key,''))): raise ValueError('Invalid saved match identity.')
    if value.get('theme') not in __import__('uno_themes').THEMES: raise ValueError('Invalid saved design.')
    integer(value.get('round_number'),0,10**9)
    integer(value.get('turn_timer'),0,60)
    integer(value.get('round_limit'),0,10)
    if value['turn_timer'] not in (0,30,45,60) or value['round_limit'] not in (0,3,5,10): raise ValueError('Invalid saved timer or round limit.')
    if value.get('bot_difficulty') not in ('easy','normal','hard'): raise ValueError('Invalid saved bot difficulty.')
    for key in ('paused','join_locked','practice'):
        if type(value.get(key)) is not bool: raise ValueError('Invalid saved room option.')
    if any(type(item) is not bool for item in value['muted']): raise ValueError('Invalid saved mute option.')
    game=restore_engine(kind,value.get('game'),count,value.get('settings',{}),value.get('board_settings',{}))
    result=value.get('round_result')
    if result is not None:
        if (not isinstance(result,dict) or result.get('id')!=value['round_id'] or result.get('kind')!=kind
                or type(result.get('practice')) is not bool or game is None or not game.done
                or result.get('winner')!=game.winner): raise ValueError('Invalid saved result.')
    return value,game
