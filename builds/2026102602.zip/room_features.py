"""Local recovery and game-night state for the existing authoritative room."""
from pathlib import Path
import time
import uuid
from playroom_data import cosmetics, engine_data, read_json, validate_checkpoint
from update_core import atomic_json


class RoomFeatures:
    def init_features(self, save_path=None, saved_room=None):
        self.save_path=Path(save_path) if save_path else None
        self.save_error=''; self.saved_at=None; self._saved_revision=-1
        self.room_id=uuid.uuid4().hex; self.round_id=uuid.uuid4().hex
        self.profiles=[cosmetics() for _ in range(self.player_count)]
        self.night_queue=[]; self.night_scores=[0]*self.player_count
        self.round_result=None; self.practice=False
        if saved_room is not None:
            value,game=validate_checkpoint(saved_room)
            self.code=value['code']; self.room_id=value['room_id']; self.round_id=value['round_id']
            self.names=list(value['names']); self.tokens=list(value['tokens'])
            self.profiles=[cosmetics(profile) for profile in value['profiles']]
            self.muted=list(value['muted']); self.game=game
            self.round_number=value['round_number']; self.practice=value['practice']
            self.night_queue=list(value['night_queue']); self.night_scores=list(value['night_scores'])
            self.round_result=value.get('round_result')
            self.paused=value['paused']; self.join_locked=value['join_locked']
            from uno_net import BotPeer
            for seat in value['bots']:
                peer=BotPeer(self.names[seat],seat,self.bot_difficulty)
                peer.token=self.tokens[seat]; self.peers[seat]=peer; self.ready[seat]=True
            self._sync_bot_seats()
            self.last_event='Saved table restored. Friends can reconnect with the same room code and their saved seats.'

    def feature_snapshot(self,seat):
        return {'room_id':self.room_id,'round_id':self.round_id,'profiles':[dict(p) for p in self.profiles],
                'night_queue':list(self.night_queue),'night_scores':list(self.night_scores),
                'round_result':self.round_result,'practice':self.practice,
                'saved_at':self.saved_at,'save_error':self.save_error if seat==0 else ''}

    def new_round(self):
        self.round_id=uuid.uuid4().hex
        self.round_result=None

    def record_round(self):
        if self.game is None or not self.game.done or self.round_result is not None: return
        winner=self.game.winner
        if type(winner) is not int or not 0<=winner<self.player_count: return
        self.night_scores[winner]+=1
        self.round_result={'id':self.round_id,'kind':self.game_kind,'winner':winner,'practice':self.practice}

    def feature_command(self,seat,message):
        kind=message.get('type')
        if kind=='profile':
            profile=message.get('profile')
            if not isinstance(profile,dict) or cosmetics(profile)!=profile:
                self._reject(seat,'Choose a supported avatar and card back.'); return True
            self.profiles[seat]=dict(profile)
            # Cosmetic changes must not invalidate a move already in flight.
            self.checkpoint(force=True); self._broadcast()
            return True
        elif kind=='night':
            if seat!=0:
                self._reject(seat,'Only the room owner can schedule game night.'); return True
            if type(message.get('revision')) is not int or message.get('revision')!=self.revision:
                self._reject(seat,'The table changed. Reopen Game night and try again.'); return True
            queue=message.get('queue')
            if type(message.get('reset_scores',False)) is not bool:
                self._reject(seat,'Score reset must be on or off.'); return True
            if not isinstance(queue,list) or len(queue)>12 or any(kind not in ('uno','maedn') for kind in queue):
                self._reject(seat,'Queue up to twelve UNO or Mensch rounds.'); return True
            if message.get('reset_scores'):
                if self.game is not None and not self.game.done:
                    self._reject(seat,'Finish the current round before resetting night scores.'); return True
                self.night_scores=[0]*self.player_count
            self.night_queue=list(queue)
            self.last_event='The host updated the game-night playlist. Each queued game starts after everyone is ready.'
            if self.game is None: self.ready=[False]*self.player_count
        else:
            return False
        self.revision+=1; self._broadcast()
        return True

    def checkpoint(self,force=False):
        if self.stop.is_set() and not force: return
        if self.save_path is None or not force and self._saved_revision==self.revision: return
        value={'schema':1,'code':self.code,'room_id':self.room_id,'round_id':self.round_id,
               'player_count':self.player_count,'names':list(self.names),'tokens':list(self.tokens),
               'profiles':list(self.profiles),'muted':list(self.muted),'bots':sorted(self.bot_seats),
               'settings':dict(self.settings),'board_settings':dict(self.board_settings),
               'game_kind':self.game_kind,'theme':self.theme,'bot_difficulty':self.bot_difficulty,
               'turn_timer':self.turn_timer,'round_limit':self.round_limit,'paused':self.paused,
               'join_locked':self.join_locked,'game':engine_data(self.game),'round_number':self.round_number,
               'night_queue':list(self.night_queue),'night_scores':list(self.night_scores),
               'round_result':self.round_result,'practice':self.practice}
        try:
            atomic_json(self.save_path,value)
            self.saved_at=time.strftime('%H:%M:%S'); self.save_error=''; self._saved_revision=self.revision
        except (OSError,ValueError,TypeError) as exc:
            self.save_error='Match could not be saved: '+str(exc)


def load_room(path):
    value=read_json(Path(path))
    try:
        return validate_checkpoint(value)[0]
    except (ValueError,TypeError,KeyError,AttributeError,IndexError):
        raise ValueError('This saved table is damaged or incompatible. Your file has been kept.')
