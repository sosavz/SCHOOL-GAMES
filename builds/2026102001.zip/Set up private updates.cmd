@echo off
setlocal
title Playroom - Private updates
echo ONE-TIME SETUP
echo First accept the host's invitation to sosavz/SCHOOL-GAMES on GitHub.
echo Sign in below using that same GitHub account.
echo.
set "PLAYROOM_GH=gh"
if exist "%~dp0runtime\gh.exe" (
    set "PLAYROOM_GH=%~dp0runtime\gh.exe"
    goto login
)
where gh >nul 2>nul
if %errorlevel% equ 0 goto login
if exist "%ProgramFiles%\GitHub CLI\gh.exe" (
    set "PLAYROOM_GH=%ProgramFiles%\GitHub CLI\gh.exe"
    goto login
)
if exist "%LOCALAPPDATA%\Programs\GitHub CLI\gh.exe" (
    set "PLAYROOM_GH=%LOCALAPPDATA%\Programs\GitHub CLI\gh.exe"
    goto login
)
echo Install GitHub CLI from https://cli.github.com then run this file again.
echo You can also install it in Terminal with:
echo winget install --id GitHub.cli --exact --source winget
pause
exit /b 1
:login
"%PLAYROOM_GH%" auth login --hostname github.com --git-protocol https --web
if errorlevel 1 (
    echo Sign-in was not completed. You can still play your installed game.
    pause
    exit /b 1
)
"%PLAYROOM_GH%" api --hostname github.com repos/sosavz/SCHOOL-GAMES --silent
if errorlevel 1 (
    echo Your account cannot access the private repository yet.
    echo Ask the host to invite your GitHub username, then accept the invitation.
) else (
    echo Ready! Open Start UNO Together.cmd to check for updates and play.
)
pause
