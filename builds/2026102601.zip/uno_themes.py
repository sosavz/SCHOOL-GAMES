"""Local, vector-drawn table themes. Card and pawn colors keep their meaning."""
import math

THEMES = {
    'Playroom': dict(BG='#f3f1eb', PANEL='#ffffff', TEXT='#20263e', MUTED='#697188', GOLD='#514bcb',
                     GREEN='#514bcb', BUTTON='#e9e7f5', BUTTON_TEXT='#ffffff', BOARD='#eeedf8',
                     BORDER='#d9d9e8', TILE='#ffffff', ACTIVE='#ddd9fb', ENTRY='#f3f2fa', ERROR='#b82f48'),
    'Classic': dict(BG='#0c211d', PANEL='#15372e', TEXT='#f5f3df', MUTED='#aac0af', GOLD='#ffe177',
                    GREEN='#287b59', BUTTON='#284a3c', BUTTON_TEXT='#ffffff', BOARD='#174539',
                    BORDER='#356352', TILE='#12392f', ACTIVE='#225540', ENTRY='#f5f5e9', ERROR='#ffb9a4'),
    'Spider-Man': dict(BG='#0a142b', PANEL='#15264a', TEXT='#f1f5ff', MUTED='#acbddc', GOLD='#ff7b89',
                      GREEN='#b52c48', BUTTON='#294578', BUTTON_TEXT='#ffffff', BOARD='#102344',
                      BORDER='#35527c', TILE='#0b1933', ACTIVE='#682c46', ENTRY='#eef3ff', ERROR='#ffb9a4'),
    'Hello Kitty': dict(BG='#fff1f7', PANEL='#ffe1ee', TEXT='#59283f', MUTED='#86546d', GOLD='#a31e59',
                       GREEN='#b7316a', BUTTON='#ead0e1', BUTTON_TEXT='#ffffff', BOARD='#fbd4e5',
                       BORDER='#dba1be', TILE='#fff3f8', ACTIVE='#f1b4d0', ENTRY='#fffafd', ERROR='#a3263e'),
    'Formula 1': dict(BG='#101316', PANEL='#20262c', TEXT='#f6f6f2', MUTED='#b4c0c6', GOLD='#ff8177',
                     GREEN='#c0362e', BUTTON='#37424c', BUTTON_TEXT='#ffffff', BOARD='#282e34',
                     BORDER='#4f5b65', TILE='#171c21', ACTIVE='#6b302e', ENTRY='#f3f5f5', ERROR='#ffb9a4'),
    'Starlight': dict(BG='#111128', PANEL='#211f43', TEXT='#f7f3ff', MUTED='#c1b9dc', GOLD='#ffd879',
                      GREEN='#40b8a7', BUTTON='#39345f', BUTTON_TEXT='#ffffff', BOARD='#191a38',
                      BORDER='#49436f', TILE='#252345', ACTIVE='#39345f', ENTRY='#17172f', ERROR='#ff9cab'),
    'Deep Sea': dict(BG='#092631', PANEL='#103b49', TEXT='#eaffff', MUTED='#a9d2d6', GOLD='#ffd66e',
                     GREEN='#24a994', BUTTON='#1d5660', BUTTON_TEXT='#ffffff', BOARD='#0e3440',
                     BORDER='#28717a', TILE='#12404b', ACTIVE='#1b5a63', ENTRY='#092d38', ERROR='#ffaaa2'),
    'Woodland': dict(BG='#18261d', PANEL='#273b2b', TEXT='#f4f5e6', MUTED='#c0ccb4', GOLD='#efd27d',
                     GREEN='#62975d', BUTTON='#3a5d43', BUTTON_TEXT='#ffffff', BOARD='#263a2b',
                     BORDER='#536d4f', TILE='#1e3225', ACTIVE='#3d6046', ENTRY='#192b20', ERROR='#ffb1a3'),
    'Candy Clouds': dict(BG='#fff4f5', PANEL='#ffe7ee', TEXT='#462a47', MUTED='#775c78', GOLD='#963c8c',
                        GREEN='#4c8b78', BUTTON='#e9d2ef', BUTTON_TEXT='#ffffff', BOARD='#f8e8f3',
                        BORDER='#d8b7d1', TILE='#fffafd', ACTIVE='#efd4ea', ENTRY='#ffffff', ERROR='#a22647'),
    'Arcade': dict(BG='#111820', PANEL='#1b2534', TEXT='#f0fbff', MUTED='#a8bcc9', GOLD='#f5dc54',
                   GREEN='#32d0b0', BUTTON='#343d55', BUTTON_TEXT='#ffffff', BOARD='#182332',
                   BORDER='#4d6173', TILE='#121d29', ACTIVE='#263b4b', ENTRY='#101923', ERROR='#ff9696'),
    'Sunset': dict(BG='#35223d', PANEL='#4a2d4a', TEXT='#fff7ed', MUTED='#e0c5ce', GOLD='#ffc76b',
                   GREEN='#64b395', BUTTON='#69445d', BUTTON_TEXT='#ffffff', BOARD='#492d49',
                   BORDER='#8e5b67', TILE='#3e2843', ACTIVE='#704658', ENTRY='#39233e', ERROR='#ffaba1'),
    'Larissa': dict(BG='#e9e9e7', PANEL='#ffffff', TEXT='#202124', MUTED='#666a70', GOLD='#a5874f',
                    GREEN='#30343a', BUTTON='#d9dadd', BUTTON_TEXT='#ffffff', BOARD='#e2e2df',
                    BORDER='#aeb0b2', TILE='#ffffff', ACTIVE='#d5d6d7', ENTRY='#ffffff', ERROR='#aa5147'),
}


def decorate_table(canvas, width, height, theme, paint):
    """Subtle vector table decorations; nothing here changes game state."""
    ink = paint['BORDER']
    if theme == 'Spider-Man':
        for corner in (0, width):
            sign = 1 if corner == 0 else -1
            for fraction in (.2, .4, .6, .8, 1):
                reach = min(width*.42, height*.7) * fraction
                canvas.create_line(corner, 110+reach, corner+sign*reach*.52, 110+reach*.52,
                                   corner+sign*reach, 110, fill=ink, smooth=True, width=1)
            for fraction in (.2, .5, .8):
                canvas.create_line(corner, 110, corner+sign*width*.32*fraction,
                                   110+height*.55*(1-fraction), fill=ink, width=1)
    elif theme == 'Hello Kitty':
        for x, y, size in ((width*.14, height*.44, 16), (width*.86, height*.44, 16),
                           (width*.25, height*.68, 10), (width*.75, height*.68, 10)):
            for offset in (-size*.55, size*.55):
                canvas.create_oval(x+offset-size*.55, y-size*.55, x+offset+size*.55, y+size*.55,
                                   fill=paint['ACTIVE'], outline=ink)
            canvas.create_oval(x-size*.25, y-size*.3, x+size*.25, y+size*.3,
                               fill=ink, outline='')
    elif theme == 'Formula 1':
        for side in (14, width-24):
            for row in range(10):
                canvas.create_rectangle(side, 118+row*12, side+8, 128+row*12,
                                        fill=ink if row%2 else paint['ACTIVE'], outline='')
        canvas.create_line(width*.22, height*.45, width*.22, height*.35, width*.3, height*.29,
                           width*.7, height*.29, width*.78, height*.35, width*.78, height*.45,
                           smooth=True, fill=ink, width=2)
    elif theme == 'Starlight':
        for x, y, size in ((.12,.25,9),(.23,.54,5),(.81,.24,7),(.89,.55,10),(.72,.72,5),(.31,.78,7)):
            px, py = width*x, height*y
            canvas.create_text(px,py,text='✦',fill=ink,font=('Segoe UI',size,'bold'))
    elif theme == 'Deep Sea':
        for row in range(3):
            y=height*(.28+row*.17)
            points=[]
            for i in range(17):
                x=width*i/16; points.extend((x,y+math.sin(i*.72+row)*7))
            canvas.create_line(*points,fill=ink,smooth=True,width=2)
    elif theme == 'Woodland':
        for x,y,size,angle in ((.13,.33,18,-1),(.86,.35,17,1),(.2,.72,13,1),(.8,.7,13,-1)):
            px,py=width*x,height*y
            canvas.create_oval(px-size,py-size*.45,px+size,py+size*.45,outline=ink,width=2)
            canvas.create_line(px-size*.7,py+size*.3,px+size*.7,py-size*.3,fill=ink,width=2)
    elif theme == 'Candy Clouds':
        for x,y,size in ((.12,.36,11),(.86,.36,11),(.22,.7,8),(.78,.69,8)):
            px,py=width*x,height*y
            for dx,dy in ((-size*.7,0),(0,-size*.45),(size*.7,0)):
                canvas.create_oval(px+dx-size*.55,py+dy-size*.55,px+dx+size*.55,py+dy+size*.55,
                                   fill=paint['PANEL'],outline=ink)
    elif theme == 'Arcade':
        for x,y,size in ((.14,.38,17),(.84,.38,17),(.23,.7,11),(.77,.7,11)):
            canvas.create_oval(width*x-size,height*y-size,width*x+size,height*y+size,outline=ink,width=2)
            canvas.create_oval(width*x-size*.55,height*y-size*.55,width*x+size*.55,height*y+size*.55,
                               outline=paint['ACTIVE'],width=2)
    elif theme == 'Sunset':
        cx,cy=width/2,height*.75
        canvas.create_arc(cx-34,cy-34,cx+34,cy+34,start=0,extent=180,style='arc',outline=ink,width=3)
        for dx in (-48,-25,0,25,48):
            canvas.create_line(cx+dx,cy-18,cx+dx*1.3,cy-32,fill=ink,width=2)
    elif theme == 'Larissa':
        # A bright, luxury monochrome kitchen: marble, lacquered cabinetry,
        # brushed metal details, and a warm under-cabinet light line.
        canvas.create_rectangle(14,104,width-14,min(height*.48,330),fill='#f7f7f5',outline='#bfc1c2',width=2)
        tile=max(42,min(78,int(width*.065)))
        for x in range(15,int(width),tile):
            canvas.create_line(x,106,x+tile*.7,min(height*.48,330),fill='#e0e1df',width=1)
            canvas.create_line(x+tile*.22,106,x-tile*.48,min(height*.48,330),fill='#ececea',width=1)
        # Deep charcoal upper cabinets frame the wall without hiding the signage.
        cab_bottom=min(height*.32,220)
        for left,right in ((18,width*.20),(width*.80,width-18)):
            canvas.create_rectangle(left,112,right,cab_bottom,fill='#242629',outline='#111315',width=3)
            count=2
            for index in range(count):
                x1=left+(right-left)*index/count+7
                x2=left+(right-left)*(index+1)/count-7
                canvas.create_rectangle(x1,120,x2,cab_bottom-8,fill='#303337',outline='#55585a',width=2)
                canvas.create_line(x2-9,145,x2-9,cab_bottom-28,fill='#b3b4b4',width=3)
            canvas.create_line(left+5,cab_bottom-4,right-5,cab_bottom-4,fill='#d2b77b',width=2)
        # Feature island on the left and a built-in black-glass oven on the right.
        oven_x=width*.86
        canvas.create_rectangle(oven_x-45,168,oven_x+45,276,fill='#17191b',outline='#777a7c',width=3)
        canvas.create_rectangle(oven_x-33,190,oven_x+33,254,fill='#25282a',outline='#8f9294',width=2)
        canvas.create_line(oven_x-32,181,oven_x+32,181,fill='#c7c8c7',width=3)
        for knob_x in (oven_x-20,oven_x+20):
            canvas.create_oval(knob_x-4,170,knob_x+4,178,fill='#d2b77b',outline='')
        # Keep the slogan on the outer wall, clear of the central card piles.
        banner_left,banner_right=width*.67,width*.975
        canvas.create_rectangle(banner_left+4,55,banner_right+4,111,fill='#b7b8b7',outline='')
        canvas.create_rectangle(banner_left,51,banner_right,107,fill='#242629',outline='#c8aa6c',width=3)
        canvas.create_text((banner_left+banner_right)/2,79,text='kuchen, putzen,\nabpumpen',
                           fill='#ffffff',font=('Segoe UI',max(13,min(17,int(width*.014))),'bold'),justify='center')
        # A luminous marble island/countertop grounds the scene at the lower edge.
        counter_y=min(height*.53,348)
        canvas.create_rectangle(14,counter_y,width-14,counter_y+25,fill='#25282b',outline='#111315',width=2)
        canvas.create_line(18,counter_y+3,width-18,counter_y+3,fill='#d6bd85',width=2)
        for x in range(40,int(width),150):
            canvas.create_line(x,counter_y+7,x+36,counter_y+19,x+64,counter_y+11,fill='#727578',width=1)
        # Stainless sink and an induction cooktop add unmistakable kitchen detail.
        sink_x=width*.18
        canvas.create_rectangle(sink_x-44,counter_y-8,sink_x+44,counter_y+8,fill='#c6c8c9',outline='#777a7c',width=2)
        canvas.create_arc(sink_x-10,counter_y-23,sink_x+10,counter_y+3,start=0,extent=180,style='arc',outline='#aeb1b2',width=4)
        stove_x=width*.82
        for dx in (-20,20):
            for dy in (-5,6):
                canvas.create_oval(stove_x+dx-7,counter_y-13+dy,stove_x+dx+7,counter_y+1+dy,outline='#c4c6c7',width=2)
        lower_top=counter_y+25; lower_bottom=min(height*.70,lower_top+145)
        canvas.create_rectangle(14,lower_top,width-14,lower_bottom,fill='#f0f0ee',outline='#b9bbbc',width=2)
        for x in range(int(width*.08),int(width*.94),int(max(120,width*.16))):
            canvas.create_rectangle(x,lower_top+8,x+max(90,width*.12),lower_bottom-6,fill='#fafaf9',outline='#d0d1d0',width=2)
            canvas.create_line(x+max(75,width*.105),lower_top+22,x+max(75,width*.105),lower_top+45,fill='#b1a277',width=3)
        # Tiny warm downlights lend depth while keeping the table and cards clear.
        for x in (width*.25,width*.38,width*.62,width*.75):
            canvas.create_oval(x-14,103,x+14,108,fill='#e6d9b5',outline='')


def card_back(canvas, x, y, w, h, theme):
    """Hand-drawn themed backs, independent of external image downloads."""
    cx, cy = x+w/2, y+h/2
    if theme == 'Spider-Man':
        canvas.create_oval(x+w*.14, y+h*.16, x+w*.86, y+h*.84, fill='#cf2343', outline='#101c38')
        for offset in (-.16, 0, .16):
            canvas.create_line(cx+offset*w, y+h*.19, cx+offset*w*.6, cy, cx+offset*w, y+h*.81,
                               fill='#762039', width=max(1,w*.012))
        for offset in (-.15, .13):
            canvas.create_line(x+w*.18, cy+offset*h, cx, cy+offset*h*.6, x+w*.82, cy+offset*h,
                               fill='#762039', width=max(1,w*.012))
        for sign in (-1, 1):
            canvas.create_polygon(cx+sign*w*.04, cy, cx+sign*w*.28, cy-h*.12,
                                  cx+sign*w*.23, cy+h*.06, cx+sign*w*.10, cy+h*.10,
                                  fill='#f9fbff', outline='#101c38', width=max(1,w*.02))
    elif theme == 'Hello Kitty':
        for sign in (-1,1):
            canvas.create_polygon(cx+sign*w*.13, cy-h*.15, cx+sign*w*.28, cy-h*.29,
                                  cx+sign*w*.33, cy-h*.07, fill='#fffefa', outline='#79425c')
        canvas.create_oval(x+w*.14,y+h*.31,x+w*.86,y+h*.72,fill='#fffefa',outline='#79425c')
        for sign in (-1,1):
            ex=cx+sign*w*.17
            canvas.create_oval(ex-w*.025,cy-h*.006,ex+w*.025,cy+h*.04,fill='#3a2632',outline='')
            for dy in (-.055, .015, .085):
                canvas.create_line(cx+sign*w*.29,cy+dy*h,cx+sign*w*.41,cy+(dy+.01)*h,
                                   fill='#79425c',width=max(1,w*.013))
        canvas.create_oval(cx-w*.045,cy+h*.045,cx+w*.045,cy+h*.085,fill='#e8be38',outline='')
        bx,by=x+w*.72,y+h*.34
        for dx in (-.075,.075):
            canvas.create_oval(bx+(dx-.07)*w,by-h*.055,bx+(dx+.07)*w,by+h*.055,
                               fill='#eb4b8d',outline='#a5285e')
        canvas.create_oval(bx-w*.04,by-h*.035,bx+w*.04,by+h*.035,fill='#c82e70',outline='')
    elif theme == 'Formula 1':
        for side in (-1,1):
            for dy in (-.15,.15):
                canvas.create_rectangle(cx+side*w*.23-w*.055,cy+dy*h-h*.065,
                                         cx+side*w*.23+w*.055,cy+dy*h+h*.065,fill='#050608',outline='#99a3a9')
        canvas.create_polygon(cx-w*.06,cy-h*.28,cx+w*.06,cy-h*.28,cx+w*.14,cy+h*.22,
                              cx-w*.14,cy+h*.22,fill='#f1493f',outline='#ffaca6')
        for dy in (-.23,.22):
            canvas.create_rectangle(cx-w*.24,cy+dy*h,cx+w*.24,cy+(dy+.04)*h,fill='#ed463d',outline='')
        canvas.create_oval(cx-w*.065,cy-h*.015,cx+w*.065,cy+h*.075,fill='#f6f7f1',outline='#1b2025')
        for row in range(2):
            for col in range(6):
                canvas.create_rectangle(x+w*(.2+col*.1),y+h*(.84+row*.04),
                                         x+w*(.3+col*.1),y+h*(.88+row*.04),
                                         fill='#eeeeee' if (row+col)%2 else '#1d2329',outline='')
    elif theme == 'Larissa':
        # Hand-painted plate with crossed wooden spoons and a small heart.
        canvas.create_oval(x+w*.2,y+h*.23,x+w*.8,y+h*.77,fill='#fffaf0',outline='#a98b6d',width=max(1,w*.02))
        canvas.create_oval(x+w*.29,y+h*.31,x+w*.71,y+h*.69,outline='#d7b995',width=max(1,w*.018))
        canvas.create_line(x+w*.37,y+h*.62,x+w*.65,y+h*.35,fill='#9a704b',width=max(2,w*.04))
        canvas.create_line(x+w*.63,y+h*.63,x+w*.36,y+h*.36,fill='#6d815e',width=max(2,w*.04))
        canvas.create_oval(x+w*.32,y+h*.31,x+w*.43,y+h*.43,fill='#9a704b',outline='')
        canvas.create_oval(x+w*.57,y+h*.57,x+w*.68,y+h*.69,fill='#6d815e',outline='')
        canvas.create_text(cx,cy,text='♥',fill='#b85e58',font=('Segoe UI',max(8,int(w*.14)),'bold'))
    else:
        palette=THEMES.get(theme,THEMES['Classic'])
        color=palette['GOLD']; accent=palette['GREEN']
        if theme == 'Starlight':
            for px,py,size in ((.27,.28,.08),(.72,.29,.06),(.28,.72,.055),(.72,.7,.09)):
                cx,cy=x+w*px,y+h*py
                canvas.create_text(cx,cy,text='✦',fill=color,font=('Segoe UI',max(8,int(w*size*3)),'bold'))
            canvas.create_oval(x+w*.38,y+h*.35,x+w*.62,y+h*.65,outline=accent,width=max(1,w*.025))
        elif theme == 'Deep Sea':
            for row in range(3):
                pts=[]
                for i in range(13):
                    px=x+w*(.17+i*.055); py=y+h*(.38+row*.12+math.sin(i*.65+row)*.035)
                    pts.extend((px,py))
                canvas.create_line(*pts,fill=color,width=max(1,w*.018),smooth=True)
            canvas.create_oval(x+w*.4,y+h*.23,x+w*.6,y+h*.43,outline=accent,width=max(1,w*.02))
        elif theme == 'Woodland':
            cx,cy=x+w/2,y+h/2
            canvas.create_line(cx,cy+h*.22,cx,cy-h*.22,fill=color,width=max(1,w*.025))
            for sign in (-1,1):
                for row in (-.12,.02,.16):
                    yy=cy+row*h
                    canvas.create_oval(cx,yy-h*.045,cx+sign*w*.23,yy+h*.045,outline=accent,width=max(1,w*.018))
        elif theme == 'Candy Clouds':
            for cx,cy in ((x+w*.5,y+h*.38),(x+w*.36,y+h*.52),(x+w*.64,y+h*.52)):
                canvas.create_oval(cx-w*.16,cy-h*.11,cx+w*.16,cy+h*.11,fill=palette['PANEL'],outline=color,width=max(1,w*.018))
            canvas.create_text(x+w*.5,y+h*.69,text='✦',fill=accent,font=('Segoe UI',max(8,int(w*.2)),'bold'))
        elif theme == 'Arcade':
            for size in (.3,.22,.13):
                canvas.create_oval(x+w*(.5-size),y+h*(.5-size),x+w*(.5+size),y+h*(.5+size),outline=color,width=max(1,w*.018))
            canvas.create_line(x+w*.24,y+h*.5,x+w*.76,y+h*.5,fill=accent,width=max(1,w*.02))
        elif theme == 'Sunset':
            cx,cy=x+w*.5,y+h*.55
            canvas.create_arc(cx-w*.25,cy-h*.22,cx+w*.25,cy+h*.28,start=0,extent=180,style='arc',outline=color,width=max(1,w*.025))
            for row in range(3):
                yy=cy+h*(.04+row*.08)
                canvas.create_line(cx-w*(.22-row*.025),yy,cx+w*(.22-row*.025),yy,fill=accent,width=max(1,w*.025))
