# UNO Together

A standalone collection of **UNO and Mensch ärgere dich nicht**, each for 2–6 players. Includes live room chat, a prominent turn banner, large action buttons, private UNO hands, reconnects, illustrated cards, twelve designs, accessible display settings, Classic and Extreme UNO modes, editable lobby settings, and opt-in lobby surprises. No Python installation is needed for the Windows ZIP.

## Automatic updates

After you get the current Windows ZIP once, the game checks for updates on every launch. No GitHub account or setup is required. The public download also works while the host PC is offline. The game still opens if an update check fails. See the friends guide for details.

## The Playroom redesign

Only UNO and Mensch ärgere dich nicht are included. The window is now called Playroom; the folder and launcher keep their existing names. Large illustrated game tiles lead to a simple name-and-code join screen. Rounded controls, clear turn prompts, highlighted legal moves, a compact player roster and an optional chat rail work down to a 960 × 680 window.

Card deals and flights, rolling dice, hopping pawns, captures and confetti follow authoritative game state. Animations never determine dice or rules. All legal moves, UNO calls and catches stay available during animation; a new move can interrupt a decorative effect. Seven original quiet sound effects are included and can be enabled in Settings. Reduced motion makes actions immediate.

How to play offers a three-step illustrated lesson for each game plus All rules. UNO number keys 1–7 select visible cards; R/Y/G/B choose a Wild color. D/U/P draw, call UNO and pass. Mensch uses Space to roll and 1–4 for pawns. Typing in chat or name/code fields never triggers moves. Leaving an active game asks for confirmation. Your display name is remembered locally.

## Practice against bots

Choose a game and player count, then click **Practice vs bots · this PC only**. You play the host seat and local bots fill the other seats for both games. Practice uses a loopback-only room and is not reachable by friends on the LAN.

## Start here

Open **Friends - START HERE.html** for the detailed, shareable guide. A Markdown copy is also included. In the app, use **Friends’ guide** or **Connection help**.

1. Everyone extracts the latest **UNO Together Windows.zip**, keeping the full runtime folder.
2. Open **Start UNO Together.cmd** and enter your name.
3. The host opens **Host settings**, chooses the game, the number of players and that game’s options, then creates a room. The host can also change these in the waiting room.
4. The host sends the six-digit code using **Copy code**. Friends enter only that code and click **Join room**. Everyone chooses **Ready to play**.

## Chat, turns and controls

Chat with everyone in the room from the right sidebar in both the lobby and game. Type in the message box and press Enter or Send. Messages show authenticated player names and seat numbers. The host keeps the latest 80 messages in memory and restores them on reconnect; closing the room clears history. Messages are limited to 240 characters and five messages per five seconds. Rejected messages keep their draft. Chat does not change game revisions, reveal hands, or interrupt a pending move or color picker.

Activity shows the latest shared game events with timestamps, including plays, turn changes, captures, reconnects and host actions; it is sent by the room so everyone sees the same feed. The Chat tab counts new messages while Activity is open. Chat scroll position is kept when reading older messages. Drafts survive theme changes, dealing and reconnects. All game shortcuts are inactive inside chat fields. The header Chat button hides or shows the rail without losing the draft.

A large YOUR TURN banner and a highlighted player tile identify the active player. The title bar also says Your turn when appropriate. The bottom-left Draw, UNO, pass, challenge and next-round buttons have larger text and click targets. Unavailable actions stay disabled, and the banner explains waiting, paused and round-end states.

Close old windows and use this release on every PC. Protocol version 7 adds server-enforced owner controls and fun effects; all players must update. Earlier versions cannot join.

## Mensch ärgere dich nicht

Choose **Host settings → Game → Mensch ärgere dich nicht**, then Apply settings. It supports 2–6 human players with four pawns each. One pawn starts on A and three in base. A 40-space board serves 2–4 players; a six-arm 60-space board serves 5–6. Two players sit on opposite arms.

Click Roll die or press Space, then click a highlighted pawn or use Pawn 1–4 / number keys. Pointing at a movable pawn previews its destination. The host generates dice and validates all moves. Six gives another roll and brings out a base pawn when A is free. An own pawn on A must move whenever possible while pawns wait in base. Landing on an opponent captures it, even on a start square. You may jump over track pawns but cannot land on your own. Home lanes need exact rolls and cannot be overshot.

All four pawns home gives a finishing place. Remaining players continue until only one remains; final places appear with Ready for another game. Chat, turn banners, saved seats, automatic reconnects and paused play work in both games. Keyboard shortcuts do not interrupt chat input.

The host can enable the optional three-attempt rule (default off) and disable jumping over pawns in the home lane (default allowed). Three attempts apply only when remaining pawns are in base and no home pawn can advance. Game and rule changes in the waiting room reset all Ready votes. Options lock after play starts. Host controls can return everyone to the lobby to change them after ending the current game. There are no AI opponents. Rules reference: [Schmidt Spiele](https://www.schmidtspiele.de/files/Produkte/4/49020%20-%20Jubil%C3%A4umsausgabe/49020_49021_Mensch_aergere_Dich_nicht_DE.pdf).

Hands can be sorted by color or shown in their dealt order. The just-drawn card opens on the correct page in either mode. A round-end score panel shows each opponent's contribution. Wild selections survive unrelated public updates. Commands are acknowledged individually, so table updates cannot unlock a pending move or make rapid clicks toggle Ready twice. Retrying an occupied saved seat waits for the old connection to clear.

## Host controls and the secret party menu

The host-only toolbar panel offers kick, mute/unmute, lock/unlock new joins, pause/resume, restart, new match and return to lobby. Destructive actions have confirmations. Kicking during a game ends it and resets scores; the room code, remaining connections and chat survive. Remove open seats compacts the waiting room without disconnecting retained players. Offline reservations must be kicked first; the room always has at least two seats. A kick revokes the saved seat and stops reconnects, but is not a permanent ban. Lock joins to block new arrivals while still permitting saved players to reconnect.

Restarting an unfinished UNO round keeps scores and the dealer. New match resets scores. Restarting Mensch resets the board and starter. Both need everyone connected. Return to lobby also works while someone is offline. Settings then become editable again. Mutes and the join lock last until changed or the room closes. Pauses block all game moves and Ready; chat remains available.

Type `/party` into chat and press Enter to open the secret fun menu. The code is handled locally and is not posted as a chat message. Everyone can trigger confetti on their own screen. Only the authenticated host can broadcast confetti or a bouncing Boo surprise, take a bonus Wild or +4 from the existing deck/discards at the start of their own UNO turn, or set the next board-game roll to 1–6. The dice override is used once, for whoever rolls next, and cleared on restart or return to lobby. Game-changing effects are announced publicly. Normal rules resume after the effect; cards are moved, never duplicated or taken from another hand. Confetti respects the Animations setting. The code is a hidden shortcut, not a security password.

In the waiting-room chat, the host can type `/küche` to show everyone a large, five-second kitchen-party banner. It stays inside the game window and does not change gameplay.

## Fixed host connection

This copy is hardcoded to **192.168.178.193:47624**. There are no IP or port inputs. Old saved addresses cannot override this destination. Re-entering the same room code automatically restores the saved seat; Resume last room is also available for a matching saved connection.

**192.168.178.193 is a local address and only works on that LAN.** Friends on different networks still need Tailscale setup and a game copy configured with the host’s Tailscale address. Installing Tailscale by itself does not make this local address reachable. See the detailed guide for the complete steps. The game has no public matchmaking service or internet relay.

The fixed address is `DEFAULT_HOST` near the top of `uno_app.py`; the fixed port is `DEFAULT_PORT` in `uno_net.py`. A future address change requires redistributing the updated app. Use the latest release on every PC. The UNO-only protocol is incompatible; this owner-controls release uses protocol version 7, so previous two-game clients must also update.

## Saved tables, players and game night

- **Restore host table:** host rooms save automatically to `playroom_host_save.json` after changes. After closing the game or a crash, reopen the launcher and choose **Restore host table**. The same code, private cards, pawns, rules, scores and reserved seats return. Friends keep their original extracted folder and `uno_session.json`, then use **Resume last room**, or leave their game open to reconnect automatically. The host PC must be running the restored room. Starting a new hosted room replaces the previous local checkpoint.
- **Player:** choose one of six avatars and a Room, Midnight, Pearl or Sunburst card back. Avatars are shared in the lobby and roster; your chosen card back appears on your screen. Friend-round wins, streaks and achievement badges stay on this PC. Practice rounds are tracked separately and do not inflate friend wins. Restoring or reconnecting to a finished round does not award the result twice.
- **Game night:** everyone can open the cross-game scoreboard. A round win earns one star. The host can add, reorder and remove up to twelve upcoming UNO or Mensch rounds. The current round stays first; the playlist advances only after all players choose Ready. Each queued UNO entry deals one fresh round. A playlist advances after each round, regardless of the normal points target; when the playlist ends, normal same-game rounds continue. The host can also save named rule presets, load them in the waiting room, and configure timers and bot seats here. Scheduling a playlist during play does not interrupt the current round.
- **Theme previews:** select a design in Settings to preview its scene, cards and pawns before applying it. Original scalable scenes coordinate both games and the menus. High contrast, text size, reduced motion and mute remain available. Settings and host forms scroll on smaller screens, with the action buttons kept at the bottom.
- **Connection health:** the header shows measured ping, quality and reconnect attempts, using the existing game connection. The host sees the local save status. The fixed address, port and host/join architecture are unchanged.
- **Extreme launcher:** Extreme is a Playroom house variant with +2 stacking and a weighted virtual launcher. Hitting the launcher gives **0, 2, 3, 4 or 6 cards**, then passes the turn. The weights are 35%, 30%, 20%, 10% and 5% respectively. The host resolves the result before the visual effect; clicking or skipping animations cannot change it. Stacked +2 penalties still require drawing the accumulated total. Classic keeps its normal one-card draw and optional play of that card.
- **Responsive effects:** legal moves remain available during deals, card flights and dice effects. A new move can interrupt the previous effect. Sound is optional; seven quiet original effects cover deals, draws, moves, dice, launches, captures and wins.

**Keep private local files on their original PCs:** `playroom_host_save.json` contains the room's private cards and seat keys. `playroom_profile.json` stores local cosmetics/statistics and `playroom_presets.json` stores favorite rules. These files, preferences and sessions are excluded from public updates and the Windows distribution ZIP. Share the original ZIP, never your played-in folder. Chat is not included in the host checkpoint and clears when the host closes.

## Designs and settings

**Settings** offers twelve designs: **Playroom**, **Classic**, **Spider-Man**, **Hello Kitty**, **Formula 1**, **Starlight**, **Deep Sea**, **Woodland**, **Candy Clouds**, **Arcade**, **Sunset** and **Larissa**. Larissa features a luxury black-and-white kitchen with marble, dark cabinets, a sink and a stove. Playroom is the default. The host chooses the shared room design in **Host settings** before play. Every player can also change their personal design from **Settings** at any time, including mid-game; this affects only their screen. Settings also offers text size, high contrast, animation pace, mute/sound, hints and fullscreen. Preferences are saved locally; UNO card colors keep their usual meaning.

The host chooses the game and **2–6 players**. UNO additionally offers **Classic or Extreme mode**, **5/7/10 starting cards**, and **100/250/500/1000 points to win**. Classic defaults are 7 cards and 500 points. Extreme adds a weighted virtual launcher with 0, 2, 3, 4 or 6-card bursts, ending the current turn, and allows a +2 to stack on a +2; the next player may stack again or draw the full total and lose their turn. Wild Draw Four cards do not stack. **Host settings** in the waiting room can change these before play starts. Changes reset all Ready votes; votes sent using old settings are rejected. Connected players in removed seats prevent a reduction. Offline reservations at removed seats are released. Increasing capacity adds open seats without losing the room or chat. Guests cannot change rules. Settings lock after the first game starts, so use Host controls to return everyone to the lobby, resetting the match, before changing them.

Use **Quick game**, **Standard**, or **Long night** to set a starting pace, then tune each option. A host can cap UNO at 3, 5, or 10 rounds, or leave the round cap off and play to the score target. Optional 30/45/60-second turn timers show the remaining time and make a legal move automatically if time expires. Timers are off by default.

The host can also add up to five **Easy**, **Normal**, or **Hard** bot seats. Bots are ready automatically; friends fill open seats first and can replace a bot before the first deal. Practice mode stays local to one PC. After a match ends, **Quick rematch · same table** lets players opt in to another match; scores reset only when everyone readies.

The **Use classic UNO** preset restores 7 cards and 500 points. Custom settings are saved. This UI update switches to the new Playroom design once; subsequent design choices remain saved.

## Connections and privacy

The host validates every action and sends each player only their own hand plus public state. Only the challenger sees a challenged Wild Draw Four hand. Every selected seat must be connected before play is accepted. A disconnect pauses the game; temporary losses reconnect automatically.

Guest seats are remembered in `uno_session.json`. Keep that file on its original PC. Seats remain reserved unless the host removes their offline seat while reducing waiting-room capacity. Keep the game open after a disconnect: it retries automatically, and **Reconnect now** requests an immediate retry while preserving your seat. The room holds play until missing players return. Closing the host disconnects the room. Restore host table recovers the automatic local checkpoint, keeping the same code and guest seat keys. Chat clears on host shutdown. The distribution ZIP excludes session files, preferences, caches and crash logs.

The host may need to allow the UNO/Python app through Windows Firewall on the network in use. The app does not modify firewall or system settings. For startup failures, check `uno_crash.log` beside the launcher.

## Rules

Classic 108-card deck with configurable starting hand and score target. Match color, number or symbol. Reverse changes direction; with two players it acts as Skip. Skip skips the next player. In Classic, Draw Two penalizes and skips the next player. In Extreme, Draw Two penalties stack; the player facing the stack may add another +2 or draw the accumulated total and lose their turn. +4 does not stack. In Classic, a drawn playable card may be played or kept, but other cards cannot be played after drawing. Extreme launcher bursts pass the turn immediately.

Call UNO before playing down to one card. A missed call can be caught by any other player before the next normal move. Late UNO calls are allowed before being caught. Wild Draw Four is lawful only without a card of the active color; a successful challenge penalizes the offender by four, and a failed challenge penalizes the challenger by six and skips their turn.

Opening action cards take effect; an opening Draw Four is replaced. The discard pile is recycled while preserving its top card. A final +2 or +4 applies its penalty and ends the round automatically before scoring; a final +4 does not open a challenge phase. The winner scores all opponents’ remaining cards: numbers at face value, actions 20, Wilds 50. The first dealer is chosen by the highest number drawn, with actions counting as zero and ties redrawn. The dealer moves one seat clockwise between rounds; a new match selects a new first dealer. Reaching the selected target wins the match.

Rules references: [Mattel classic UNO](https://service.mattel.com/instruction_sheets/W2085.pdf), [Mattel two-player rules](https://service.mattel.com/instruction_sheets/J4299-0520.pdf).

Portable runtime: 64-bit Windows 10/11. Source: Python 3.9+ with Tkinter, no third-party packages. The runtime license is in `runtime/LICENSE.txt`. These are personal fan-made games and visual themes, not official Mattel, Schmidt Spiele or character-brand products.
