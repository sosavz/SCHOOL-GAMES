"""Original scalable scene art; shared by menus, both tables and theme previews."""
import math


def blend(a,b,t):
    return '#'+''.join(f'{round(int(a[i:i+2],16)*(1-t)+int(b[i:i+2],16)*t):02x}' for i in (1,3,5))


def paint_scene(c,w,h,theme,paint):
    if w<20 or h<20 or paint['BG']=='#000000': return
    bg=paint['BG']; accent=paint['GOLD']; ink=paint['BORDER']
    for index in range(14):
        t=index/13
        c.create_rectangle(0,h*index/14,w,h*(index+1)/14+1,fill=blend(bg,paint['BOARD'],t*.55),outline='')
    def polygon(points,color,outline=''):
        c.create_polygon(*[v for x,y in points for v in (x*w,y*h)],fill=color,outline=outline)
    def glow(x,y,r,color):
        for factor,t in ((1,.06),(.7,.10),(.42,.20)):
            c.create_oval(w*x-r*factor,h*y-r*factor,w*x+r*factor,h*y+r*factor,fill=blend(bg,color,t),outline='')
    if theme in ('Starlight','Arcade'):
        glow(.83,.20,min(w,h)*.38,accent)
        for index in range(38):
            x=(index*137+29)%max(1,int(w)); y=(index*71+17)%max(1,int(h*.72))
            size=1+index%3
            c.create_oval(x,y,x+size,y+size,fill=blend(bg,'#ffffff',.35+index%4*.12),outline='')
        if theme=='Starlight':
            x,y=w*.83,h*.23;r=min(w,h)*.13
            c.create_oval(x-r*1.6,y-r*.4,x+r*1.6,y+r*.4,outline=blend(bg,accent,.65),width=3)
            c.create_oval(x-r,y-r,x+r,y+r,fill=blend(bg,accent,.35),outline=blend(bg,accent,.6),width=2)
            polygon(((0,.93),(.16,.68),(.31,.88),(.48,.63),(.68,.94),(1,.75),(1,1),(0,1)),blend(bg,'#000000',.22))
        else:
            horizon=h*.60
            for index in range(11):
                y=horizon+(h-horizon)*(index/10)**2
                c.create_line(0,y,w,y,fill=blend(bg,accent,.30),width=1)
            for index in range(-4,14): c.create_line(w*.5,horizon,index*w*.12,h,fill=blend(bg,paint['GREEN'],.45),width=1)
            polygon(((0,.60),(.15,.39),(.31,.57),(.49,.34),(.73,.59),(1,.39),(1,.61)),blend(bg,accent,.22),blend(bg,accent,.55))
    elif theme=='Deep Sea':
        for x in (.08,.35,.74):
            polygon(((x,0),(x+.07,0),(min(1,x+.35),1),(x-.09,1)),blend(bg,'#70d8ee',.06))
        for row in range(4):
            points=[]
            for index in range(25): points.extend((w*index/24,h*(.60+row*.12)+math.sin(index*.6+row)*h*.025))
            c.create_line(*points,fill=blend(bg,accent,.13+row*.035),smooth=True,width=max(2,h*.009))
        for index in range(14):
            x=w*(index+.5)/14;y=h*(.83+(index%3)*.06);r=4+index%4
            c.create_line(x,h,x-8,y,x+6,y-17,fill=blend(bg,paint['GREEN'],.5),smooth=True,width=3)
            c.create_oval(x-r,y-40,x+r,y-40+2*r,outline=blend(bg,'#ffffff',.24),width=1)
    elif theme=='Woodland':
        glow(.72,.20,min(w,h)*.34,accent)
        for layer in range(3):
            for index in range(9):
                x=(index/8+(layer%2)*.04); y=.55+layer*.16; size=.10+layer*.025
                color=blend(bg,paint['GREEN'],.12+layer*.14)
                polygon(((x-size,y),(x,y-.4),(x+size,y)),color)
                polygon(((x-size*1.2,y+.12),(x,y-.22),(x+size*1.2,y+.12)),color)
                c.create_line(x*w,(y-.08)*h,x*w,(y+.25)*h,fill=color,width=max(3,w*.006))
        for index in range(14):
            x=w*((index*37)%100)/100;y=h*(.50+index%5*.09)
            c.create_oval(x,y,x+3,y+3,fill=blend(bg,accent,.60),outline='')
    elif theme in ('Candy Clouds','Hello Kitty'):
        glow(.18,.24,min(w,h)*.34,'#ffffff')
        for index in range(8):
            x=w*(index/7); y=h*(.28+index%3*.22);r=min(w,h)*(.07+index%2*.025)
            color=blend(bg,'#ffffff',.68)
            for dx,dy,rr in ((-r,0,r*.7),(0,-r*.3,r),(r,0,r*.7)):
                c.create_oval(x+dx-rr,y+dy-rr*.6,x+dx+rr,y+dy+rr*.6,fill=color,outline='')
            if theme=='Hello Kitty':
                for side in (-1,1):
                    c.create_oval(x+side*r*.23-r*.25,y-r*.12,x+side*r*.23+r*.25,y+r*.12,outline=blend(bg,accent,.45),width=2)
        polygon(((0,.88),(.25,.76),(.51,.90),(.80,.78),(1,.86),(1,1),(0,1)),blend(bg,accent,.13))
    elif theme=='Formula 1':
        glow(.81,.18,min(w,h)*.35,'#ff5149')
        polygon(((0,.38),(.28,.36),(.40,.46),(.70,.38),(1,.41),(1,.60),(0,.59)),blend(bg,'#ffffff',.07))
        polygon(((0,1),(.32,.63),(.62,.48),(.73,.48),(.55,.68),(.36,1)),blend(bg,'#ffffff',.13))
        c.create_line(w*.16,h,w*.46,h*.65,w*.67,h*.49,fill=blend(bg,'#ffffff',.45),width=3,dash=(14,18),smooth=True)
        for row in range(3):
            for col in range(12):
                c.create_rectangle(w*.79+col*w*.016,h*.09+row*10,w*.79+(col+1)*w*.016,h*.09+(row+1)*10,
                                   fill=blend(bg,'#ffffff',.32) if (row+col)%2 else blend(bg,'#000000',.5),outline='')
        c.create_line(w*.30,h,w*.58,h*.66,w*.70,h*.48,fill=blend(bg,paint['GREEN'],.55),width=5,smooth=True)
    elif theme=='Spider-Man':
        glow(.72,.18,min(w,h)*.35,'#ed4d6b')
        for layer in range(2):
            for index in range(13):
                x=w*index/12;y=h*(.52+((index*17+layer*3)%13)/45)+layer*h*.16
                color=blend(bg,paint['BUTTON'],.18+layer*.18)
                c.create_rectangle(x,y,x+w*.075,h,fill=color,outline='')
                for level in range(3): c.create_line(x+7,y+14+level*17,x+14,y+14+level*17,fill=blend(bg,accent,.22),width=2)
        for side in (0,w):
            for step in (1,2,3):
                r=min(w,h)*step*.14
                c.create_arc(side-r, -r, side+r,r,start=180 if side else 270,extent=90,style='arc',outline=blend(bg,ink,.32))
    elif theme=='Sunset':
        glow(.77,.25,min(w,h)*.45,accent)
        r=min(w,h)*.15
        c.create_oval(w*.77-r,h*.3-r,w*.77+r,h*.3+r,fill=blend(bg,accent,.45),outline='')
        for layer in range(4):
            points=[(0,1)]
            points += [(index/10,.58+layer*.09+math.sin(index*.72+layer)*.07) for index in range(11)]
            points += [(1,1)]
            polygon(points,blend(bg,paint['GOLD'] if layer%2 else paint['BUTTON'],.12+layer*.03))
    elif theme=='Larissa':
        # Cabinet silhouettes, marble seams and warm recessed lighting frame the room.
        for side in (0,.82):
            c.create_rectangle(w*side,h*.18,w*(side+.18),h*.66,fill=blend(bg,'#151719',.70),outline=blend(bg,ink,.50),width=2)
            for index in range(3): c.create_line(w*(side+.02),h*(.29+index*.11),w*(side+.16),h*(.29+index*.11),fill=blend(bg,'#ffffff',.20),width=1)
            c.create_line(w*(side+.02),h*.66,w*(side+.16),h*.66,fill='#c8b47f',width=3)
        c.create_rectangle(0,h*.78,w,h*.84,fill=blend(bg,'#1c1e22',.65),outline='')
        c.create_line(0,h*.78,w,h*.78,fill='#d3c08f',width=2)
        for index in range(6):
            x=w*index/5
            c.create_line(x,h*.84,x+w*.13,h*.94,x+w*.18,h,fill=blend(bg,ink,.30),width=1)
        for x in (.29,.5,.71):
            glow(x,.16,min(w,h)*.18,'#f3daa3')
            c.create_line(w*x,0,w*x,h*.13,fill=blend(bg,'#000000',.45),width=2)
            polygon(((x-.035,.13),(x+.035,.13),(x+.06,.18),(x-.06,.18)),blend(bg,'#1a1b1d',.70))
    else:
        # Felt for Classic; bright, tactile game pieces for Playroom.
        for x,y,r in ((.12,.20,.20),(.89,.85,.25),(.76,.15,.12)):
            glow(x,y,min(w,h)*r,accent)
        for inset in (12,20):
            c.create_rectangle(inset,inset,w-inset,h-inset,outline=blend(bg,ink,.25),width=1)
        if theme=='Playroom':
            for index in range(9):
                x=(index*193+37)%max(1,int(w)); y=h*(.1+index%5*.19);r=12+index%4*5
                c.create_oval(x-r,y-r,x+r,y+r,outline=blend(bg,accent,.12),width=3)
