"""Small, keyboard-accessible vector widgets for the portable Tk app."""
import math
import time
import tkinter as tk
import tkinter.font as tkfont
from uno_art import rounded, paint_uno_card


def mix(a,b,t):
    t=max(0,min(1,t))
    return '#'+''.join(f'{round(int(a[i:i+2],16)*(1-t)+int(b[i:i+2],16)*t):02x}' for i in (1,3,5))


def pawn(c,x,y,r,color,number='',ring=False):
    if ring:
        c.create_oval(x-r*1.5,y-r*1.5,x+r*1.5,y+r*1.5,fill='#e9e5ff',outline='#514bcb',width=2)
    c.create_oval(x-r,y+r*.55,x+r,y+r*1.1,fill='#c8c4c9',outline='')
    c.create_oval(x-r*.82,y-r*.23,x+r*.82,y+r*.83,fill=mix(color,'#17203b',.14),outline='')
    c.create_oval(x-r*.68,y-r*.90,x+r*.68,y+r*.40,fill=color,outline=mix(color,'#ffffff',.26),width=1)
    c.create_oval(x-r*.35,y-r*.68,x-r*.04,y-r*.37,fill=mix(color,'#ffffff',.65),outline='')
    if number:
        c.create_text(x,y,text=str(number),font=('Segoe UI',max(8,int(r*.7)),'bold'),fill='#20263e' if color=='#e5bd24' else 'white')


def die(c,x,y,size,value,accent='#514bcb',tilt=0):
    rounded(c,x-size/2+2,y-size/2+5,x+size/2+2,y+size/2+5,size*.22,fill='#c9c6d9',outline='')
    rounded(c,x-size/2,y-size/2,x+size/2,y+size/2,size*.22,fill='white',outline='#ddd9ef',width=2)
    dots={1:[(0,0)],2:[(-1,-1),(1,1)],3:[(-1,-1),(0,0),(1,1)],4:[(-1,-1),(-1,1),(1,-1),(1,1)],
          5:[(-1,-1),(-1,1),(0,0),(1,-1),(1,1)],6:[(-1,-1),(-1,0),(-1,1),(1,-1),(1,0),(1,1)]}
    if value not in dots:
        c.create_text(x,y,text='?',fill=accent,font=('Segoe UI',int(size*.34),'bold')); return
    for a,b in dots[value]:
        dx,dy=a*math.cos(tilt)-b*math.sin(tilt),a*math.sin(tilt)+b*math.cos(tilt)
        xx,yy=x+dx*size*.25,y+dy*size*.25; r=size*.065
        c.create_oval(xx-r,yy-r,xx+r,yy+r,fill=accent,outline='')


class SoftButton(tk.Canvas):
    """A real focusable button, drawn as a rounded pill; no image scaling."""
    is_button=True
    def __init__(self,parent,text,command,paint,secondary=False,large=False):
        self.paint=paint; self.command=command; self.secondary=secondary
        self.opts={'text':text,'state':'normal','font':('Segoe UI',13 if large else 10,'bold'),
                   'padx':20 if large else 15,'pady':19 if large else 11,
                   'bg':paint['BUTTON'] if secondary else paint['GREEN'],
                   'fg':paint['TEXT'] if secondary else paint['BUTTON_TEXT']}
        self.level=0.; self.target=0.; self.job=None; self.pressed=False; self.focused=False
        super().__init__(parent,bg=parent.cget('bg'),highlightthickness=0,bd=0,takefocus=1,cursor='hand2')
        self._measure()
        self.bind('<Configure>',lambda e:self.redraw())
        self.bind('<Enter>',lambda e:self.hover(True)); self.bind('<Leave>',lambda e:self.hover(False))
        self.bind('<ButtonPress-1>',self.press); self.bind('<ButtonRelease-1>',self.release)
        self.bind('<FocusIn>',lambda e:self.focused_set(True)); self.bind('<FocusOut>',lambda e:self.focused_set(False))
        self.bind('<Return>',self.key); self.bind('<space>',self.key)
        self.bind('<Destroy>',self.cleanup)

    def _measure(self):
        font=tkfont.Font(root=self,font=self.opts['font'])
        width=max(font.measure(line) for line in self.opts['text'].split('\n'))+self.opts['padx']*2+8
        height=font.metrics('linespace')*len(self.opts['text'].split('\n'))+self.opts['pady']*2+4
        super().configure(width=width,height=height)

    def configure(self,cnf=None,**kw):
        if cnf: kw.update(cnf)
        custom={k:kw.pop(k) for k in list(kw) if k in self.opts}
        custom={k:v for k,v in custom.items() if self.opts[k]!=v}
        if not custom and not kw: return
        self.opts.update(custom)
        if kw: super().configure(**kw)
        if any(k in custom for k in ('text','font','padx','pady')): self._measure()
        if custom.get('state')=='disabled': self.pressed=False
        self.redraw()
    config=configure
    def cget(self,key):
        return self.opts[key] if key in self.opts else super().cget(key)
    def invoke(self):
        if self.opts['state']!='disabled' and self.command: return self.command()
    def key(self,event):
        self.invoke(); return 'break'
    def press(self,event):
        if self.opts['state']=='disabled': return
        self.focus_set(); self.pressed=True; self.redraw()
    def release(self,event):
        pressed=self.pressed; self.pressed=False; self.redraw()
        if pressed and 0<=event.x<=self.winfo_width() and 0<=event.y<=self.winfo_height(): self.invoke()
    def focused_set(self,value): self.focused=value; self.redraw()
    def hover(self,value):
        self.target=1. if value and self.opts['state']!='disabled' else 0.
        if not value: self.pressed=False
        root=self.winfo_toplevel()
        if hasattr(root,'motion') and not root.motion.get():
            self.level=self.target; self.redraw(); return
        if self.job is None: self.step()
    def step(self):
        self.job=None
        if not self.winfo_exists(): return
        self.level+=(self.target-self.level)*.35
        self.redraw()
        if abs(self.level-self.target)>.02: self.job=self.after(16,self.step)
    def cleanup(self,event):
        if event.widget is self and self.job:
            self.after_cancel(self.job); self.job=None
    def redraw(self):
        if not self.winfo_exists(): return
        self.delete('all'); w=max(self.winfo_width(),int(super().cget('width'))) if self.winfo_width()<=1 else self.winfo_width()
        h=self.winfo_height() if self.winfo_height()>1 else int(super().cget('height'))
        disabled=self.opts['state']=='disabled'; base=self.opts['bg']
        fill=mix(base,self.paint['BG'],.60) if disabled else mix(base,self.paint['TEXT'] if self.secondary else '#ffffff',self.level*.10)
        fg=self.paint['MUTED'] if disabled else self.opts['fg']
        offset=2 if self.pressed else 0
        if not self.secondary and not disabled:
            rounded(self,3,5,w-3,h-1,14,fill=mix(base,'#1e193c',.28),outline='')
        rounded(self,3,2+offset,w-3,h-5+offset,14,fill=fill,outline=self.paint['GOLD'] if self.focused else '',width=2)
        if self.focused: rounded(self,1,0,w-1,h-2,15,fill='',outline=self.paint['GOLD'],width=2)
        self.create_text(w/2,(h-3)/2+offset,text=self.opts['text'],font=self.opts['font'],fill=fg,justify='center')


class Surface(tk.Frame):
    """A rounded surface whose children keep normal Tk layout and focus."""
    def __init__(self,parent,bg,**kw):
        self.surface_fill=bg
        super().__init__(parent,bg=parent.cget('bg'),**kw)
        self.paper=tk.Canvas(self,bg=parent.cget('bg'),highlightthickness=0,bd=0,takefocus=0)
        self.paper.place(x=0,y=0,relwidth=1,relheight=1,bordermode='ignore')
        self.tk.call('lower',self.paper._w)
        self.bind('<Configure>',lambda e:self.redraw())
    def configure(self,cnf=None,**kw):
        if cnf: kw.update(cnf)
        if 'bg' in kw: self.surface_fill=kw.pop('bg')
        if kw: super().configure(**kw)
        if hasattr(self,'paper'): self.redraw()
    config=configure
    def cget(self,key): return self.surface_fill if key in ('bg','background') else super().cget(key)
    def redraw(self):
        self.paper.delete('all')
        rounded(self.paper,0,0,self.winfo_width(),self.winfo_height(),18,fill=self.surface_fill,outline='')


class ThemeBackdrop(tk.Canvas):
    """Quiet, original vector wallpaper used across every app screen."""
    def __init__(self,parent,theme,paint,**kw):
        self.theme=theme; self.paint=paint
        super().__init__(parent,highlightthickness=0,bd=0,takefocus=0,**kw)
        self.bind('<Configure>',lambda _e:self.redraw())
        self.redraw()
    def set_theme(self,theme,paint):
        self.theme=theme; self.paint=paint; self.configure(bg=paint['BG']); self.redraw()
    def redraw(self):
        if not self.winfo_exists(): return
        self.delete('all'); self.configure(bg=self.paint['BG'])
        w,h=max(1,self.winfo_width()),max(1,self.winfo_height())
        bg=self.paint['BG']; ink=mix(bg,self.paint['BORDER'],.28); glow=mix(bg,self.paint['GOLD'],.20)
        step=148 if h>120 else 76
        theme=self.theme
        for row,y in enumerate(range(step//2,int(h)+step,step)):
            for col,x in enumerate(range(step//2,int(w)+step,step)):
                xx=x+(step//2 if row%2 else 0); r=8+(row+col)%4
                if theme=='Spider-Man':
                    for a in range(0,360,45):
                        ex=xx+math.cos(math.radians(a))*r*2.8; ey=y+math.sin(math.radians(a))*r*2.8
                        self.create_line(xx,y,ex,ey,fill=ink,width=1)
                    self.create_oval(xx-r*2.8,y-r*2.8,xx+r*2.8,y+r*2.8,outline=ink,width=1)
                elif theme=='Hello Kitty':
                    self.create_oval(xx-r*1.5,y-r*.75,xx-r*.15,y+r*.25,outline=glow,width=2)
                    self.create_oval(xx+r*.15,y-r*.75,xx+r*1.5,y+r*.25,outline=glow,width=2)
                    self.create_oval(xx-r*.45,y-r*.25,xx+r*.45,y+r*.65,outline=ink,width=1)
                elif theme=='Formula 1':
                    cell=8
                    for a in range(2):
                        for b in range(2):
                            if (a+b+row+col)%2==0:
                                self.create_rectangle(xx+a*cell,y+b*cell,xx+(a+1)*cell,y+(b+1)*cell,fill=ink,outline='')
                    self.create_line(xx-18,y+18,xx+22,y-18,fill=glow,width=2)
                elif theme=='Starlight':
                    self.create_oval(xx-r,y-r,xx+r,y+r,outline=ink,width=1)
                    self.create_line(xx-r*1.8,y,xx+r*1.8,y,fill=glow,width=1)
                    self.create_line(xx,y-r*1.8,xx,y+r*1.8,fill=glow,width=1)
                elif theme=='Deep Sea':
                    self.create_oval(xx-r,y-r,xx+r,y+r,outline=ink,width=2)
                    self.create_oval(xx-r*.5,y-r*.6,xx-r*.15,y-r*.25,fill=glow,outline='')
                elif theme=='Woodland':
                    self.create_oval(xx-r*1.5,y-r*.65,xx+r*1.5,y+r*.65,outline=ink,width=1)
                    self.create_line(xx-r*1.3,y+r*.5,xx+r*1.3,y-r*.5,fill=glow,width=1)
                elif theme=='Candy Clouds':
                    for dx,dy,rr in ((-r,2,r*.7),(0,-r*.4,r),(r,2,r*.7)):
                        self.create_oval(xx+dx-rr,y+dy-rr,xx+dx+rr,y+dy+rr,outline=ink,width=1)
                    self.create_line(xx-r,y+r,xx+r,y+r,fill=ink,width=1)
                elif theme=='Arcade':
                    self.create_rectangle(xx-r,y-r,xx+r,y+r,outline=ink,width=1)
                    self.create_rectangle(xx-r*.4,y-r*.4,xx+r*.4,y+r*.4,fill=glow,outline='')
                elif theme=='Sunset':
                    self.create_arc(xx-r*2,y-r,xx+r*2,y+r*3,start=0,extent=180,style='arc',outline=ink,width=2)
                    self.create_line(xx-r*1.5,y+r,xx+r*1.5,y+r,fill=glow,width=1)
                elif theme=='Larissa':
                    self.create_rectangle(xx-r*2,y-r*2,xx+r*2,y+r*2,outline=ink,width=1)
                    self.create_oval(xx-r*.8,y-r*.35,xx+r*.8,y+r*.65,outline=glow,width=2)
                    self.create_line(xx+r*.55,y-r*.2,xx+r*1.55,y-r*.65,fill=glow,width=2)
                else:
                    self.create_oval(xx-r,y-r,xx+r,y+r,outline=ink,width=1)
                    self.create_oval(xx-r*.35,y-r*.35,xx+r*.35,y+r*.35,fill=glow,outline='')



class GameTile(tk.Canvas):
    def __init__(self,parent,app,kind,command):
        super().__init__(parent,height=190,bg=parent.cget('bg'),highlightthickness=0,takefocus=1,cursor='hand2')
        self.app,self.kind,self.command=app,kind,command; self.hovered=False; self.level=0.; self.job=None
        self.bind('<Configure>',lambda e:self.draw())
        self.bind('<Button-1>',lambda e:self.choose())
        self.bind('<Return>',lambda e:self.choose()); self.bind('<space>',lambda e:self.choose())
        self.bind('<Enter>',lambda e:self.hover(True)); self.bind('<Leave>',lambda e:self.hover(False))
        self.bind('<FocusIn>',lambda e:self.hover(True)); self.bind('<FocusOut>',lambda e:self.hover(False))
        self.bind('<Destroy>',self.cleanup)
    def choose(self): self.focus_set(); self.command(self.kind); return 'break'
    def hover(self,on):
        self.hovered=on
        if not self.app.motion.get(): self.level=float(on); self.draw()
        elif self.job is None: self.step()
    def step(self):
        self.job=None; self.level+=(float(self.hovered)-self.level)*.25; self.draw()
        if abs(self.level-float(self.hovered))>.02: self.job=self.after(16,self.step)
    def cleanup(self,e):
        if e.widget is self and self.job: self.after_cancel(self.job); self.job=None
    def draw(self):
        self.delete('all'); w=max(100,self.winfo_width()); h=max(100,self.winfo_height()); app=self.app
        selected=app.game_kind.get()==self.kind
        fill=app.ACTIVE if selected else app.TILE
        rounded(self,5,7,w-5,h-2,23,fill=mix(app.BG,app.BORDER,.65),outline='')
        rounded(self,3,3,w-3,h-7,23,fill=fill,outline=app.GREEN if selected else app.BORDER,width=3 if selected else 2)
        name='UNO' if self.kind=='uno' else 'Mensch ärgere\ndich nicht'
        compact=h<180
        self.create_text(22,23 if compact else 29,text=name,anchor='nw',fill=app.TEXT,font=('Segoe UI',23 if self.kind=='uno' else 15 if compact else 17,'bold'))
        self.create_text(23,79 if compact else 89 if self.kind=='uno' else 93,text='Match. Play. Shout UNO!' if self.kind=='uno' else 'Roll. Race. Get home!',anchor='nw',fill=app.MUTED,font=('Segoe UI',10))
        self.create_text(23,h-34,text='2–6 friends  ·  Card game' if self.kind=='uno' else '2–6 friends  ·  Board game',anchor='w',fill=app.MUTED,font=('Segoe UI',9))
        cx=w-85; cy=(73 if compact else 87)-6*self.level
        if w>275:
            if self.kind=='uno':
                self.design=app.design.get()
                for i,card in enumerate((('Blue','Reverse'),('Yellow','7'),('Red','7'))):
                    paint_uno_card(self,cx-45+i*27,cy-39+(i%2)*10,54,81,card)
            else:
                for dx,dy,col in ((-30,0,'#d9363e'),(32,12,'#25955b'),(3,-23,'#e5bd24')):
                    pawn(self,cx+dx,cy+dy,22,col)
                die(self,cx+6,cy+37,39,5)
        if selected:
            self.create_oval(w-35,16,w-15,36,fill=app.GREEN,outline='')
            self.create_text(w-25,26,text='✓',fill='white',font=('Segoe UI',10,'bold'))
